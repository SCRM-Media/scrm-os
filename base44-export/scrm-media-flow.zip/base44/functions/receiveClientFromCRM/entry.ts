import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  if (req.method !== 'POST') {
    return Response.json({ error: 'Method not allowed' }, { status: 405 });
  }

  // Verify shared secret
  const authHeader = req.headers.get('x-webhook-secret');
  const expectedSecret = Deno.env.get('CRM_WEBHOOK_SECRET');
  if (!authHeader || authHeader !== expectedSecret) {
    return Response.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const payload = await req.json();
  const base44 = createClientFromRequest(req);

  // ── Map package name ──────────────────────────────────────────────────────
  // Supported packages in SCRM OS: Minimum, Momentum, Dominate, Partner
  // CRM may send: Performance, Custom — map to closest or leave blank
  const PACKAGE_MAP = {
    'Minimum': 'Minimum',
    'Momentum': 'Momentum',
    'Dominate': 'Dominate',
    'Partner': 'Partner',
    'Performance': 'Partner',   // closest match
    'Custom': 'Momentum',       // fallback
  };

  // ── Map active services to add_ons array ─────────────────────────────────
  const activeServices = payload.active_services || [];
  const carbeeEnabled = activeServices.some(s => /carbee/i.test(s));
  const inventoryEnabled = activeServices.some(s => /inventory/i.test(s));
  const inventoryVideoEnabled = activeServices.some(s => /inventory.video/i.test(s) || /inventory video/i.test(s));

  const mappedPackage = PACKAGE_MAP[payload.package] || null;

  // ── Pre-fill onboarding_progress so Phase 1 wizard is pre-populated ──────
  const clientInfoProgress = {
    dealership_name: payload.dealership_name || '',
    state: payload.state || '',
    address: payload.address || '',
    contact_name: payload.contact_full_name || payload.contact_name || '',
    contact_position: payload.contact_role || payload.contact_title || '',
    contact_phone: payload.contact_phone || '',
    contact_email: payload.contact_email || '',
    package: mappedPackage || '',
    monthly_value: payload.monthly_value ? Number(payload.monthly_value) : '',
    add_ons: activeServices,
    // Add-on pricing prefill
    ...(inventoryEnabled && payload.inventory_cars_per_month ? {
      addon_inv_photo: {
        cars_per_month: Number(payload.inventory_cars_per_month),
        price_per_car: payload.inventory_price_per_car ? Number(payload.inventory_price_per_car) : '',
      }
    } : {}),
    ...(inventoryVideoEnabled && payload.inventory_video_cars_per_month ? {
      addon_inv_video: {
        cars_per_month: Number(payload.inventory_video_cars_per_month),
        price_per_car: payload.inventory_video_price_per_car ? Number(payload.inventory_video_price_per_car) : '',
      }
    } : {}),
    ...(carbeeEnabled && payload.carbee_cars_per_month ? {
      addon_carbee: {
        cars_per_month: Number(payload.carbee_cars_per_month),
        price_per_car: payload.carbee_price_per_car ? Number(payload.carbee_price_per_car) : '',
      }
    } : {}),
  };

  // ── Build client record ───────────────────────────────────────────────────
  const clientData = {
    name: payload.dealership_name || 'Unknown Dealership',
    status: 'Onboarding',
    location: [payload.address, payload.state].filter(Boolean).join(', ') || payload.location || null,
    address: payload.address || null,
    state: payload.state || null,
    package: mappedPackage,
    monthly_value: payload.monthly_value ? Number(payload.monthly_value) : null,
    filming_cadence: payload.filming_cadence || null,
    add_ons: activeServices,
    carbee_enabled: carbeeEnabled,
    inventory_enabled: inventoryEnabled,
    onboarding_progress: { client_info: clientInfoProgress },
  };

  const client = await base44.asServiceRole.entities.Client.create(clientData);

  // ── Create contact record ─────────────────────────────────────────────────
  const contactName = payload.contact_full_name || payload.contact_name || null;
  if (contactName) {
    await base44.asServiceRole.entities.Contact.create({
      client: client.id,
      full_name: contactName,
      position: payload.contact_role || payload.contact_title || null,
      phone: payload.contact_phone || null,
      email: payload.contact_email || null,
      is_primary: true,
    });
  }

  console.log(`CRM webhook: created client "${client.name}" (id: ${client.id})`);

  return Response.json({
    success: true,
    client_id: client.id,
    client_name: client.name,
  });
});