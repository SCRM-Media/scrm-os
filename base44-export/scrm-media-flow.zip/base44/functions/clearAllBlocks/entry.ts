import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    // Fetch ALL blocks in batches until none remain
    let totalDeleted = 0;
    while (true) {
      const batch = await base44.asServiceRole.entities.CalendarBlock.list('created_date', 200);
      if (!batch || batch.length === 0) break;

      for (const block of batch) {
        await base44.asServiceRole.entities.CalendarBlock.delete(block.id);
        totalDeleted++;
      }

      // If we got fewer than 200, we've cleared everything
      if (batch.length < 200) break;
    }

    return Response.json({ success: true, deleted: totalDeleted });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});