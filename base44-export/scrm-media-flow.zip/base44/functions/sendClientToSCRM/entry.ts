/**
 * SCRM OS SENDER — Deploy this in your CRM app.
 *
 * Call this function from an entity automation on your Lead/Account entity
 * when status changes to "Active".
 *
 * The automation payload will contain:
 *   event.entity_name, event.entity_id, data (the lead/account record)
 *
 * Set these secrets in the CRM app:
 *   SCRM_WEBHOOK_URL  — the full URL of receiveClientFromCRM in SCRM OS
 *                       e.g. https://app--your-scrm-app.base44.app/api/apps/<appId>/functions/receiveClientFromCRM
 *   SCRM_WEBHOOK_SECRET — same value as CRM_WEBHOOK_SECRET in SCRM OS
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);

  const SCRM_URL = Deno.env.get('SCRM_WEBHOOK_URL');
  const SCRM_SECRET = Deno.env.get('SCRM_WEBHOOK_SECRET');

  if (!SCRM_URL || !SCRM_SECRET) {
    return Response.json({ error: 'Missing SCRM_WEBHOOK_URL or SCRM_WEBHOOK_SECRET secrets' }, { status: 500 });
  }

  // ── Parse automation payload ──────────────────────────────────────────────
  const body = await req.json();
  const leadData = body.data || {};

  // ── Resolve contact: prefer linked Contacts, fallback to Lead fields ──────
  let contactName = null, contactRole = null, contactPhone = null, contactEmail = null;

  // Try to fetch linked contacts from the CRM (adjust entity/field names as needed)
  try {
    const contacts = await base44.asServiceRole.entities.Contact.filter({ lead: leadData.id });
    if (contacts.length > 0) {
      const primary = contacts.find(c => c.is_primary) || contacts[0];
      contactName = primary.full_name || null;
      contactRole = primary.role || primary.position || null;
      contactPhone = primary.phone || null;
      contactEmail = primary.email || null;
    }
  } catch (_) {
    // Contact entity may have a different name in the CRM — fall through to lead fields
  }

  // Fallback to fields on the lead/account record itself
  if (!contactName) {
    contactName = leadData.contact_name || leadData.contact_full_name || null;
    contactRole = leadData.contact_title || leadData.contact_role || null;
    contactPhone = leadData.contact_phone || null;
    contactEmail = leadData.contact_email || null;
  }

  // ── Build payload for SCRM OS ─────────────────────────────────────────────
  const scrmPayload = {
    // Account / dealership
    dealership_name: leadData.dealership_name || leadData.account_name || leadData.name,
    location: leadData.location || null,
    address: leadData.address || null,
    website: leadData.website || null,

    // Package & commercial
    package: leadData.package || null,
    monthly_value: leadData.monthly_value || leadData.mrr || null,
    filming_cadence: leadData.filming_cadence || null,

    // Active services (array of strings, e.g. ["CarBee", "Inventory Photography"])
    active_services: leadData.active_services || leadData.services || [],

    // CarBee pricing
    carbee_cars_per_month: leadData.carbee_cars_per_month || null,
    carbee_price_per_car: leadData.carbee_price_per_car || null,

    // Inventory pricing
    inventory_cars_per_month: leadData.inventory_cars_per_month || null,
    inventory_price_per_car: leadData.inventory_price_per_car || null,

    // Contact
    contact_full_name: contactName,
    contact_role: contactRole,
    contact_phone: contactPhone,
    contact_email: contactEmail,
  };

  // ── POST to SCRM OS ───────────────────────────────────────────────────────
  const response = await fetch(SCRM_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-webhook-secret': SCRM_SECRET,
    },
    body: JSON.stringify(scrmPayload),
  });

  const result = await response.json();

  if (!response.ok) {
    console.error('SCRM webhook failed:', result);
    return Response.json({ error: 'SCRM webhook failed', detail: result }, { status: 500 });
  }

  console.log(`Sent client to SCRM OS: ${result.client_name} (${result.client_id})`);
  return Response.json({ success: true, scrm_client_id: result.client_id });
});