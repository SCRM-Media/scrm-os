import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import ClientSelector from '@/components/social/ClientSelector';
import ClientCalendarPage from '@/components/social/ClientCalendarPage';

export default function SocialCalendar() {
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedClient, setSelectedClient] = useState(null);

  useEffect(() => {
    base44.entities.Client.list().then(data => {
      setClients(data);
      setLoading(false);
    });
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="w-7 h-7 border-2 border-border border-t-accent rounded-full animate-spin" />
      </div>
    );
  }

  if (selectedClient) {
    return (
      <ClientCalendarPage
        client={selectedClient}
        onBack={() => setSelectedClient(null)}
      />
    );
  }

  return <ClientSelector clients={clients} onSelect={setSelectedClient} />;
}