import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import ClientScheduleTab from '@/components/clients/ClientScheduleTab';
import ClientAboutTabs from '@/components/social/ClientAboutTabs';
import CarBeeTab from '@/components/clients/CarBeeTab.jsx';
import InventoryPhotographyTab from '@/components/clients/InventoryPhotographyTab.jsx';
import { Plus, Search, Edit2, Trash2, ChevronDown, ChevronUp, AlertTriangle } from 'lucide-react';
import StatusBadge, { packageColors } from '@/components/ui/StatusBadge';
import PageHeader from '@/components/ui/PageHeader';
import ClientModal from '@/components/clients/ClientModal.jsx';

const HEALTH_DOTS = {
  Green: 'bg-green-500',
  Amber: 'bg-amber-500',
  Red: 'bg-red-500',
};

export default function Clients() {
  const [clients, setClients] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterHealth, setFilterHealth] = useState('All');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingClient, setEditingClient] = useState(null);
  const [expandedId, setExpandedId] = useState(null);
  const [expandedTab, setExpandedTab] = useState('details'); // 'details' | 'schedule'

  const load = async () => {
    const [data, emps, ctcts] = await Promise.all([
      base44.entities.Client.filter({ status: 'Active' }),
      base44.entities.Employee.list(),
      base44.entities.Contact.list(),
    ]);
    setClients(data);
    setEmployees(emps);
    setContacts(ctcts);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const filtered = clients.filter(c => {
    const matchSearch = c.name?.toLowerCase().includes(search.toLowerCase()) ||
      c.location?.toLowerCase().includes(search.toLowerCase());
    const matchHealth = filterHealth === 'All' || c.account_health === filterHealth;
    return matchSearch && matchHealth;
  });

  const handleEdit = (client) => {
    setEditingClient(client);
    setModalOpen(true);
  };

  const handleDelete = async (id) => {
    if (!confirm('Delete this client?')) return;
    await base44.entities.Client.delete(id);
    load();
  };

  const handleSave = async (data) => {
    if (editingClient) {
      const packageChanged = editingClient.package !== data.package;
      await base44.entities.Client.update(editingClient.id, data);

      // If package changed, end all active BlockRules and prompt user to set up schedule
      if (packageChanged && data.package) {
        const today = new Date().toISOString().split('T')[0];
        const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
        const existingRules = await base44.entities.BlockRule.filter({ client: editingClient.id });
        const activeRules = existingRules.filter(r => !r.rule_end_date || r.rule_end_date >= today);
        await Promise.all(activeRules.map(r => base44.entities.BlockRule.update(r.id, { rule_end_date: yesterday })));
        setModalOpen(false);
        setEditingClient(null);
        await load();
        // Open the client's schedule tab so they can set up the new schedule
        setExpandedId(editingClient.id);
        setExpandedTab('schedule');
        return;
      }
    } else {
      await base44.entities.Client.create(data);
    }
    setModalOpen(false);
    setEditingClient(null);
    load();
  };

  return (
    <div className="p-6 lg:p-8 max-w-7xl mx-auto">
      <PageHeader
        title="Clients"
        subtitle={`${clients.length} active dealerships`}
        action={
          <button
            onClick={() => { setEditingClient(null); setModalOpen(true); }}
            className="flex items-center gap-2 bg-accent text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-accent/90 transition-colors"
          >
            <Plus size={16} /> Add Client
          </button>
        }
      />

      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-6">
        <div className="relative flex-1 min-w-48">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search clients..."
            className="w-full pl-9 pr-3 py-2 text-sm border border-border rounded-lg bg-card focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
        <select
          value={filterHealth}
          onChange={e => setFilterHealth(e.target.value)}
          className="px-3 py-2 text-sm border border-border rounded-lg bg-card focus:outline-none"
        >
          {['All', 'Green', 'Amber', 'Red'].map(h => <option key={h}>{h}</option>)}
        </select>
      </div>

      {loading ? (
        <div className="flex justify-center py-16">
          <div className="w-7 h-7 border-2 border-border border-t-accent rounded-full animate-spin" />
        </div>
      ) : (
        <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
          {/* Column headers */}
          <div className="grid grid-cols-[1fr_auto_auto_auto] items-center px-5 py-2.5 border-b border-border bg-secondary/40">
            <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Dealership Name</span>
            <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide text-right mr-8">Monthly Value</span>
            <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mr-4">Status</span>
            <span></span>
          </div>
          <div className="divide-y divide-border">
            {filtered.length === 0 && (
              <div className="py-16 text-center text-muted-foreground text-sm">No active clients found</div>
            )}
            {filtered.map(client => (
              <div key={client.id}>
                <div
                  className="px-5 py-4 flex items-center gap-4 hover:bg-secondary/40 transition-colors cursor-pointer"
                  onClick={() => setExpandedId(expandedId === client.id ? null : client.id)}
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium text-foreground text-sm">{client.name}</span>
                      <StatusBadge label={client.package} colorMap={packageColors} />
                    </div>
                    <div className="text-xs text-muted-foreground mt-0.5">{client.location}</div>
                  </div>

                  <div className="hidden sm:flex items-center gap-4 shrink-0">
                    {client.monthly_value ? (
                      <span className="text-sm font-semibold text-foreground">${client.monthly_value.toLocaleString()}/mo</span>
                    ) : (
                      <span className="text-sm text-muted-foreground">—</span>
                    )}
                    {/* Health dot only — no text */}
                    <div
                      className={`w-2.5 h-2.5 rounded-full ${HEALTH_DOTS[client.account_health] || 'bg-green-500'}`}
                      title={client.account_health || 'Green'}
                    />
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button onClick={e => { e.stopPropagation(); handleEdit(client); }} className="p-1.5 rounded hover:bg-secondary text-muted-foreground hover:text-foreground">
                      <Edit2 size={14} />
                    </button>
                    <button onClick={e => { e.stopPropagation(); handleDelete(client.id); }} className="p-1.5 rounded hover:bg-red-50 text-muted-foreground hover:text-red-600">
                      <Trash2 size={14} />
                    </button>
                    {expandedId === client.id ? <ChevronUp size={14} className="text-muted-foreground" /> : <ChevronDown size={14} className="text-muted-foreground" />}
                  </div>
                </div>

                {expandedId === client.id && (
                  <div className="bg-secondary/20 border-t border-border">
                    {/* Tab bar */}
                    <div className="flex border-b border-border px-5 pt-3 gap-4 overflow-x-auto">
                      {[
                        'details',
                        'profile',
                        'schedule',
                        ...(client.carbee_enabled ? ['carbee'] : []),
                        ...(client.inventory_enabled ? ['inventory'] : []),
                      ].map(tab => (
                        <button key={tab} onClick={() => setExpandedTab(tab)}
                          className={`pb-2 text-xs font-semibold capitalize whitespace-nowrap border-b-2 transition-colors ${expandedTab === tab ? 'border-accent text-accent' : 'border-transparent text-muted-foreground hover:text-foreground'}`}>
                          {tab === 'carbee' ? 'CarBee' : tab === 'inventory' ? 'Inventory Photography' : tab}
                        </button>
                      ))}
                    </div>

                    {expandedTab === 'details' && (
                      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 px-5 pt-4 pb-5">
                        {/* Contacts */}
                        {contacts.filter(c => c.client === client.id).map(c => (
                          <div key={c.id} className="sm:col-span-2 lg:col-span-1 bg-secondary/30 rounded-lg px-3 py-2.5 space-y-1">
                            <div className="text-xs font-semibold text-foreground">{c.full_name}{c.is_primary && <span className="ml-1.5 text-[10px] bg-accent/10 text-accent px-1.5 py-0.5 rounded font-medium">Primary</span>}</div>
                            {c.position && <div className="text-xs text-muted-foreground">{c.position}</div>}
                            {c.phone && <div className="text-xs text-foreground"><a href={`tel:${c.phone}`} className="hover:text-accent transition-colors">{c.phone}</a></div>}
                            {c.email && <div className="text-xs text-foreground"><a href={`mailto:${c.email}`} className="hover:text-accent transition-colors">{c.email}</a></div>}
                          </div>
                        ))}
                        <div>
                          <div className="text-xs font-medium text-muted-foreground mb-1">Filming Cadence</div>
                          <div className="text-xs text-foreground">{client.filming_cadence || '—'}</div>
                        </div>
                        <div>
                          <div className="text-xs font-medium text-muted-foreground mb-1">Cycle Start Date</div>
                          {client.cycle_start_date
                            ? <div className="text-xs text-foreground font-medium">{client.cycle_start_date}</div>
                            : <div className="text-xs text-red-600 font-medium flex items-center gap-1"><AlertTriangle size={11} /> No cycle start date</div>
                          }
                        </div>
                        {client.add_ons?.length > 0 && (
                          <div>
                            <div className="text-xs font-medium text-muted-foreground mb-1">Add-ons</div>
                            <div className="flex flex-wrap gap-1">
                              {client.add_ons.map(a => (
                                <span key={a} className="text-xs bg-secondary px-2 py-0.5 rounded text-foreground">{a}</span>
                              ))}
                            </div>
                          </div>
                        )}
                        {client.content_notes && (
                          <div className="sm:col-span-2">
                            <div className="text-xs font-medium text-muted-foreground mb-1">Content Notes</div>
                            <p className="text-xs text-foreground">{client.content_notes}</p>
                          </div>
                        )}
                      </div>
                    )}

                    {expandedTab === 'profile' && (
                      <div className="px-5 py-4">
                        <ClientAboutTabs client={client} onClientUpdate={load} />
                      </div>
                    )}

                    {expandedTab === 'schedule' && (
                      <div className="px-5 py-4">
                        <ClientScheduleTab client={client} />
                      </div>
                    )}

                    {expandedTab === 'carbee' && client.carbee_enabled && (
                      <div className="px-5 py-4">
                        <CarBeeTab client={client} employees={employees} onClientUpdate={load} />
                      </div>
                    )}

                    {expandedTab === 'inventory' && client.inventory_enabled && (
                      <div className="px-5 py-4">
                        <InventoryPhotographyTab client={client} employees={employees} onClientUpdate={load} />
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {modalOpen && (
        <ClientModal
          client={editingClient}
          employees={employees}
          onSave={handleSave}
          onClose={() => { setModalOpen(false); setEditingClient(null); }}
        />
      )}
    </div>
  );
}