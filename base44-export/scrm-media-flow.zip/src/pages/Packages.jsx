import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, Pencil, Trash2, Save, X, AlertTriangle, ChevronDown, ChevronUp, Users } from 'lucide-react';
import { BLOCK_TYPES, DEFAULT_DURATION } from '@/lib/calendarBlocks';
import { SYSTEM_PACKAGES } from '@/lib/packageDefaults';
import AddOnsConfig from '@/components/packages/AddOnsConfig';

export default function Packages() {
  const [tab, setTab] = useState('social');
  const [packages, setPackages] = useState([]);
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState(null);
  const [showCreate, setShowCreate] = useState(false);
  const [savedNotice, setSavedNotice] = useState(null);

  const load = async () => {
    let [pkgs, cs] = await Promise.all([
      base44.entities.Package.list(),
      base44.entities.Client.list(),
    ]);
    // Seed system packages if missing
    const existingNames = new Set(pkgs.map(p => p.name));
    const toSeed = SYSTEM_PACKAGES.filter(sp => !existingNames.has(sp.name));
    if (toSeed.length > 0) {
      await Promise.all(toSeed.map(sp => base44.entities.Package.create(sp)));
      pkgs = await base44.entities.Package.list();
    }
    setPackages(pkgs);
    setClients(cs);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const handleSave = async (pkg) => {
    if (pkg.id) {
      await base44.entities.Package.update(pkg.id, { name: pkg.name, blocks: pkg.blocks });
    } else {
      await base44.entities.Package.create({ name: pkg.name, blocks: pkg.blocks, is_system: false });
    }
    setEditingId(null);
    setShowCreate(false);
    setSavedNotice('Changes will apply to new blocks only. Existing blocks are unchanged.');
    setTimeout(() => setSavedNotice(null), 5000);
    load();
  };

  const handleDelete = async (pkg) => {
    if (!confirm(`Delete package "${pkg.name}"? This cannot be undone.`)) return;
    await base44.entities.Package.delete(pkg.id);
    load();
  };

  const getClientCount = (pkgName) =>
    clients.filter(c => c.package === pkgName && (c.status === 'Active' || c.status === 'Onboarding')).length;

  if (loading) return (
    <div className="flex justify-center items-center h-64">
      <div className="w-7 h-7 border-2 border-border border-t-accent rounded-full animate-spin" />
    </div>
  );

  // Filter out internal config records from the social packages list
  const socialPackages = packages.filter(p => p.name !== '__add_ons_config__');

  return (
    <div className="p-4 sm:p-6 max-w-3xl mx-auto space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-dm font-bold text-foreground tracking-tight">Packages</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Define block types, durations, and add-on configurations</p>
        </div>
        {tab === 'social' && !showCreate && (
          <button
            onClick={() => setShowCreate(true)}
            className="flex items-center gap-2 px-4 py-2 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accent/90 transition-colors"
          >
            <Plus size={16} /> New Package
          </button>
        )}
      </div>

      {/* Tabs */}
      <div className="flex border-b border-border gap-4">
        {['social', 'add-ons'].map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`pb-2 text-sm font-semibold capitalize border-b-2 transition-colors -mb-px ${tab === t ? 'border-accent text-accent' : 'border-transparent text-muted-foreground hover:text-foreground'}`}>
            {t === 'social' ? 'Social Packages' : 'Add-Ons'}
          </button>
        ))}
      </div>

      {savedNotice && (
        <div className="flex items-center gap-2 bg-amber-50 border border-amber-200 rounded-xl px-4 py-3">
          <AlertTriangle size={15} className="text-amber-600 shrink-0" />
          <span className="text-sm text-amber-800 font-medium">{savedNotice}</span>
        </div>
      )}

      {tab === 'social' && (
        <>
          {showCreate && (
            <PackageEditor
              pkg={{ name: '', blocks: [] }}
              onSave={handleSave}
              onCancel={() => setShowCreate(false)}
              isNew
            />
          )}
          <div className="space-y-3">
            {socialPackages.map(pkg => (
              editingId === pkg.id ? (
                <PackageEditor
                  key={pkg.id}
                  pkg={pkg}
                  onSave={handleSave}
                  onCancel={() => setEditingId(null)}
                />
              ) : (
                <PackageCard
                  key={pkg.id}
                  pkg={pkg}
                  clientCount={getClientCount(pkg.name)}
                  onEdit={() => setEditingId(pkg.id)}
                  onDelete={() => handleDelete(pkg)}
                />
              )
            ))}
          </div>
        </>
      )}

      {tab === 'add-ons' && <AddOnsConfig />}
    </div>
  );
}

function PackageCard({ pkg, clientCount, onEdit, onDelete }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden shadow-sm">
      <div className="flex items-center justify-between px-5 py-4">
        <div className="flex items-center gap-3">
          <button onClick={() => setExpanded(e => !e)} className="text-muted-foreground hover:text-foreground transition-colors">
            {expanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
          </button>
          <div>
            <div className="font-dm font-bold text-foreground">{pkg.name}</div>
            <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
              <span>{(pkg.blocks || []).length} block type{(pkg.blocks || []).length !== 1 ? 's' : ''}{pkg.is_system ? ' · System package' : ''}</span>
              <span className="flex items-center gap-1 text-primary font-medium">
                <Users size={11} /> {clientCount} active client{clientCount !== 1 ? 's' : ''}
              </span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <button onClick={onEdit} className="p-2 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"><Pencil size={15} /></button>
          {!pkg.is_system && (
            <button onClick={onDelete} className="p-2 rounded-lg hover:bg-red-50 text-muted-foreground hover:text-red-600 transition-colors"><Trash2 size={15} /></button>
          )}
        </div>
      </div>
      {expanded && (pkg.blocks || []).length > 0 && (
        <div className="border-t border-border divide-y divide-border/50">
          {pkg.blocks.map((b, i) => (
            <div key={i} className="flex items-center justify-between px-5 py-2.5 text-sm">
              <span className="text-foreground">{b.block_type}</span>
              <div className="flex items-center gap-4 text-muted-foreground text-xs">
                {b.role && <span className="text-primary/70">{b.role}</span>}
                <span>{b.duration_minutes} min</span>
                <span>{b.repeat_frequency}{b.week_of_month ? ` (${b.week_of_month})` : b.week ? ` (${b.week})` : ''}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function PackageEditor({ pkg, onSave, onCancel, isNew }) {
  const [name, setName] = useState(pkg.name);
  const [blocks, setBlocks] = useState(pkg.blocks || []);
  const [saving, setSaving] = useState(false);

  const addBlock = () => {
    setBlocks(b => [...b, {
      block_type: BLOCK_TYPES[0],
      duration_minutes: DEFAULT_DURATION[BLOCK_TYPES[0]] || 60,
      repeat_frequency: 'Weekly',
      role: '',
      week_of_month: 'Any',
    }]);
  };

  const updateBlock = (i, field, value) => {
    setBlocks(b => b.map((bl, idx) => {
      if (idx !== i) return bl;
      const updated = { ...bl, [field]: value };
      if (field === 'block_type') updated.duration_minutes = DEFAULT_DURATION[value] || 60;
      return updated;
    }));
  };

  const removeBlock = (i) => setBlocks(b => b.filter((_, idx) => idx !== i));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!name.trim()) return;
    setSaving(true);
    await onSave({ ...pkg, name: name.trim(), blocks });
    setSaving(false);
  };

  return (
    <form onSubmit={handleSubmit} className="bg-card border border-accent/40 rounded-xl shadow-sm overflow-hidden">
      <div className="px-5 py-4 border-b border-border bg-accent/5">
        <div className="flex items-center gap-3">
          <input
            value={name}
            onChange={e => setName(e.target.value)}
            className="input-base font-dm font-bold text-foreground flex-1"
            placeholder="Package name..."
            disabled={pkg.is_system}
            required
          />
          {pkg.is_system && <span className="text-xs text-muted-foreground shrink-0">System package — name locked</span>}
        </div>
      </div>

      <div className="px-5 py-4 space-y-3">
        <div className="text-xs font-medium text-muted-foreground mb-2 uppercase tracking-wide">Block Types</div>
        {blocks.length === 0 && (
          <p className="text-sm text-muted-foreground italic">No blocks yet — add one below.</p>
        )}
        {blocks.map((b, i) => (
          <div key={i} className="border border-border rounded-lg p-3 space-y-2">
            <div className="flex items-center gap-2">
              <select value={b.block_type} onChange={e => updateBlock(i, 'block_type', e.target.value)} className="input-base flex-1 text-sm">
                {BLOCK_TYPES.map(t => <option key={t}>{t}</option>)}
              </select>
              <button type="button" onClick={() => removeBlock(i)} className="p-1.5 rounded-lg hover:bg-red-50 text-muted-foreground hover:text-red-600 transition-colors">
                <X size={14} />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="flex items-center gap-1">
                <input type="number" value={b.duration_minutes} onChange={e => updateBlock(i, 'duration_minutes', parseInt(e.target.value) || 0)} className="input-base text-sm" min="5" />
                <span className="text-xs text-muted-foreground shrink-0">min</span>
              </div>
              <select value={b.repeat_frequency} onChange={e => updateBlock(i, 'repeat_frequency', e.target.value)} className="input-base text-sm">
                {['Weekly', 'Fortnightly', 'Monthly'].map(r => <option key={r}>{r}</option>)}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs text-muted-foreground">Role</label>
                <select value={b.role || ''} onChange={e => updateBlock(i, 'role', e.target.value)} className="input-base text-sm mt-0.5">
                  <option value="">Any</option>
                  {['Videographer', 'Editor', 'Social Media Manager', 'Marketing Manager', 'Operations Manager', 'Founder'].map(r => <option key={r}>{r}</option>)}
                </select>
              </div>
              {b.repeat_frequency === 'Monthly' && (
                <div>
                  <label className="text-xs text-muted-foreground">Week of month</label>
                  <select value={b.week_of_month || 'Any'} onChange={e => updateBlock(i, 'week_of_month', e.target.value)} className="input-base text-sm mt-0.5">
                    <option value="Any">Any (cycle start)</option>
                    <option value="before">Week 0 (week before cycle)</option>
                    <option value="first">Week 1 (cycle start week)</option>
                  </select>
                </div>
              )}
            </div>
          </div>
        ))}

        <button type="button" onClick={addBlock}
          className="flex items-center gap-1.5 text-sm text-accent hover:text-accent/80 font-medium mt-2 transition-colors">
          <Plus size={14} /> Add Block Type
        </button>
      </div>

      <div className="px-5 py-4 border-t border-border flex gap-2 justify-end">
        <button type="button" onClick={onCancel}
          className="px-4 py-2 border border-border rounded-lg text-sm font-medium text-muted-foreground hover:bg-secondary transition-colors">
          Cancel
        </button>
        <button type="submit" disabled={saving}
          className="flex items-center gap-2 px-4 py-2 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accent/90 disabled:opacity-50 transition-colors">
          <Save size={14} /> {saving ? 'Saving...' : 'Save Package'}
        </button>
      </div>
    </form>
  );
}