import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, Search, Edit2, Trash2, Phone, Mail, MapPin } from 'lucide-react';
import PageHeader from '@/components/ui/PageHeader';
import EmployeeModal from '@/components/employees/EmployeeModal';

const roleColors = {
  'Social Media Manager': 'bg-blue-100 text-blue-700',
  'Editor': 'bg-purple-100 text-purple-700',
  'Content Creator': 'bg-teal-100 text-teal-700',
  'Marketing Manager': 'bg-orange-100 text-orange-700',
  'Operations Manager': 'bg-indigo-100 text-indigo-700',
  'Founder': 'bg-pink-100 text-pink-700',
};

const roleInitials = (role) => {
  const map = {
    'Social Media Manager': 'SM',
    'Editor': 'ED',
    'Content Creator': 'CC',
    'Marketing Manager': 'MM',
    'Operations Manager': 'OP',
    'Founder': 'FO',
  };
  return map[role] || '??';
};

export default function Employees() {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterRegion, setFilterRegion] = useState('All');
  const [filterRole, setFilterRole] = useState('All');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState(null);

  const load = () => {
    base44.entities.Employee.list().then(data => {
      setEmployees(data);
      setLoading(false);
    });
  };

  useEffect(() => { load(); }, []);

  const filtered = employees.filter(e => {
    const matchSearch = e.name?.toLowerCase().includes(search.toLowerCase()) ||
      e.email?.toLowerCase().includes(search.toLowerCase());
    const matchRegion = filterRegion === 'All' || e.region === filterRegion;
    const matchRole = filterRole === 'All' || e.role === filterRole;
    return matchSearch && matchRegion && matchRole;
  });

  const handleSave = async (data) => {
    if (editingEmployee) {
      await base44.entities.Employee.update(editingEmployee.id, data);
    } else {
      await base44.entities.Employee.create(data);
    }
    setModalOpen(false);
    setEditingEmployee(null);
    load();
  };

  const handleDelete = async (id) => {
    if (!confirm('Remove this employee?')) return;
    await base44.entities.Employee.delete(id);
    load();
  };

  const byRegion = {};
  filtered.forEach(e => {
    const r = e.region || 'Unassigned';
    if (!byRegion[r]) byRegion[r] = [];
    byRegion[r].push(e);
  });

  return (
    <div className="p-6 lg:p-8 max-w-7xl mx-auto">
      <PageHeader
        title="Team"
        subtitle={`${employees.length} team members`}
        action={
          <button
            onClick={() => { setEditingEmployee(null); setModalOpen(true); }}
            className="flex items-center gap-2 bg-accent text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-accent/90 transition-colors"
          >
            <Plus size={16} /> Add Employee
          </button>
        }
      />

      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-6">
        <div className="relative flex-1 min-w-48">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search team..."
            className="w-full pl-9 pr-3 py-2 text-sm border border-border rounded-lg bg-card focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
        <select value={filterRegion} onChange={e => setFilterRegion(e.target.value)}
          className="px-3 py-2 text-sm border border-border rounded-lg bg-card focus:outline-none">
          {['All', 'Melbourne', 'Sydney', 'Brisbane', 'Perth', 'Newcastle'].map(r => <option key={r}>{r}</option>)}
        </select>
        <select value={filterRole} onChange={e => setFilterRole(e.target.value)}
          className="px-3 py-2 text-sm border border-border rounded-lg bg-card focus:outline-none">
          <option value="All">All Roles</option>
          {['Social Media Manager', 'Editor', 'Content Creator', 'Marketing Manager', 'Operations Manager', 'Founder'].map(r => <option key={r}>{r}</option>)}
        </select>
      </div>

      {loading ? (
        <div className="flex justify-center py-16">
          <div className="w-7 h-7 border-2 border-border border-t-accent rounded-full animate-spin" />
        </div>
      ) : (
        <div className="space-y-6">
          {Object.entries(byRegion).map(([region, emps]) => (
            <div key={region}>
              <div className="flex items-center gap-2 mb-3">
                <MapPin size={14} className="text-muted-foreground" />
                <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">{region}</h2>
                <span className="text-xs text-muted-foreground">({emps.length})</span>
              </div>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {emps.map(emp => (
                  <div key={emp.id} className="bg-card rounded-xl border border-border p-4 shadow-sm hover:shadow-md transition-all group">
                    <div className="flex items-start gap-3">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-xs font-bold shrink-0 ${roleColors[emp.role] || 'bg-gray-100 text-gray-600'}`}>
                        {roleInitials(emp.role)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-dm font-semibold text-foreground text-sm truncate">{emp.name}</div>
                        <div className="text-xs text-muted-foreground truncate">{emp.role}</div>
                      </div>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => { setEditingEmployee(emp); setModalOpen(true); }}
                          className="p-1.5 rounded hover:bg-secondary text-muted-foreground hover:text-foreground">
                          <Edit2 size={13} />
                        </button>
                        <button onClick={() => handleDelete(emp.id)}
                          className="p-1.5 rounded hover:bg-red-50 text-muted-foreground hover:text-red-600">
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </div>
                    {(emp.email || emp.phone) && (
                      <div className="mt-3 pt-3 border-t border-border space-y-1">
                        {emp.email && (
                          <a href={`mailto:${emp.email}`} className="flex items-center gap-2 text-xs text-muted-foreground hover:text-accent transition-colors">
                            <Mail size={12} /> {emp.email}
                          </a>
                        )}
                        {emp.phone && (
                          <a href={`tel:${emp.phone}`} className="flex items-center gap-2 text-xs text-muted-foreground hover:text-accent transition-colors">
                            <Phone size={12} /> {emp.phone}
                          </a>
                        )}
                        {emp.address && (
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <MapPin size={12} className="shrink-0" /> {emp.address}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ))}
          {filtered.length === 0 && (
            <div className="py-16 text-center text-sm text-muted-foreground">No team members found</div>
          )}
        </div>
      )}

      {modalOpen && (
        <EmployeeModal
          employee={editingEmployee}
          onSave={handleSave}
          onClose={() => { setModalOpen(false); setEditingEmployee(null); }}
        />
      )}
    </div>
  );
}