import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';
import { AlertTriangle, Calendar, CheckCircle2, Clock, TrendingUp, Users, ArrowRight, ClipboardList } from 'lucide-react';
import StatusBadge, { healthColors, clientStatusColors, contentStatusColors } from '@/components/ui/StatusBadge';
import PageHeader from '@/components/ui/PageHeader';

export default function Dashboard() {
  const [clients, setClients] = useState([]);
  const [contentItems, setContentItems] = useState([]);
  const [meetings, setMeetings] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      base44.entities.Client.list(),
      base44.entities.ContentItem.list('-updated_date', 200),
      base44.entities.PlanningMeeting.list('-meeting_date', 20),
    ]).then(([c, ci, m]) => {
      setClients(c);
      setContentItems(ci);
      setMeetings(m);
      setLoading(false);
    });
  }, []);

  const activeClients = clients.filter(c => c.status === 'Active');
  const atRiskClients = clients.filter(c => c.account_health === 'Red');
  const amberClients = clients.filter(c => c.account_health === 'Amber');
  const inProgressContent = contentItems.filter(c => !['Published', 'Planned'].includes(c.status));
  const upcomingMeetings = meetings.filter(m => m.status === 'Scheduled').slice(0, 5);
  const monthlyRevenue = activeClients.reduce((sum, c) => sum + (c.monthly_value || 0), 0);

  const today = new Date().toISOString().split('T')[0];
  const overdueShoots = contentItems.filter(c =>
    c.scheduled_date && c.scheduled_date < today && c.status !== 'Published'
  );

  const statCards = [
    { label: 'Active Clients', value: activeClients.length, icon: Users, color: 'text-blue-600', bg: 'bg-blue-50' },
    { label: 'Monthly Revenue', value: `$${monthlyRevenue.toLocaleString()}`, icon: TrendingUp, color: 'text-green-600', bg: 'bg-green-50' },
    { label: 'Content In Production', value: inProgressContent.length, icon: Clock, color: 'text-purple-600', bg: 'bg-purple-50' },
    { label: 'At-Risk Accounts', value: atRiskClients.length, icon: AlertTriangle, color: 'text-red-600', bg: 'bg-red-50' },
  ];

  if (loading) return (
    <div className="p-8 flex items-center justify-center h-64">
      <div className="w-7 h-7 border-3 border-border border-t-accent rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="p-6 lg:p-8 max-w-7xl mx-auto">
      <PageHeader
        title="Good morning 👋"
        subtitle={`Here's what needs attention today — ${new Date().toLocaleDateString('en-AU', { weekday: 'long', day: 'numeric', month: 'long' })}`}
      />

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {statCards.map(({ label, value, icon: Icon, color, bg }) => (
          <div key={label} className="bg-card rounded-xl p-5 border border-border shadow-sm">
            <div className={`w-9 h-9 ${bg} rounded-lg flex items-center justify-center mb-3`}>
              <Icon size={18} className={color} />
            </div>
            <div className="text-2xl font-dm font-bold text-foreground">{value}</div>
            <div className="text-xs text-muted-foreground mt-0.5">{label}</div>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Attention needed */}
        <div className="lg:col-span-2 space-y-4">
          {/* At-risk clients */}
          {(atRiskClients.length > 0 || amberClients.length > 0) && (
            <div className="bg-card rounded-xl border border-border shadow-sm">
              <div className="px-5 py-4 border-b border-border flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <AlertTriangle size={16} className="text-red-500" />
                  <h2 className="font-dm font-semibold text-sm text-foreground">Account Health Alerts</h2>
                </div>
                <Link to="/clients" className="text-xs text-accent hover:underline flex items-center gap-1">
                  All clients <ArrowRight size={12} />
                </Link>
              </div>
              <div className="divide-y divide-border">
                {[...atRiskClients, ...amberClients].slice(0, 6).map(client => (
                  <div key={client.id} className="px-5 py-3 flex items-center justify-between">
                    <div>
                      <div className="text-sm font-medium text-foreground">{client.name}</div>
                      <div className="text-xs text-muted-foreground">{client.location} · {client.package}</div>
                    </div>
                    <StatusBadge label={client.account_health} colorMap={healthColors} />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Overdue content */}
          {overdueShoots.length > 0 && (
            <div className="bg-card rounded-xl border border-border shadow-sm">
              <div className="px-5 py-4 border-b border-border flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Clock size={16} className="text-amber-500" />
                  <h2 className="font-dm font-semibold text-sm text-foreground">Overdue Content</h2>
                </div>
                <Link to="/social-calendar" className="text-xs text-accent hover:underline flex items-center gap-1">
                  View all <ArrowRight size={12} />
                </Link>
              </div>
              <div className="divide-y divide-border">
                {overdueShoots.slice(0, 5).map(item => {
                  const client = clients.find(c => c.id === item.client);
                  return (
                    <div key={item.id} className="px-5 py-3 flex items-center justify-between">
                      <div>
                        <div className="text-sm font-medium text-foreground">{item.title}</div>
                        <div className="text-xs text-muted-foreground">{client?.name || '—'} · Due {item.scheduled_date}</div>
                      </div>
                      <StatusBadge label={item.status} colorMap={contentStatusColors} />
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* In-production content */}
          <div className="bg-card rounded-xl border border-border shadow-sm">
            <div className="px-5 py-4 border-b border-border flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle2 size={16} className="text-purple-500" />
                <h2 className="font-dm font-semibold text-sm text-foreground">Content In Production</h2>
              </div>
              <Link to="/social-calendar" className="text-xs text-accent hover:underline flex items-center gap-1">
                View all <ArrowRight size={12} />
              </Link>
            </div>
            {inProgressContent.length === 0 ? (
              <div className="px-5 py-8 text-center text-sm text-muted-foreground">No content in production</div>
            ) : (
              <div className="divide-y divide-border">
                {inProgressContent.slice(0, 6).map(item => {
                  const client = clients.find(c => c.id === item.client);
                  return (
                    <div key={item.id} className="px-5 py-3 flex items-center justify-between">
                      <div>
                        <div className="text-sm font-medium text-foreground">{item.title}</div>
                        <div className="text-xs text-muted-foreground">{client?.name || '—'} · {item.content_type}</div>
                      </div>
                      <StatusBadge label={item.status} colorMap={contentStatusColors} />
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Upcoming meetings */}
        <div>
          <div className="bg-card rounded-xl border border-border shadow-sm">
            <div className="px-5 py-4 border-b border-border flex items-center gap-2">
              <Calendar size={16} className="text-accent" />
              <h2 className="font-dm font-semibold text-sm text-foreground">Upcoming Planning Meetings</h2>
            </div>
            {upcomingMeetings.length === 0 ? (
              <div className="px-5 py-8 text-center text-sm text-muted-foreground">No upcoming meetings</div>
            ) : (
              <div className="divide-y divide-border">
                {upcomingMeetings.map(meeting => {
                  const client = clients.find(c => c.id === meeting.client);
                  return (
                    <div key={meeting.id} className="px-5 py-4">
                      <div className="text-sm font-medium text-foreground">{client?.name || '—'}</div>
                      <div className="text-xs text-muted-foreground mt-0.5">{meeting.month}</div>
                      {meeting.meeting_date && (
                        <div className="text-xs text-accent mt-1 font-medium">
                          {new Date(meeting.meeting_date).toLocaleDateString('en-AU', { day: 'numeric', month: 'short' })}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Onboarding clients */}
          <div className="bg-card rounded-xl border border-border shadow-sm mt-4">
            <div className="px-5 py-4 border-b border-border flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ClipboardList size={16} className="text-blue-500" />
                <h2 className="font-dm font-semibold text-sm text-foreground">Onboarding</h2>
              </div>
              <Link to="/onboarding" className="text-xs text-accent hover:underline flex items-center gap-1">
                View <ArrowRight size={12} />
              </Link>
            </div>
            {clients.filter(c => c.status === 'Onboarding').length === 0 ? (
              <div className="px-5 py-8 text-center text-sm text-muted-foreground">No active onboarding</div>
            ) : (
              <div className="divide-y divide-border">
                {clients.filter(c => c.status === 'Onboarding').map(client => (
                  <div key={client.id} className="px-5 py-3 flex items-center justify-between">
                    <div className="text-sm font-medium text-foreground">{client.name}</div>
                    <StatusBadge label={client.package} colorMap={{}} />
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}