import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import OnboardingHub from '@/components/onboarding/OnboardingHub.jsx';
import OnboardingWizard from '@/components/onboarding/OnboardingWizard.jsx';

export default function Onboarding() {
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [wizardClient, setWizardClient] = useState(null);
  const [startingNew, setStartingNew] = useState(false);

  const load = () => {
    base44.entities.Client.filter({ status: 'Onboarding' }).then(data => {
      setClients(data);
      setLoading(false);
    });
  };

  useEffect(() => { load(); }, []);

  const handleStartNew = () => {
    setWizardClient(null);
    setStartingNew(true);
  };

  const handleContinue = (client) => {
    setWizardClient(client);
    setStartingNew(false);
  };

  const handleWizardClose = () => {
    setWizardClient(null);
    setStartingNew(false);
    load();
  };

  const handleDelete = async (client) => {
    if (!confirm(`Delete the onboarding for "${client.name}"? This will permanently delete the client record.`)) return;
    await base44.entities.Client.delete(client.id);
    load();
  };

  const handleClientActivated = () => {
    setWizardClient(null);
    setStartingNew(false);
    load();
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="w-7 h-7 border-2 border-border border-t-accent rounded-full animate-spin" />
      </div>
    );
  }

  if (startingNew || wizardClient) {
    return (
      <OnboardingWizard
        client={wizardClient}
        onClose={handleWizardClose}
        onActivated={handleClientActivated}
        onClientCreated={(c) => { setWizardClient(c); setStartingNew(false); }}
      />
    );
  }

  return (
    <OnboardingHub
      clients={clients}
      onStartNew={handleStartNew}
      onContinue={handleContinue}
      onDelete={handleDelete}
    />
  );
}