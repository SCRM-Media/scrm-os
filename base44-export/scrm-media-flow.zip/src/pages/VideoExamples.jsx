import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, ExternalLink, Trash2, Edit2, X, Check } from 'lucide-react';
import { ALL_CONTENT_TYPES } from '@/lib/contentTypes';

function ExampleModal({ example, onSave, onClose }) {
  const [form, setForm] = useState(example || { content_type: ALL_CONTENT_TYPES[0], title: '', video_url: '', notes: '' });
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-card rounded-2xl border border-border shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between px-5 py-4 border-b border-border">
          <h3 className="font-dm font-bold text-foreground">{example ? 'Edit Example' : 'Add Example'}</h3>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X size={18} /></button>
        </div>
        <div className="px-5 py-5 space-y-4">
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Content Type</label>
            <select value={form.content_type} onChange={e => set('content_type', e.target.value)} className="input-base">
              {ALL_CONTENT_TYPES.map(t => <option key={t}>{t}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Title</label>
            <input value={form.title} onChange={e => set('title', e.target.value)} className="input-base" placeholder="Short descriptive title" />
          </div>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Video URL</label>
            <input value={form.video_url} onChange={e => set('video_url', e.target.value)} className="input-base" placeholder="https://..." />
          </div>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Notes</label>
            <textarea value={form.notes} onChange={e => set('notes', e.target.value)} className="input-base resize-none h-24" placeholder="Additional notes about this example..." />
          </div>
        </div>
        <div className="flex gap-2 px-5 pb-5">
          <button onClick={() => onSave(form)} className="flex-1 py-2 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accent/90">Save</button>
          <button onClick={onClose} className="px-4 py-2 border border-border rounded-lg text-sm text-muted-foreground hover:bg-secondary">Cancel</button>
        </div>
      </div>
    </div>
  );
}

export default function VideoExamples() {
  const [examples, setExamples] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(null); // null | 'new' | example object
  const [filterType, setFilterType] = useState('');

  const load = async () => {
    const data = await base44.entities.ContentTypeExample.list('-created_date', 200);
    setExamples(data);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const handleSave = async (form) => {
    if (modal && modal.id) {
      await base44.entities.ContentTypeExample.update(modal.id, form);
    } else {
      await base44.entities.ContentTypeExample.create(form);
    }
    setModal(null);
    load();
  };

  const handleDelete = async (id) => {
    if (!confirm('Delete this example?')) return;
    await base44.entities.ContentTypeExample.delete(id);
    load();
  };

  const filtered = filterType ? examples.filter(e => e.content_type === filterType) : examples;

  return (
    <div className="p-4 lg:p-8 max-w-4xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-dm font-bold text-2xl text-foreground">Video Examples Library</h1>
          <p className="text-sm text-muted-foreground mt-1">Manage reference videos per content type — shown in content item detail.</p>
        </div>
        <button onClick={() => setModal('new')}
          className="flex items-center gap-2 bg-accent text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-accent/90 transition-colors">
          <Plus size={15} /> Add Example
        </button>
      </div>

      <div className="mb-4">
        <select value={filterType} onChange={e => setFilterType(e.target.value)} className="input-base max-w-xs">
          <option value="">All Content Types</option>
          {ALL_CONTENT_TYPES.map(t => <option key={t}>{t}</option>)}
        </select>
      </div>

      {loading ? (
        <div className="flex justify-center py-12">
          <div className="w-7 h-7 border-2 border-border border-t-accent rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground text-sm">
          No examples yet. Add the first one above.
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map(ex => (
            <div key={ex.id} className="bg-card border border-border rounded-xl px-5 py-4 flex items-start gap-4">
              <div className="flex-1 min-w-0">
                <div className="text-xs font-medium text-accent mb-0.5">{ex.content_type}</div>
                <div className="font-medium text-foreground">{ex.title}</div>
                {ex.video_url && (
                  <a href={ex.video_url} target="_blank" rel="noreferrer"
                    className="flex items-center gap-1 text-xs text-accent hover:underline mt-1">
                    <ExternalLink size={11} /> {ex.video_url}
                  </a>
                )}
                {ex.notes && <p className="text-xs text-muted-foreground mt-1">{ex.notes}</p>}
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <button onClick={() => setModal(ex)} className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors">
                  <Edit2 size={14} />
                </button>
                <button onClick={() => handleDelete(ex.id)} className="p-1.5 rounded-lg hover:bg-red-50 text-muted-foreground hover:text-red-600 transition-colors">
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {modal && (
        <ExampleModal
          example={modal === 'new' ? null : modal}
          onSave={handleSave}
          onClose={() => setModal(null)}
        />
      )}
    </div>
  );
}