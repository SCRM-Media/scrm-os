import { useState, useEffect, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { Users, ChevronLeft, ChevronRight } from 'lucide-react';
import { computeInstancesForRange, dateToStr, addDays } from '@/lib/cycleEngine';
import MultiSelectDropdown from '@/components/calendar/MultiSelectDropdown';
import CalendarLegend from '@/components/calendar/CalendarLegend';
import RuleWeekTimeGrid from '@/components/calendar/RuleWeekTimeGrid';
import RuleMonthView from '@/components/calendar/RuleMonthView';
import BlockRuleDetailPanel from '@/components/calendar/BlockRuleDetailPanel';
import CycleView from '@/components/calendar/CycleView';

function getWeekDates(baseDate) {
  const d = new Date(baseDate);
  if (isNaN(d.getTime())) {
    // fallback to current week if invalid date
    const now = new Date();
    return getWeekDates(now);
  }
  const dow = d.getDay();
  const daysToMon = dow === 0 ? 6 : dow - 1;
  d.setDate(d.getDate() - daysToMon);
  d.setHours(0, 0, 0, 0);
  return Array.from({ length: 7 }, (_, i) => {
    const day = new Date(d);
    day.setDate(d.getDate() + i);
    return day;
  });
}

export default function EmployeeCalendar() {
  const [clients, setClients] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [rules, setRules] = useState([]);
  const [exceptions, setExceptions] = useState([]);
  const [loading, setLoading] = useState(true);

  const [view, setView] = useState('week');
  const [weekBase, setWeekBase] = useState(new Date());
  const [monthBase, setMonthBase] = useState(new Date());

  const [selectedEmployees, setSelectedEmployees] = useState(new Set());
  const [filterClients, setFilterClients] = useState(new Set());
  const [filterBlockTypes, setFilterBlockTypes] = useState(new Set());
  const [filterState, setFilterState] = useState('all');

  const [selectedInstance, setSelectedInstance] = useState(null);
  const [dstView, setDstView] = useState(false);

  const load = async () => {
    const [cls, emps, rls, excs] = await Promise.all([
      base44.entities.Client.list(),
      base44.entities.Employee.list(),
      base44.entities.BlockRule.list(),
      base44.entities.BlockException.list(),
    ]);
    setClients(cls);
    setEmployees(emps);
    setRules(rls);
    setExceptions(excs);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const clientsMap = useMemo(() => Object.fromEntries(clients.map(c => [c.id, c])), [clients]);
  const employeesMap = useMemo(() => Object.fromEntries(employees.map(e => [e.id, e])), [employees]);

  const weekDates = useMemo(() => getWeekDates(weekBase), [weekBase]);
  const weekStart = dateToStr(weekDates[0]);
  const weekEnd = dateToStr(weekDates[6]);
  const monthStart = dateToStr(new Date(monthBase.getFullYear(), monthBase.getMonth(), 1));
  const monthEnd = dateToStr(new Date(monthBase.getFullYear(), monthBase.getMonth() + 1, 0));

  const rangeStart = view === 'month' ? monthStart : weekStart;
  const rangeEnd = view === 'month' ? monthEnd : weekEnd;

  // Compute all instances for the visible range
  const allInstances = useMemo(() => {
    // Group rules by client for cycle start date lookup
    const result = [];
    rules.forEach(rule => {
      const client = clientsMap[rule.client];
      if (!client) return;
      const clientExceptions = exceptions.filter(e => e.block_rule === rule.id);
      const instances = computeInstancesForRange([rule], clientExceptions, rangeStart, rangeEnd, client.cycle_start_date);
      result.push(...instances);
    });
    return result;
  }, [rules, exceptions, rangeStart, rangeEnd, clientsMap]);

  const AU_STATES = useMemo(() =>
    [...new Set(clients.map(c => c.state).filter(Boolean))].sort()
  , [clients]);

  // Filter instances
  const visibleInstances = useMemo(() => allInstances.filter(inst => {
    if (filterClients.size > 0 && !filterClients.has(inst.client)) {
      if (!inst.is_unassigned) return false;
    }
    if (filterBlockTypes.size > 0 && !filterBlockTypes.has(inst.block_type)) return false;
    if (selectedEmployees.size > 0 && !inst.is_unassigned && !selectedEmployees.has(inst.employee)) return false;
    if (filterState !== 'all') {
      const client = clientsMap[inst.client];
      if (!client || client.state !== filterState) return false;
    }
    return true;
  }), [allInstances, filterClients, filterBlockTypes, selectedEmployees, filterState, clientsMap]);

  const unassignedRulesCount = rules.filter(r => !r.employee).length;

  // Per-employee stats when filtering to single employee
  const singleEmployee = selectedEmployees.size === 1
    ? employeesMap[[...selectedEmployees][0]]
    : null;
  const employeeClientCount = singleEmployee
    ? new Set(rules.filter(r => r.employee === singleEmployee.id).map(r => r.client)).size
    : 0;
  const employeeWeeklyMins = singleEmployee
    ? rules.filter(r => r.employee === singleEmployee.id && ['Weekly', 'Fortnightly', 'Monthly Week 0', 'Monthly Week 1'].includes(r.repeat_frequency))
        .reduce((sum, r) => {
          const multiplier = r.repeat_frequency === 'Weekly' ? 1 : r.repeat_frequency === 'Fortnightly' ? 0.5 : 0.25;
          return sum + (r.duration_minutes || 0) * multiplier;
        }, 0)
    : 0;

  const BLOCK_TYPES = [...new Set(rules.map(r => r.block_type))].sort();

  if (loading) return (
    <div className="flex justify-center items-center h-64">
      <div className="w-7 h-7 border-2 border-border border-t-accent rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="p-4 sm:p-6 space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-dm font-bold text-foreground tracking-tight">Employee Calendar</h1>
          {singleEmployee ? (
            <p className="text-sm text-muted-foreground mt-0.5">
              {singleEmployee.name} · {singleEmployee.role} · {singleEmployee.region} · {employeeClientCount} clients · ~{Math.round(employeeWeeklyMins / 60 * 10) / 10}h/wk avg
            </p>
          ) : (
            <p className="text-sm text-muted-foreground mt-0.5">All employees — rule-based scheduling</p>
          )}
        </div>
      </div>

      {/* Unassigned banner */}
      {unassignedRulesCount > 0 && (
        <div className="flex items-center gap-2 bg-blue-50 border border-blue-200 rounded-xl px-4 py-3">
          <Users size={15} className="text-blue-600 shrink-0" />
          <span className="text-sm text-blue-800 font-medium">{unassignedRulesCount} unassigned block rule{unassignedRulesCount !== 1 ? 's' : ''} across all clients</span>
        </div>
      )}

      {/* View toggle */}
      <div className="flex items-center gap-2 bg-card border border-border rounded-lg px-1 py-1 w-fit">
        {['week', 'month', 'cycle'].map(v => (
          <button key={v} onClick={() => setView(v)}
            className={`px-3 py-1.5 rounded text-sm font-medium transition-colors capitalize ${view === v ? 'bg-accent text-white' : 'text-muted-foreground hover:text-foreground'}`}>
            {v}
          </button>
        ))}
      </div>

      <CalendarLegend />

      {/* Filters + Nav */}
      <div className={`flex flex-wrap items-center gap-3 ${view === 'cycle' ? 'hidden' : ''}`}>
        {view === 'week' && (
          <div className="flex items-center gap-1 bg-card border border-border rounded-lg px-1 py-1">
            <button onClick={() => setWeekBase(d => addDays(d, -7))} className="p-1.5 rounded hover:bg-secondary text-muted-foreground transition-colors">
              <ChevronLeft size={16} />
            </button>
            <span className="text-sm font-medium text-foreground px-2 whitespace-nowrap">
              {weekDates[0].toLocaleDateString('en-AU', { day: 'numeric', month: 'short' })} –{' '}
              {weekDates[6].toLocaleDateString('en-AU', { day: 'numeric', month: 'short', year: 'numeric' })}
            </span>
            <button onClick={() => setWeekBase(d => addDays(d, 7))} className="p-1.5 rounded hover:bg-secondary text-muted-foreground transition-colors">
              <ChevronRight size={16} />
            </button>
          </div>
        )}

        <MultiSelectDropdown
          options={employees.map(e => ({ value: e.id, label: e.name }))}
          selected={selectedEmployees}
          onChange={setSelectedEmployees}
          allLabel="All Employees"
        />
        <MultiSelectDropdown
          options={clients.map(c => ({ value: c.id, label: c.name }))}
          selected={filterClients}
          onChange={setFilterClients}
          allLabel="All Clients"
        />
        <MultiSelectDropdown
          options={BLOCK_TYPES.map(t => ({ value: t, label: t.replace(' Block', '') }))}
          selected={filterBlockTypes}
          onChange={setFilterBlockTypes}
          allLabel="All Block Types"
        />
        <select value={filterState} onChange={e => setFilterState(e.target.value)}
          className="px-3 py-2 text-sm border border-border rounded-lg bg-card focus:outline-none">
          <option value="all">All States</option>
          {AU_STATES.map(s => <option key={s} value={s}>{s}</option>)}
        </select>
        <button onClick={() => setWeekBase(new Date())}
          className="px-3 py-2 text-sm border border-border rounded-lg bg-card hover:bg-secondary transition-colors text-muted-foreground">
          Today
        </button>
        <button
          onClick={() => setDstView(v => !v)}
          className={`px-3 py-2 text-sm border rounded-lg font-medium transition-colors ${dstView ? 'bg-accent text-white border-accent' : 'border-border bg-card text-muted-foreground hover:bg-secondary'}`}
          title="Toggle DST view — subtracts 1 hour for QLD/WA non-DST states"
        >
          {dstView ? 'DST −1h ON' : 'DST −1h'}
        </button>
      </div>

      {/* Calendar Views */}
      {view === 'week' && (
        <RuleWeekTimeGrid
          weekDates={weekDates}
          instances={visibleInstances}
          clientsMap={clientsMap}
          employeesMap={employeesMap}
          rules={rules}
          exceptions={exceptions}
          onSelectInstance={setSelectedInstance}
          onRefresh={load}
          dstOffsetMins={dstView ? -60 : 0}
        />
      )}
      {view === 'month' && (
        <RuleMonthView
          month={monthBase}
          instances={visibleInstances}
          clientsMap={clientsMap}
          employeesMap={employeesMap}
          onSelectInstance={setSelectedInstance}
          onPrevMonth={() => setMonthBase(d => new Date(d.getFullYear(), d.getMonth() - 1))}
          onNextMonth={() => setMonthBase(d => new Date(d.getFullYear(), d.getMonth() + 1))}
        />
      )}
      {view === 'cycle' && (
        <CycleView clients={clients} />
      )}

      {/* Block Rule Detail Panel */}
      {selectedInstance && (
        <BlockRuleDetailPanel
          instance={selectedInstance}
          clients={clients}
          employees={employees}
          rules={rules}
          exceptions={exceptions}
          clientsMap={clientsMap}
          employeesMap={employeesMap}
          onClose={() => setSelectedInstance(null)}
          onRefresh={() => { setSelectedInstance(null); load(); }}
        />
      )}
    </div>
  );
}