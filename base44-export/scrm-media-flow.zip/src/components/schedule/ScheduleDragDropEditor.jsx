import { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import { ROLE_FOR_BLOCK } from '@/lib/calendarBlocks';
import { formatDuration, timeToMinutes, minutesToTime, timesOverlap, getCurrentCycleStart, getWeekAnchor, getInstanceDatesForRule, dateToStr, parseDate, addDays } from '@/lib/cycleEngine';
import { AlertTriangle, CheckCircle2, X } from 'lucide-react';

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const START_HOUR = 7;
const END_HOUR = 20;
const TOTAL_HOURS = END_HOUR - START_HOUR;
const SLOT_HEIGHT = 64;
const TIME_COL_W = 52;

function minutesToPx(mins) { return (mins / 60) * SLOT_HEIGHT; }
function pxToMinutes(px) { return (px / SLOT_HEIGHT) * 60; }
function snapTo15(mins) { return Math.round(mins / 15) * 15; }
function clampStart(startMins, duration) {
  return Math.max(START_HOUR * 60, Math.min(END_HOUR * 60 - (duration || 60), startMins));
}

function blockColorClass(blockType) {
  const bt = (blockType || '').toLowerCase();
  if (bt.includes('carbee')) return 'bg-yellow-100 text-yellow-800 border-yellow-300';
  if (bt.includes('filming')) return 'bg-orange-100 text-orange-800 border-orange-300';
  if (bt.includes('editing')) return 'bg-purple-100 text-purple-800 border-purple-300';
  if (bt.includes('planning') || bt.includes('strategy') || bt.includes('scripting')) return 'bg-blue-100 text-blue-800 border-blue-300';
  if (bt.includes('send') || bt.includes('scheduling')) return 'bg-green-100 text-green-800 border-green-300';
  if (bt.includes('ad') || bt.includes('meta')) return 'bg-red-100 text-red-800 border-red-300';
  return 'bg-gray-100 text-gray-800 border-gray-300';
}

function computeConflict(block, allPlaced, allRules, clientId, clientCycleStartDate) {
  if (!block.employee || !block.day_of_week || !block.start_time) return null;
  const today = new Date().toISOString().split('T')[0];

  for (const other of allPlaced) {
    if (other.id === block.id) continue;
    if (other.employee !== block.employee || other.day_of_week !== block.day_of_week || !other.start_time) continue;
    if (timesOverlap(block.start_time, block.duration_minutes, other.start_time, other.duration_minutes)) {
      const end = minutesToTime(timeToMinutes(other.start_time) + (other.duration_minutes || 60));
      return `${other.block_type.replace(' Block', '')} from ${other.start_time}–${end}`;
    }
  }

  let blockDate = today;
  if (clientCycleStartDate) {
    const cycleMonday = getCurrentCycleStart(clientCycleStartDate);
    blockDate = dateToStr(getWeekAnchor(cycleMonday, block.day_of_week));
  }

  const otherRules = allRules.filter(r =>
    r.client !== clientId && r.employee === block.employee &&
    (!r.rule_end_date || r.rule_end_date >= today)
  );
  for (const r of otherRules) {
    if (!r.start_time) continue;
    const instances = getInstanceDatesForRule(r, blockDate, blockDate, r.rule_start_date);
    if (instances.length > 0 && timesOverlap(block.start_time, block.duration_minutes, r.start_time, r.duration_minutes || 60)) {
      const end = minutesToTime(timeToMinutes(r.start_time) + (r.duration_minutes || 60));
      return `${r.block_type.replace(' Block', '')} from ${r.start_time}–${end} (another client)`;
    }
  }
  return null;
}

function computeLayout(dayBlocks) {
  const sorted = [...dayBlocks].sort((a, b) => timeToMinutes(a.start_time) - timeToMinutes(b.start_time));
  const cols = [], colMap = {};
  sorted.forEach(b => {
    const s = timeToMinutes(b.start_time), e = s + (b.duration_minutes || 60);
    let wasPlaced = false;
    for (let c = 0; c < cols.length; c++) {
      if (cols[c] <= s) { cols[c] = e; colMap[b.id] = c; wasPlaced = true; break; }
    }
    if (!wasPlaced) { colMap[b.id] = cols.length; cols.push(e); }
  });
  return sorted.map(b => {
    const s = timeToMinutes(b.start_time), e = s + (b.duration_minutes || 60);
    let maxC = 0;
    sorted.forEach(o => {
      const os = timeToMinutes(o.start_time), oe = os + (o.duration_minutes || 60);
      if (s < oe && e > os) maxC = Math.max(maxC, colMap[o.id]);
    });
    return { block: b, col: colMap[b.id], totalCols: maxC + 1 };
  });
}

const TIME_LABELS = Array.from({ length: TOTAL_HOURS * 2 + 1 }, (_, i) => {
  const totalMins = START_HOUR * 60 + i * 30;
  const h = Math.floor(totalMins / 60);
  const m = totalMins % 60;
  const ampm = h >= 12 ? 'pm' : 'am';
  const h12 = h > 12 ? h - 12 : h === 0 ? 12 : h;
  return { label: m === 0 ? `${h12}${ampm}` : `${h12}:30`, top: i * (SLOT_HEIGHT / 2) };
});

// ─── Mobile Table Fallback ────────────────────────────────────────────────────

function MobileTable({ packageBlocks, employees, initialPlaced, allRules, clientId, onChange, clientCycleStartDate }) {
  const [rows, setRows] = useState(() =>
    packageBlocks.map(pb => {
      const ex = initialPlaced.find(r => r.block_type === pb.block_type);
      return {
        block_type: pb.block_type,
        duration_minutes: pb.duration_minutes || 60,
        repeat_frequency: pb.repeat_frequency,
        role: pb.role || ROLE_FOR_BLOCK[pb.block_type] || '',
        employee: ex?.employee || '',
        day_of_week: ex?.day_of_week || 'Monday',
        start_time: ex?.start_time || '09:00',
        existingRuleId: ex?.id || null,
      };
    })
  );

  const conflicts = useMemo(() => {
    const map = {};
    const today = new Date().toISOString().split('T')[0];
    rows.forEach(r => {
      if (!r.employee) return;
      for (const other of rows) {
        if (other.block_type === r.block_type || other.employee !== r.employee || other.day_of_week !== r.day_of_week) continue;
        if (timesOverlap(r.start_time, r.duration_minutes, other.start_time, other.duration_minutes)) {
          map[r.block_type] = `Conflict with ${other.block_type.replace(' Block', '')}`;
          return;
        }
      }
      if (map[r.block_type]) return;
      const otherRules = allRules.filter(rule =>
        rule.client !== clientId && rule.employee === r.employee &&
        rule.day_of_week === r.day_of_week && (!rule.rule_end_date || rule.rule_end_date >= today)
      );
      for (const rule of otherRules) {
        if (timesOverlap(r.start_time, r.duration_minutes, rule.start_time, rule.duration_minutes || 60)) {
          map[r.block_type] = `Conflict with ${rule.block_type.replace(' Block', '')} (another client)`;
          return;
        }
      }
    });
    return map;
  }, [rows, allRules, clientId]);

  useEffect(() => {
    const isValid = rows.every(r => r.employee && r.day_of_week && r.start_time);
    onChange && onChange(rows, isValid);
  }, [rows]);

  const update = (idx, field, value) => setRows(prev => prev.map((r, i) => i === idx ? { ...r, [field]: value } : r));

  return (
    <div className="space-y-3">
      {rows.map((row, idx) => {
        const primary = row.role ? employees.filter(e => e.role === row.role) : employees;
        const others = row.role ? employees.filter(e => e.role !== row.role) : [];
        const conflict = conflicts[row.block_type];
        return (
          <div key={row.block_type} className={`border rounded-xl p-4 space-y-3 ${conflict ? 'border-yellow-300 bg-yellow-50' : 'border-border bg-card'}`}>
            <div className="flex items-center justify-between">
              <span className="font-medium text-sm text-foreground">{row.block_type.replace(' Block', '')}</span>
              <span className="text-xs text-muted-foreground">{formatDuration(row.duration_minutes)} · {row.role}</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">Day</label>
                <select value={row.day_of_week} onChange={e => update(idx, 'day_of_week', e.target.value)} className="input-base py-1.5 text-sm">
                  {DAYS.map(d => <option key={d}>{d}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">Time</label>
                <input type="time" value={row.start_time} onChange={e => update(idx, 'start_time', e.target.value)} className="input-base py-1.5 text-sm" />
              </div>
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Employee</label>
              <select value={row.employee} onChange={e => update(idx, 'employee', e.target.value)} className="input-base py-1.5 text-sm">
                <option value="">Select...</option>
                {primary.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
                {others.length > 0 && (
                  <optgroup label="Other employees">
                    {others.map(e => <option key={e.id} value={e.id}>{e.name} ({e.role})</option>)}
                  </optgroup>
                )}
              </select>
            </div>
            {conflict && (
              <div className="flex items-center gap-2 text-xs text-yellow-700">
                <AlertTriangle size={12} /> {conflict} — you can still save and resolve later.
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ─── Desktop Drag-Drop Grid ───────────────────────────────────────────────────

function DesktopEditor({ packageBlocks, employees, allRules, clientId, initialPlaced, onChange, clientCycleStartDate }) {
  const [placed, setPlaced] = useState(() =>
    initialPlaced.map((r, i) => ({
      id: r.id || `init-${i}-${r.block_type}`,
      block_type: r.block_type,
      duration_minutes: r.duration_minutes || 60,
      repeat_frequency: r.repeat_frequency,
      role: r.role || ROLE_FOR_BLOCK[r.block_type] || '',
      day_of_week: r.day_of_week,
      start_time: r.start_time,
      employee: r.employee || '',
      existingRuleId: r.id && !r.id.startsWith('init-') ? r.id : null,
    }))
  );

  const [dropIndicator, setDropIndicator] = useState(null);
  const [popover, setPopover] = useState(null);
  const [hoverEmployee, setHoverEmployee] = useState(null);
  const [filterEmployee, setFilterEmployee] = useState('');
  const dragRef = useRef(null);
  const scrollRef = useRef(null);

  // Compute the Monday on or before cycle_start_date
  const cycleWeekMonday = useMemo(() => {
    if (!clientCycleStartDate) return null;
    const d = parseDate(clientCycleStartDate);
    // getDay(): 0=Sun,1=Mon,...,6=Sat. Convert to Mon=0 offset.
    const jsDay = d.getDay(); // 0=Sun
    const daysFromMon = jsDay === 0 ? 6 : jsDay - 1;
    return addDays(d, -daysFromMon);
  }, [clientCycleStartDate]);

  const cycleWeekDates = useMemo(() => {
    if (!cycleWeekMonday) return DAYS.map(() => null);
    return DAYS.map((_, i) => dateToStr(addDays(cycleWeekMonday, i)));
  }, [cycleWeekMonday]);

  const weekLabel = useMemo(() => {
    if (!cycleWeekMonday) return null;
    const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const fmt = (d) => `${d.getDate()} ${months[d.getMonth()]}`;
    const sun = addDays(cycleWeekMonday, 6);
    return `Week of Mon ${fmt(cycleWeekMonday)} — Sun ${fmt(sun)}`;
  }, [cycleWeekMonday]);

  // Day abbreviations for column headers
  const DAY_ABBRS = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];

  // Auto-scroll to 8am on mount
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = minutesToPx((8 - START_HOUR) * 60);
    }
  }, []);

  const conflicts = useMemo(() => {
    const map = {};
    placed.forEach(b => {
      if (b.employee) {
        const c = computeConflict(b, placed, allRules, clientId, clientCycleStartDate);
        if (c) map[b.id] = c;
      }
    });
    return map;
  }, [placed, allRules, clientId, clientCycleStartDate]);

  const unscheduled = packageBlocks.filter(pb => !placed.some(p => p.block_type === pb.block_type));
  // Valid if all placed blocks are fully configured AND there's at least one placed block
  const allValid = placed.length > 0 && placed.every(b => b.employee && b.day_of_week && b.start_time);

  const today = new Date().toISOString().split('T')[0];

  // For each day column, only show other-client rules that produce a real instance within this exact week
  const otherRulesByDay = useMemo(() => {
    if (!cycleWeekMonday) return DAYS.map(() => []);
    const weekStart = dateToStr(cycleWeekMonday);
    const weekEnd = dateToStr(addDays(cycleWeekMonday, 6));
    const baseRules = allRules.filter(r => r.client !== clientId && (!r.rule_end_date || r.rule_end_date >= weekStart));
    // Only keep rules that actually produce an instance within this week
    const rulesThisWeek = baseRules.filter(r => {
      const instances = getInstanceDatesForRule(r, weekStart, weekEnd, r.rule_start_date);
      return instances.length > 0;
    });
    return DAYS.map((_, i) => rulesThisWeek.filter(r => r.day_of_week === DAYS[i]));
  }, [allRules, clientId, cycleWeekMonday, today]);

  const updatePlaced = useCallback((newPlaced) => {
    setPlaced(newPlaced);
    const newConflicts = {};
    newPlaced.forEach(b => {
      if (b.employee) {
        const c = computeConflict(b, newPlaced, allRules, clientId, clientCycleStartDate);
        if (c) newConflicts[b.id] = c;
      }
    });
    const valid = newPlaced.length > 0 && newPlaced.every(b => b.employee && b.day_of_week && b.start_time);
    onChange && onChange(newPlaced.map(b => ({
      block_type: b.block_type,
      duration_minutes: b.duration_minutes,
      repeat_frequency: b.repeat_frequency,
      role: b.role,
      day_of_week: b.day_of_week,
      start_time: b.start_time,
      employee: b.employee,
      existingRuleId: b.existingRuleId,
    })), valid);
  }, [allRules, clientId, clientCycleStartDate, packageBlocks, onChange]);

  function handleDragStart(source, block, e) {
    dragRef.current = { source, block };
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', block.block_type);
  }

  function handleDragOver(e, dayIdx) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (!dragRef.current) return;
    const scrollTop = scrollRef.current?.scrollTop || 0;
    const rect = e.currentTarget.getBoundingClientRect();
    const relY = e.clientY - rect.top + scrollTop;
    const rawMins = START_HOUR * 60 + Math.round(pxToMinutes(Math.max(0, relY)));
    const snapped = snapTo15(rawMins);
    const duration = dragRef.current.block.duration_minutes || 60;
    setDropIndicator({ dayIdx, startMins: clampStart(snapped, duration) });
  }

  function handleDrop(e, dayIdx) {
    e.preventDefault();
    if (!dragRef.current || !dropIndicator) return;
    const { source, block } = dragRef.current;
    const startMins = clampStart(dropIndicator.startMins, block.duration_minutes || 60);
    const startTime = minutesToTime(startMins);
    const day = DAYS[dayIdx];

    if (source === 'sidebar') {
      const newBlock = {
        id: Math.random().toString(36).slice(2),
        block_type: block.block_type,
        duration_minutes: block.duration_minutes || 60,
        repeat_frequency: block.repeat_frequency,
        role: block.role || ROLE_FOR_BLOCK[block.block_type] || '',
        day_of_week: day,
        start_time: startTime,
        employee: '',
        existingRuleId: null,
      };
      const newPlaced = [...placed, newBlock];
      setPlaced(newPlaced);
      onChange && onChange(newPlaced.map(b => ({ ...b })), false);
      setPopover({ blockId: newBlock.id });
    } else {
      updatePlaced(placed.map(b => b.id === block.id ? { ...b, day_of_week: day, start_time: startTime } : b));
    }
    setDropIndicator(null);
    dragRef.current = null;
  }

  function handleEmployeeSelect(blockId, employeeId) {
    updatePlaced(placed.map(b => b.id === blockId ? { ...b, employee: employeeId } : b));
  }

  function removeBlock(blockId) {
    updatePlaced(placed.filter(b => b.id !== blockId));
    if (popover?.blockId === blockId) setPopover(null);
  }

  const popoverBlock = popover ? placed.find(b => b.id === popover.blockId) : null;
  const popoverPrimary = popoverBlock ? employees.filter(e => !popoverBlock.role || e.role === popoverBlock.role) : [];
  const popoverOthers = popoverBlock?.role ? employees.filter(e => e.role !== popoverBlock.role) : [];

  if (!cycleWeekMonday) {
    return (
      <div className="flex items-center justify-center border border-border rounded-xl bg-secondary/20 text-sm text-muted-foreground italic p-8" style={{ height: '640px' }}>
        Set a cycle start date on this client before setting up the schedule.
      </div>
    );
  }

  return (
    <div className="flex border border-border rounded-xl overflow-hidden bg-card" style={{ height: '640px' }}>
      {/* Left Sidebar */}
      <div className="w-44 shrink-0 border-r border-border bg-secondary/20 flex flex-col overflow-hidden">
        <div className="px-3 py-2.5 border-b border-border bg-secondary/30 shrink-0">
          <h3 className="text-xs font-semibold text-foreground">To Schedule</h3>
          <p className="text-[10px] text-muted-foreground mt-0.5">{unscheduled.length} remaining · drag to calendar</p>
        </div>
        <div className="p-2 space-y-1.5 overflow-y-auto flex-1">
          {unscheduled.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <CheckCircle2 size={22} className="text-green-500 mb-2" />
              <p className="text-xs text-muted-foreground font-medium">All scheduled!</p>
            </div>
          ) : unscheduled.map(pb => (
            <div
              key={pb.block_type}
              draggable
              onDragStart={e => handleDragStart('sidebar', pb, e)}
              className={`px-2.5 py-2 rounded-lg border cursor-grab active:cursor-grabbing select-none hover:brightness-95 transition-all ${blockColorClass(pb.block_type)}`}
            >
              <div className="font-semibold text-[11px] leading-tight">{pb.block_type.replace(' Block', '')}</div>
              <div className="text-[10px] opacity-70 mt-0.5">{formatDuration(pb.duration_minutes)}</div>
              {pb.role && <div className="text-[10px] opacity-60 truncate">{pb.role}</div>}
            </div>
          ))}
        </div>
      </div>

      {/* Calendar Grid */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Week label + employee filter */}
        <div className="flex items-center justify-between px-3 py-2 border-b border-border bg-secondary/20 shrink-0 gap-3">
          <span className="text-[11px] text-muted-foreground font-medium truncate">
            {weekLabel || 'Schedule week'}
          </span>
          <select
            value={filterEmployee}
            onChange={e => setFilterEmployee(e.target.value)}
            className="text-[11px] border border-border rounded-md px-2 py-1 bg-card text-foreground focus:outline-none shrink-0"
          >
            <option value="">All Employees</option>
            {employees.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
          </select>
        </div>

        {/* Day headers */}
        <div className="flex shrink-0 border-b border-border bg-card z-20">
          <div style={{ width: TIME_COL_W, minWidth: TIME_COL_W }} className="shrink-0" />
          {DAYS.map((day, i) => {
            const dateObj = cycleWeekMonday ? addDays(cycleWeekMonday, i) : null;
            const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            const dateLabel = dateObj ? `${dateObj.getDate()} ${months[dateObj.getMonth()]}` : '';
            return (
              <div key={day} className="flex-1 text-center py-1.5 border-l border-border/40">
                <div className="text-xs font-medium text-muted-foreground">{DAY_ABBRS[i]}</div>
                {dateLabel && <div className="text-[10px] text-muted-foreground/60">{dateLabel}</div>}
              </div>
            );
          })}
        </div>

        {/* Scrollable grid */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto">
          <div className="flex" style={{ height: SLOT_HEIGHT * TOTAL_HOURS }}>
            {/* Time labels */}
            <div className="shrink-0 relative border-r border-border/40" style={{ width: TIME_COL_W, minWidth: TIME_COL_W }}>
              {TIME_LABELS.map(({ label, top }, i) => (
                <div key={i} className="absolute right-2 text-[10px] text-muted-foreground leading-none" style={{ top: top - 7 }}>{label}</div>
              ))}
            </div>

            {/* Day columns */}
            {DAYS.map((day, dayIdx) => {
              const allDayOther = otherRulesByDay[dayIdx];
              const dayOther = filterEmployee ? allDayOther.filter(r => r.employee === filterEmployee) : allDayOther;
              const dayPlaced = placed.filter(b => b.day_of_week === day);
              const layout = computeLayout(dayPlaced);

              return (
                <div
                  key={day}
                  className="flex-1 relative border-l border-border/40 min-w-0"
                  onDragOver={e => handleDragOver(e, dayIdx)}
                  onDrop={e => handleDrop(e, dayIdx)}
                  onDragLeave={e => { if (!e.currentTarget.contains(e.relatedTarget)) setDropIndicator(null); }}
                >
                  {/* Grid lines */}
                  {Array.from({ length: TOTAL_HOURS * 2 }).map((_, i) => (
                    <div key={i} className={`absolute left-0 right-0 border-t ${i % 2 === 0 ? 'border-border/60' : 'border-border/20'}`}
                      style={{ top: i * (SLOT_HEIGHT / 2) }} />
                  ))}

                  {/* Other clients' rules (grey, read-only) */}
                  {dayOther.map(rule => {
                    const top = minutesToPx(timeToMinutes(rule.start_time) - START_HOUR * 60);
                    const height = Math.max(16, minutesToPx(rule.duration_minutes || 60) - 2);
                    const isHighlighted = hoverEmployee && rule.employee === hoverEmployee;
                    return (
                      <div
                        key={rule.id}
                        className={`absolute left-0.5 right-0.5 rounded px-1 py-0.5 pointer-events-none text-[10px] border truncate transition-colors ${isHighlighted ? 'bg-blue-100 border-blue-300 text-blue-700 opacity-90' : 'bg-gray-100 border-gray-200 text-gray-500 opacity-50'}`}
                        style={{ top: top + 1, height, zIndex: 1 }}
                      >
                        {rule.block_type.replace(' Block', '')}
                      </div>
                    );
                  })}

                  {/* Drop indicator */}
                  {dropIndicator?.dayIdx === dayIdx && dragRef.current && (
                    <div
                      className="absolute left-0.5 right-0.5 rounded border-2 border-dashed border-accent bg-accent/10 pointer-events-none z-10"
                      style={{
                        top: minutesToPx(dropIndicator.startMins - START_HOUR * 60),
                        height: minutesToPx(dragRef.current.block.duration_minutes || 60),
                      }}
                    />
                  )}

                  {/* Placed blocks */}
                  {layout.map(({ block: b, col, totalCols }) => {
                    const top = minutesToPx(timeToMinutes(b.start_time) - START_HOUR * 60);
                    const height = Math.max(22, minutesToPx(b.duration_minutes) - 2);
                    const conflict = conflicts[b.id];
                    const emp = employees.find(e => e.id === b.employee);
                    const widthPct = 100 / totalCols;
                    return (
                      <div
                        key={b.id}
                        draggable
                        onDragStart={e => { e.stopPropagation(); handleDragStart('placed', b, e); }}
                        onClick={e => { e.stopPropagation(); setPopover({ blockId: b.id }); }}
                        className={`absolute rounded border px-1 py-0.5 text-[10px] cursor-grab active:cursor-grabbing select-none z-10 overflow-hidden
                          ${conflict ? 'bg-yellow-100 border-yellow-400 text-yellow-800' : b.employee ? blockColorClass(b.block_type) : 'bg-amber-50 border-amber-300 text-amber-800 border-dashed'}`}
                        style={{ top: top + 1, height, left: `calc(${col * widthPct}% + 2px)`, width: `calc(${widthPct}% - 4px)`, zIndex: 10 }}
                      >
                        <div className="font-semibold truncate leading-tight">{b.block_type.replace(' Block', '')}</div>
                        {height > 28 && (
                          <div className="truncate opacity-80 text-[9px]">
                            {b.employee ? (emp?.name || '?') : <span className="italic opacity-60">click to assign</span>}
                          </div>
                        )}
                        {conflict && height > 38 && (
                          <div className="flex items-center gap-0.5 mt-0.5"><AlertTriangle size={8} /><span className="text-[9px]">Warning</span></div>
                        )}
                        <button
                          onClick={e => { e.stopPropagation(); removeBlock(b.id); }}
                          className="absolute top-0.5 right-0.5 opacity-40 hover:opacity-100"
                        ><X size={9} /></button>
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Employee selection popover */}
      {popover && popoverBlock && (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-24 px-4 bg-black/20" onClick={() => setPopover(null)}>
          <div className="bg-card border border-border rounded-xl shadow-2xl p-4 w-72" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-1">
              <h3 className="text-sm font-semibold text-foreground">{popoverBlock.block_type.replace(' Block', '')}</h3>
              <button onClick={() => setPopover(null)} className="text-muted-foreground hover:text-foreground"><X size={14} /></button>
            </div>
            <p className="text-xs text-muted-foreground mb-3">
              {popoverBlock.day_of_week} · {popoverBlock.start_time} · {formatDuration(popoverBlock.duration_minutes)}
              {popoverBlock.role && <span className="ml-1 opacity-60">· {popoverBlock.role}</span>}
            </p>

            {conflicts[popover.blockId] && (
              <div className="mb-3 p-2 bg-yellow-50 rounded-lg border border-yellow-200 flex items-start gap-1.5">
                <AlertTriangle size={12} className="text-yellow-600 shrink-0 mt-0.5" />
                <p className="text-xs text-yellow-800">
                  Warning — {employees.find(e => e.id === popoverBlock.employee)?.name} may have {conflicts[popover.blockId]} on {popoverBlock.day_of_week}. You can still save and resolve later.
                </p>
              </div>
            )}

            <div className="space-y-1 max-h-64 overflow-y-auto">
              {popoverPrimary.length === 0 && popoverOthers.length === 0 ? (
                <p className="text-xs text-muted-foreground italic py-2">No employees found.</p>
              ) : [...popoverPrimary, ...popoverOthers].map((emp, idx) => {
                const isFirst = idx === popoverPrimary.length && popoverOthers.length > 0;
                const testBlock = { ...popoverBlock, employee: emp.id };
                const empConflict = computeConflict(testBlock, placed, allRules, clientId, clientCycleStartDate);
                const isOther = popoverBlock?.role && emp.role !== popoverBlock.role;
                return (
                  <div key={emp.id}>
                    {isFirst && (
                      <div className="text-[10px] text-muted-foreground font-semibold uppercase tracking-wide px-3 pt-2 pb-1">Other Employees</div>
                    )}
                    <button
                      onMouseEnter={() => setHoverEmployee(emp.id)}
                      onMouseLeave={() => setHoverEmployee(null)}
                      onClick={() => { handleEmployeeSelect(popover.blockId, emp.id); setHoverEmployee(null); setPopover(null); }}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm text-left transition-colors
                        ${empConflict ? 'bg-yellow-50 text-yellow-800 hover:bg-yellow-100' : 'hover:bg-secondary text-foreground'}`}
                    >
                      <span className="font-medium">{emp.name}</span>
                      {empConflict
                        ? <span className="flex items-center gap-1 text-[10px] text-yellow-700 shrink-0"><AlertTriangle size={10} />Warning</span>
                        : <span className="text-[10px] text-muted-foreground shrink-0">{isOther ? emp.role : emp.role}</span>
                      }
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Main Export ─────────────────────────────────────────────────────────────

export default function ScheduleDragDropEditor({ packageBlocks, employees, allRules, clientId, initialPlaced = [], onChange, clientCycleStartDate }) {
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  useEffect(() => {
    const h = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', h);
    return () => window.removeEventListener('resize', h);
  }, []);

  if (isMobile) {
    return <MobileTable packageBlocks={packageBlocks} employees={employees} initialPlaced={initialPlaced} allRules={allRules} clientId={clientId} onChange={onChange} clientCycleStartDate={clientCycleStartDate} />;
  }
  return <DesktopEditor packageBlocks={packageBlocks} employees={employees} allRules={allRules} clientId={clientId} initialPlaced={initialPlaced} onChange={onChange} clientCycleStartDate={clientCycleStartDate} />;
}