import { useState } from 'react';
import { X } from 'lucide-react';

export default function EmployeeModal({ employee, onSave, onClose }) {
  const [form, setForm] = useState({
    name: employee?.name || '',
    role: employee?.role || 'Social Media Manager',
    region: employee?.region || 'Melbourne',
    phone: employee?.phone || '',
    email: employee?.email || '',
    address: employee?.address || '',
  });

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(form);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
      <div className="bg-card rounded-2xl border border-border shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <h2 className="font-dm font-bold text-foreground">{employee ? 'Edit Team Member' : 'Add Team Member'}</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X size={18} /></button>
        </div>
        <form onSubmit={handleSubmit} className="px-6 py-5 space-y-4">
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Full Name *</label>
            <input required value={form.name} onChange={e => set('name', e.target.value)}
              className="input-base" placeholder="e.g. Sarah Johnson" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Role</label>
              <select value={form.role} onChange={e => set('role', e.target.value)} className="input-base">
                {['Social Media Manager', 'Editor', 'Content Creator', 'Marketing Manager', 'Operations Manager', 'Founder'].map(r => (
                  <option key={r}>{r}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Region</label>
              <select value={form.region} onChange={e => set('region', e.target.value)} className="input-base">
                {['Melbourne', 'Sydney', 'Brisbane', 'Perth', 'Newcastle'].map(r => <option key={r}>{r}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Email</label>
            <input type="email" value={form.email} onChange={e => set('email', e.target.value)}
              className="input-base" placeholder="sarah@scrmmedia.com.au" />
          </div>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Phone</label>
            <input type="tel" value={form.phone} onChange={e => set('phone', e.target.value)}
              className="input-base" placeholder="+61 4xx xxx xxx" />
          </div>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Full Address</label>
            <input value={form.address} onChange={e => set('address', e.target.value)}
              className="input-base" placeholder="123 Example St, Suburb, VIC 3000" />
          </div>
          <div className="flex gap-3 pt-1">
            <button type="button" onClick={onClose}
              className="flex-1 px-4 py-2 rounded-lg border border-border text-sm font-medium text-foreground hover:bg-secondary transition-colors">
              Cancel
            </button>
            <button type="submit"
              className="flex-1 px-4 py-2 rounded-lg bg-accent text-white text-sm font-medium hover:bg-accent/90 transition-colors">
              {employee ? 'Save Changes' : 'Add Member'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}