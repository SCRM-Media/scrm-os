import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Save, Plus, Pencil, Trash2, X, ChevronDown, ChevronUp } from 'lucide-react';

const CONFIG_NAME = '__add_ons_config__';

function Field({ label, hint, children }) {
  return (
    <div>
      <label className="block text-xs font-medium text-muted-foreground mb-1">
        {label}{hint && <span className="ml-1 opacity-60 font-normal">{hint}</span>}
      </label>
      {children}
    </div>
  );
}

function Toggle({ value, onChange }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!value)}
      className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors shrink-0 ${value ? 'bg-accent' : 'bg-border'}`}
    >
      <span className={`inline-block h-3.5 w-3.5 rounded-full bg-white shadow transition-transform ${value ? 'translate-x-4' : 'translate-x-1'}`} />
    </button>
  );
}

// ─── CarBee Config ─────────────────────────────────────────────────────────────
function CarBeeConfig() {
  const [config, setConfig] = useState(null);
  const [configId, setConfigId] = useState(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const defaults = { carbee_rate_per_car: 25, carbee_production_rate: 5 };

  useEffect(() => {
    base44.entities.Package.filter({ name: CONFIG_NAME }).then(res => {
      if (res.length > 0) {
        setConfigId(res[0].id);
        setConfig({ ...defaults, ...(res[0].blocks_config || {}) });
      } else {
        setConfig({ ...defaults });
      }
    });
  }, []);

  const save = async () => {
    setSaving(true);
    const payload = { name: CONFIG_NAME, is_system: true, blocks_config: config };
    if (configId) {
      await base44.entities.Package.update(configId, payload);
    } else {
      const rec = await base44.entities.Package.create(payload);
      setConfigId(rec.id);
    }
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const set = (k, v) => setConfig(c => ({ ...c, [k]: v }));

  const productionRate = Number(config?.carbee_production_rate || 5);
  const exampleDur = productionRate > 0 ? Math.ceil((10 / productionRate) * 60 / 15) * 15 : 0;

  if (!config) return <div className="text-xs text-muted-foreground py-4">Loading...</div>;

  return (
    <div className="bg-card border border-yellow-200 rounded-xl overflow-hidden">
      <div className="px-5 py-4 bg-yellow-50 border-b border-yellow-200">
        <h3 className="font-dm font-bold text-yellow-900">CarBee Filming</h3>
        <p className="text-xs text-yellow-700 mt-0.5">Fixed block type: CarBee Filming Block · Colour: Yellow · Role: Content Creator</p>
      </div>
      <div className="px-5 py-5 space-y-4">
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Rate Per Car (ex GST)" hint="$AUD">
            <input type="number" value={config.carbee_rate_per_car} onChange={e => set('carbee_rate_per_car', Number(e.target.value))}
              className="input-base" min="0" />
          </Field>
          <Field label="Production Rate" hint="cars/hour">
            <input type="number" value={config.carbee_production_rate} onChange={e => set('carbee_production_rate', Number(e.target.value))}
              className="input-base" min="0.5" step="0.5" />
          </Field>
        </div>
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg px-4 py-3 text-xs text-yellow-800 space-y-1">
          <div className="font-semibold">Block Duration Formula</div>
          <div>Session duration = Cars Booked ÷ {productionRate} cars/hr × 60 min</div>
          <div className="opacity-80">Example: 10 cars ÷ {productionRate}/hr = {exampleDur} min</div>
        </div>
        <div className="flex justify-end">
          <button onClick={save} disabled={saving}
            className="flex items-center gap-2 px-4 py-2 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accent/90 disabled:opacity-50 transition-colors">
            <Save size={14} /> {saving ? 'Saving...' : saved ? '✓ Saved' : 'Save CarBee Config'}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Inventory Package Editor ──────────────────────────────────────────────────
function InventoryPackageEditor({ pkg, onSave, onCancel }) {
  const [form, setForm] = useState({
    name: pkg?.name || '',
    cars_per_hour: pkg?.cars_per_hour || '',
    cars_per_hour_video: pkg?.cars_per_hour_video || '',
    photos_per_car: pkg?.photos_per_car || '',
    includes_video_default: pkg?.includes_video_default || false,
    video_style_default: pkg?.video_style_default || '',
    monthly_rate: pkg?.monthly_rate || '',
    notes: pkg?.notes || '',
  });
  const [saving, setSaving] = useState(false);
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) return;
    setSaving(true);
    await onSave({
      ...form,
      cars_per_hour: form.cars_per_hour !== '' ? Number(form.cars_per_hour) : null,
      cars_per_hour_video: form.cars_per_hour_video !== '' ? Number(form.cars_per_hour_video) : null,
      photos_per_car: form.photos_per_car !== '' ? Number(form.photos_per_car) : null,
      monthly_rate: form.monthly_rate !== '' ? Number(form.monthly_rate) : null,
    });
    setSaving(false);
  };

  return (
    <form onSubmit={handleSubmit} className="bg-card border border-teal-300 rounded-xl overflow-hidden">
      <div className="px-5 py-4 bg-teal-50 border-b border-teal-200 flex items-center justify-between">
        <h4 className="font-dm font-semibold text-teal-900">{pkg?.id ? 'Edit' : 'New'} Inventory Package</h4>
        <button type="button" onClick={onCancel} className="text-muted-foreground hover:text-foreground"><X size={16} /></button>
      </div>
      <div className="px-5 py-4 space-y-3">
        <Field label="Package Name *">
          <input required value={form.name} onChange={e => set('name', e.target.value)}
            className="input-base" placeholder="e.g. Standard, Premium, Large Yard" />
        </Field>
        <div className="grid sm:grid-cols-2 gap-3">
          <Field label="Cars / Hour — Photos Only">
            <input type="number" value={form.cars_per_hour} onChange={e => set('cars_per_hour', e.target.value)}
              className="input-base" placeholder="e.g. 5" step="0.5" min="0.5" />
          </Field>
          <Field label="Cars / Hour — Photos + Video">
            <input type="number" value={form.cars_per_hour_video} onChange={e => set('cars_per_hour_video', e.target.value)}
              className="input-base" placeholder="e.g. 3" step="0.5" min="0.5" />
          </Field>
        </div>
        <div className="grid sm:grid-cols-2 gap-3">
          <Field label="Default Photos Per Car">
            <input type="number" value={form.photos_per_car} onChange={e => set('photos_per_car', e.target.value)}
              className="input-base" placeholder="e.g. 20" min="1" />
          </Field>
          <Field label="Price Per Car (AUD, ex GST)">
            <input type="number" value={form.monthly_rate} onChange={e => set('monthly_rate', e.target.value)}
              className="input-base" placeholder="e.g. 25" min="0" />
          </Field>
        </div>
        <div className="flex items-center justify-between py-1">
          <span className="text-sm font-medium text-foreground">Includes Video by Default</span>
          <Toggle value={!!form.includes_video_default} onChange={v => set('includes_video_default', v)} />
        </div>
        {form.includes_video_default && (
          <Field label="Default Video Style">
            <select value={form.video_style_default} onChange={e => set('video_style_default', e.target.value)} className="input-base">
              <option value="">No default</option>
              <option value="Style 1 Phone Edited On Spot">Style 1 — Phone Edited On Spot</option>
              <option value="Style 2 Camera Edited Next Day">Style 2 — Camera Edited Next Day</option>
            </select>
          </Field>
        )}
        <Field label="Notes">
          <textarea value={form.notes} onChange={e => set('notes', e.target.value)}
            className="input-base resize-none h-16" placeholder="Any notes about this tier..." />
        </Field>
      </div>
      <div className="px-5 py-3 border-t border-border flex gap-2 justify-end">
        <button type="button" onClick={onCancel}
          className="px-4 py-2 border border-border rounded-lg text-sm font-medium text-muted-foreground hover:bg-secondary transition-colors">
          Cancel
        </button>
        <button type="submit" disabled={saving}
          className="flex items-center gap-2 px-4 py-2 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accent/90 disabled:opacity-50 transition-colors">
          <Save size={14} /> {saving ? 'Saving...' : 'Save'}
        </button>
      </div>
    </form>
  );
}

// ─── Inventory Package Card ────────────────────────────────────────────────────
function InventoryPackageCard({ pkg, onEdit, onDelete }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <div className="bg-card border border-teal-200 rounded-xl overflow-hidden">
      <div className="flex items-center justify-between px-5 py-3">
        <div className="flex items-center gap-3">
          <button onClick={() => setExpanded(e => !e)} className="text-muted-foreground hover:text-foreground transition-colors">
            {expanded ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
          </button>
          <div>
            <div className="font-dm font-semibold text-foreground">{pkg.name}</div>
            <div className="text-xs text-muted-foreground mt-0.5">
              {pkg.cars_per_hour ? `${pkg.cars_per_hour} cars/hr` : 'Rate not set'}
              {pkg.monthly_rate ? ` · $${pkg.monthly_rate.toLocaleString()}/car` : ''}
              {pkg.includes_video_default ? ' · Includes Video' : ''}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <button onClick={onEdit} className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"><Pencil size={14} /></button>
          <button onClick={onDelete} className="p-1.5 rounded-lg hover:bg-red-50 text-muted-foreground hover:text-red-600 transition-colors"><Trash2 size={14} /></button>
        </div>
      </div>
      {expanded && (
        <div className="border-t border-teal-100 px-5 py-3 grid sm:grid-cols-3 gap-3 text-xs bg-teal-50/30">
          <div><span className="text-muted-foreground">Photos only rate:</span> <span className="font-medium">{pkg.cars_per_hour ? `${pkg.cars_per_hour} cars/hr` : '—'}</span></div>
          <div><span className="text-muted-foreground">With video rate:</span> <span className="font-medium">{pkg.cars_per_hour_video ? `${pkg.cars_per_hour_video} cars/hr` : '—'}</span></div>
          <div><span className="text-muted-foreground">Photos per car:</span> <span className="font-medium">{pkg.photos_per_car || '—'}</span></div>
          {pkg.video_style_default && <div className="sm:col-span-2"><span className="text-muted-foreground">Default video style:</span> <span className="font-medium">{pkg.video_style_default}</span></div>}
          {pkg.notes && <div className="sm:col-span-3 text-muted-foreground italic">{pkg.notes}</div>}
        </div>
      )}
    </div>
  );
}

// ─── Inventory Packages List ───────────────────────────────────────────────────
function InventoryPackagesList() {
  const [packages, setPackages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState(null);
  const [showCreate, setShowCreate] = useState(false);

  const load = async () => {
    const pkgs = await base44.entities.InventoryPackage.list();
    setPackages(pkgs);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const handleSave = async (data) => {
    if (editingId) {
      await base44.entities.InventoryPackage.update(editingId, data);
      setEditingId(null);
    } else {
      await base44.entities.InventoryPackage.create(data);
      setShowCreate(false);
    }
    load();
  };

  const handleDelete = async (pkg) => {
    if (!confirm(`Delete "${pkg.name}"?`)) return;
    await base44.entities.InventoryPackage.delete(pkg.id);
    load();
  };

  if (loading) return <div className="text-xs text-muted-foreground py-4">Loading...</div>;

  return (
    <div className="bg-card border border-teal-200 rounded-xl overflow-hidden">
      <div className="px-5 py-4 bg-teal-50 border-b border-teal-200 flex items-center justify-between">
        <div>
          <h3 className="font-dm font-bold text-teal-900">Inventory Photography Packages</h3>
          <p className="text-xs text-teal-700 mt-0.5">Define tiers with different rates and defaults. Per-client settings can still be customised.</p>
        </div>
        <button onClick={() => setShowCreate(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-teal-700 text-white rounded-lg text-xs font-medium hover:bg-teal-800 transition-colors">
          <Plus size={13} /> New Tier
        </button>
      </div>
      <div className="px-5 py-4 space-y-3">
        {showCreate && (
          <InventoryPackageEditor onSave={handleSave} onCancel={() => setShowCreate(false)} />
        )}
        {packages.length === 0 && !showCreate && (
          <p className="text-sm text-muted-foreground italic">No inventory packages defined yet. Add a tier to get started.</p>
        )}
        {packages.map(pkg =>
          editingId === pkg.id ? (
            <InventoryPackageEditor key={pkg.id} pkg={pkg} onSave={handleSave} onCancel={() => setEditingId(null)} />
          ) : (
            <InventoryPackageCard key={pkg.id} pkg={pkg} onEdit={() => setEditingId(pkg.id)} onDelete={() => handleDelete(pkg)} />
          )
        )}
      </div>
    </div>
  );
}

// ─── Main Export ───────────────────────────────────────────────────────────────
export default function AddOnsConfig() {
  return (
    <div className="space-y-6">
      <CarBeeConfig />
      <InventoryPackagesList />
    </div>
  );
}