import { CheckCircle2, Circle } from 'lucide-react';

export default function WizardCheckbox({ checked, onChange, label, bold }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className="w-full flex items-center gap-3 py-2.5 px-3 rounded-lg hover:bg-secondary/60 transition-colors text-left group"
    >
      {checked
        ? <CheckCircle2 size={20} className="text-green-500 shrink-0" />
        : <Circle size={20} className="text-muted-foreground shrink-0 group-hover:text-accent transition-colors" />
      }
      <span className={`text-sm ${checked ? 'line-through text-muted-foreground' : bold ? 'font-semibold text-foreground' : 'text-foreground'}`}>
        {label}
      </span>
    </button>
  );
}