import Step1ClientInfo from '@/components/onboarding/steps/Step1ClientInfo.jsx';
import StepAgreement from '@/components/onboarding/steps/StepAgreement';
import StepInvoice from '@/components/onboarding/steps/StepInvoice';
import StepMeeting from '@/components/onboarding/steps/StepMeeting';
import StepQuestionnaire from '@/components/onboarding/steps/StepQuestionnaire';
import StepMetricool from '@/components/onboarding/steps/StepMetricool';
import StepPlatforms from '@/components/onboarding/steps/StepPlatforms';
import StepCalendar from '@/components/onboarding/steps/StepCalendar';
import StepFirstMeeting from '@/components/onboarding/steps/StepFirstMeeting';
import StepMetaBusiness from '@/components/onboarding/steps/StepMetaBusiness';
import StepAdAccount from '@/components/onboarding/steps/StepAdAccount';
import StepGoogleCalendar from '@/components/onboarding/steps/StepGoogleCalendar';
import StepInventory from '@/components/onboarding/steps/StepInventory';
import StepCycleStart from '@/components/onboarding/steps/StepCycleStart';

const STEP_MAP = {
  client_info: Step1ClientInfo,
  agreement: StepAgreement,
  invoice: StepInvoice,
  meeting: StepMeeting,
  questionnaire: StepQuestionnaire,
  cycle_start: StepCycleStart,
  metricool: StepMetricool,
  platforms: StepPlatforms,
  calendar: StepCalendar,
  first_meeting: StepFirstMeeting,
  meta_business: StepMetaBusiness,
  ad_account: StepAdAccount,
  google_calendar: StepGoogleCalendar,
  inventory_setup: StepInventory,
};

export default function WizardStepRenderer({ step, client, data, onChange }) {
  const Component = STEP_MAP[step.id];
  if (!Component) return <div className="text-muted-foreground text-sm">Step not found: {step.id}</div>;

  return <Component data={data} onChange={onChange} client={client} />;
}