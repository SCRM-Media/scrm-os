import { Sparkles, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function OnboardingCompletion({ client, progress, onActivate, saving }) {
  const d = progress || {};
  const dealership = d.dealership || {};
  const contact = d.contact || {};
  const pkg = d.package || {};
  const meeting = d.smm_first_meeting || {};

  return (
    <div className="max-w-2xl mx-auto px-6 py-10 space-y-6">
      {/* Banner */}
      <div className="text-center py-8 bg-green-50 border border-green-200 rounded-2xl">
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Sparkles size={28} className="text-green-600" />
        </div>
        <div className="text-green-700 text-sm font-semibold uppercase tracking-wide mb-2">Onboarding Complete</div>
        <h2 className="font-dm font-bold text-2xl text-foreground mb-2">{client.name} is now an active client.</h2>
        <p className="text-muted-foreground text-sm">All onboarding steps have been completed successfully.</p>
      </div>

      {/* Summary */}
      <div className="bg-card border border-border rounded-xl p-5 space-y-3">
        <h3 className="font-dm font-semibold text-foreground mb-4">Client Summary</h3>
        <SummaryRow label="Dealership" value={dealership.dealership_name || client.name} />
        <SummaryRow label="State" value={dealership.state} />
        <SummaryRow label="Address" value={dealership.address} />
        {dealership.dealer_group && <SummaryRow label="Dealer Group" value={dealership.dealer_group} />}
        <SummaryRow label="Package" value={pkg.package} />
        <SummaryRow label="Monthly Value" value={pkg.monthly_value ? `$${Number(pkg.monthly_value).toLocaleString()}/mo` : undefined} />
        <SummaryRow label="Primary Contact" value={contact.full_name} />
        <SummaryRow label="Contact Email" value={contact.email} />
        <SummaryRow label="Contact Phone" value={contact.phone ? `${contact.country_code || '+61'} ${contact.phone}` : undefined} />
        <SummaryRow label="Cycle Start Date" value={client.cycle_start_date} />
        <SummaryRow label="First Planning Meeting" value={meeting.first_meeting_date} />
      </div>

      {/* Actions */}
      <button
        onClick={onActivate}
        disabled={saving}
        className="w-full py-3.5 bg-accent text-white rounded-xl font-dm font-semibold text-base hover:bg-accent/90 transition-colors disabled:opacity-50 shadow-sm"
      >
        {saving ? 'Activating...' : `✓ Confirm — Mark ${client.name} as Active`}
      </button>
    </div>
  );
}

function SummaryRow({ label, value }) {
  if (!value) return null;
  return (
    <div className="flex items-center justify-between py-1.5 border-b border-border/50 last:border-0">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className="text-sm font-medium text-foreground text-right max-w-xs">{value}</span>
    </div>
  );
}