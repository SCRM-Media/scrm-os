import { Plus, ArrowRight, CheckCircle2, Trash2 } from 'lucide-react';
import PageHeader from '@/components/ui/PageHeader';
import { PHASE1_STEPS, loadProgress, isPhase1Complete, isPhase2Complete } from '@/lib/wizardSteps.js';

function getClientProgress(client) {
  const progress = loadProgress(client);
  const phase1Done = isPhase1Complete(progress);
  const phase1Idx = PHASE1_STEPS.findIndex(s => !s.isComplete(progress[s.id] || {}));
  const phase1Completed = phase1Idx === -1 ? PHASE1_STEPS.length : phase1Idx;
  const phase2Done = phase1Done && isPhase2Complete(progress, client);
  return { progress, phase1Done, phase1Completed, phase2Done };
}

export default function OnboardingHub({ clients, onStartNew, onContinue, onDelete }) {
  return (
    <div className="p-6 lg:p-8 max-w-4xl mx-auto">
      <PageHeader
        title="Onboarding"
        subtitle="Manage new client setups step by step"
      />

      <button
        onClick={onStartNew}
        className="w-full flex items-center justify-center gap-2 bg-accent text-white px-6 py-4 rounded-xl text-base font-dm font-semibold hover:bg-accent/90 transition-colors shadow-sm mb-8"
      >
        <Plus size={20} /> Start New Client Onboarding
      </button>

      {clients.length === 0 ? (
        <div className="bg-card rounded-xl border border-border p-10 text-center">
          <div className="text-muted-foreground text-sm">No clients currently onboarding.</div>
          <div className="text-xs text-muted-foreground mt-1 opacity-60">Click the button above to begin a new onboarding.</div>
        </div>
      ) : (
        <div className="space-y-3">
          <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">In Progress</h2>
          {clients.map(client => {
            const { progress, phase1Done, phase1Completed, phase2Done } = getClientProgress(client);
            const statusLabel = phase2Done
              ? 'Ready to activate'
              : phase1Done
              ? 'Phase 2 — Parallel Setup'
              : `Step ${phase1Completed + 1} of ${PHASE1_STEPS.length}`;

            return (
              <div key={client.id} className="bg-card rounded-xl border border-border shadow-sm p-5 flex items-center gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap mb-3">
                    <span className="font-dm font-semibold text-foreground">{client.name}</span>
                    {client.package && (
                      <span className="text-xs bg-secondary border border-border px-2 py-0.5 rounded-full text-muted-foreground">{client.package}</span>
                    )}
                  </div>

                  <div className="flex items-center gap-2 mb-2">
                    <div className="flex gap-0.5">
                      {PHASE1_STEPS.map((s) => {
                        const done = s.isComplete(progress[s.id] || {});
                        return (
                          <div key={s.id} className={`w-4 h-1.5 rounded-full ${done ? 'bg-accent' : 'bg-border'}`} />
                        );
                      })}
                    </div>
                    <span className="text-xs text-muted-foreground">{statusLabel}</span>
                  </div>

                  {phase2Done && (
                    <div className="flex items-center gap-1.5 text-xs text-green-600 font-medium">
                      <CheckCircle2 size={12} /> All steps complete — ready to activate
                    </div>
                  )}
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => onDelete(client)}
                    className="p-2 rounded-lg text-muted-foreground hover:text-red-600 hover:bg-red-50 transition-colors"
                    title="Delete onboarding"
                  >
                    <Trash2 size={15} />
                  </button>
                  <button
                    onClick={() => onContinue(client)}
                    className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors"
                  >
                    {phase2Done ? 'Activate' : 'Continue'} <ArrowRight size={15} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}