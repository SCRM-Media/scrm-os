import { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, ArrowRight, CheckCircle2, X } from 'lucide-react';
import {
  PHASE1_STEPS,
  loadProgress,
  isPhase1Complete,
  isPhase2Complete,
} from '@/lib/wizardSteps.js';
import WizardStepRenderer from '@/components/onboarding/WizardStepRenderer.jsx';
import Phase2View from '@/components/onboarding/Phase2View.jsx';
import OnboardingCompletion from '@/components/onboarding/OnboardingCompletion.jsx';
import ScheduleSetupStep from '@/components/onboarding/ScheduleSetupStep.jsx';

export default function OnboardingWizard({ client: initialClient, onClose, onActivated, onClientCreated }) {
  const [client, setClient] = useState(initialClient || null);
  const [progress, setProgress] = useState(loadProgress(initialClient));
  const [currentStepIdx, setCurrentStepIdx] = useState(0);
  const [saving, setSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState(null); // null | 'pending' | 'saved'
  const [view, setView] = useState('phase1'); // 'phase1' | 'phase2' | 'schedule' | 'complete'
  const debounceRef = useRef(null);

  // Don't create client on mount — wait until Continue to Phase 2 is clicked

  const phase1Done = isPhase1Complete(progress);
  const allDone = client && phase1Done && isPhase2Complete(progress, client);

  // Determine initial view when loading an existing client
  useEffect(() => {
    if (initialClient) {
      const prog = loadProgress(initialClient);
      if (isPhase1Complete(prog)) {
        if (isPhase2Complete(prog, initialClient)) {
          setView('complete');
        } else {
          setView('phase2');
        }
      }
    }
  }, []);

  const saveProgress = async (newProgress, updatedClient) => {
    const cl = updatedClient || client;
    if (!cl) return;
    const saved = await base44.entities.Client.update(cl.id, {
      onboarding_progress: newProgress,
    });
    setProgress(newProgress);
    return saved;
  };

  const debouncedSave = (saveFn) => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    setSaveStatus('pending');
    debounceRef.current = setTimeout(async () => {
      await saveFn();
      setSaveStatus('saved');
      setTimeout(() => setSaveStatus(null), 2000);
    }, 5000);
  };

  const handleStepChange = (stepId, data) => {
    const newProgress = { ...progress, [stepId]: data };
    setProgress(newProgress);
    // During Phase 1, just track progress. Client is created when continuing to Phase 2.
  };

  const handlePhase2Change = (taskId, data) => {
    const newProgress = { ...progress, [taskId]: data };
    setProgress(newProgress);

    // Save cycle start date to client when set
    if (taskId === 'ops_cycle_start' && data.cycle_start_date && data.cycle_start_date !== client?.cycle_start_date) {
      base44.entities.Client.update(client.id, { cycle_start_date: data.cycle_start_date }).then(setClient);
    }

    debouncedSave(() => saveProgress(newProgress));
  };

  // Called when "Save" is clicked in the schedule setup — go back to phase2, don't mark C2 complete
  const handleScheduleSave = () => {
    setView('phase2');
  };

  // Called when "Save and Finish" is clicked — mark C2 as complete, go back to phase2
  const handleScheduleSaveAndFinish = async () => {
    const newProgress = { ...progress, ops_blocks: { ...progress['ops_blocks'], schedule_finished: true } };
    setProgress(newProgress);
    await saveProgress(newProgress);
    setView('phase2');
  };

  const handleNext = async () => {
    if (currentStepIdx < PHASE1_STEPS.length - 1) {
      setCurrentStepIdx(i => i + 1);
    } else {
      setSaving(true);
      const info = progress['client_info'] || {};
      const addOns = info.add_ons || [];
      const clientData = {
        name: info.dealership_name || 'New Client',
        status: 'Onboarding',
        address: info.address || '',
        state: info.state || '',
        location: [info.address, info.state].filter(Boolean).join(', '),
        package: info.package || '',
        monthly_value: info.monthly_value ? Number(info.monthly_value) : null,
        add_ons: addOns,
        carbee_enabled: addOns.includes('CarBee Filming'),
        inventory_enabled: addOns.includes('Inventory Photography'),
        service_agreement_date: progress['agreement']?.date_signed || '',
        onboarding_progress: progress,
      };
      const newClient = await base44.entities.Client.create(clientData);
      setClient(newClient);
      onClientCreated && onClientCreated(newClient);
      if (info.contact_name) {
        await base44.entities.Contact.create({
          client: newClient.id,
          full_name: info.contact_name,
          position: info.contact_position || '',
          phone: info.contact_phone || '',
          email: info.contact_email || '',
          is_primary: true,
        });
      }
      setSaving(false);
      setView('phase2');
    }
  };

  const handleBack = () => {
    if (view === 'phase2') { setView('phase1'); setCurrentStepIdx(PHASE1_STEPS.length - 1); return; }
    if (view === 'schedule') { setView('phase2'); return; }
    if (currentStepIdx > 0) setCurrentStepIdx(i => i - 1);
  };

  const handleActivate = async () => {
    setSaving(true);
    await base44.entities.Client.update(client.id, { status: 'Active' });
    setSaving(false);
    setView('complete');
    onActivated && onActivated();
  };

  const currentStep = PHASE1_STEPS[currentStepIdx];
  const currentData = progress[currentStep?.id] || {};
  const stepComplete = currentStep ? currentStep.isComplete(currentData) : false;

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-card border-b border-border px-6 py-3 flex items-center justify-between">
        <button onClick={onClose} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft size={16} /> Back to Onboarding
        </button>
        <div className="flex items-center gap-3">
          <span className="font-dm font-bold text-foreground text-sm truncate max-w-xs">{client?.name || 'New Client'}</span>
          {saveStatus === 'pending' && <span className="text-xs text-muted-foreground">Saving...</span>}
          {saveStatus === 'saved' && <span className="text-xs text-green-600">Saved</span>}
        </div>
        <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
          <X size={18} />
        </button>
      </div>

      {/* Progress bar (Phase 1 only) */}
      {view === 'phase1' && (
        <div className="px-6 pt-5 pb-2 max-w-3xl mx-auto w-full">
          <div className="flex items-center gap-1 mb-3">
            {PHASE1_STEPS.map((s, i) => {
              const done = s.isComplete(progress[s.id] || {});
              const active = i === currentStepIdx;
              return (
                <button
                  key={s.id}
                  onClick={() => done || i < currentStepIdx ? setCurrentStepIdx(i) : null}
                  className={`flex-1 h-1.5 rounded-full transition-colors ${done ? 'bg-accent' : active ? 'bg-accent/50' : 'bg-border'}`}
                />
              );
            })}
          </div>
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Phase 1 — Step {currentStepIdx + 1} of {PHASE1_STEPS.length}</span>
            <span className="text-accent font-medium">{currentStep?.owner}</span>
          </div>
        </div>
      )}

      {/* Phase 2 header */}
      {view === 'phase2' && (
        <div className="px-6 pt-5 pb-2 max-w-3xl mx-auto w-full">
          <div className="w-full h-1.5 rounded-full bg-accent mb-3" />
          <div className="text-xs text-muted-foreground">Phase 2 — Parallel Team Setup</div>
        </div>
      )}

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-6 py-6 max-w-3xl mx-auto w-full">
        {view === 'phase1' && currentStep && (
          <>
            <div className="mb-6">
              <h2 className="font-dm font-bold text-foreground text-2xl mb-1">{currentStep.title}</h2>
              <p className="text-muted-foreground text-sm">{currentStep.subtitle}</p>
            </div>
            <WizardStepRenderer
              step={currentStep}
              client={client}
              data={currentData}
              onChange={(data) => handleStepChange(currentStep.id, data)}
            />
          </>
        )}

        {view === 'phase2' && client && (
          <>
            <div className="mb-6">
              <h2 className="font-dm font-bold text-foreground text-2xl mb-1">Phase 2 — Team Setup</h2>
              <p className="text-muted-foreground text-sm">These sections can be completed simultaneously by different team members.</p>
            </div>
            <Phase2View
              progress={progress}
              client={client}
              onChange={handlePhase2Change}
              onGoToSchedule={() => setView('schedule')}
            />
          </>
        )}

        {view === 'schedule' && client && (
          <>
            <div className="mb-6">
              <h2 className="font-dm font-bold text-foreground text-2xl mb-1">Schedule Setup</h2>
              <p className="text-muted-foreground text-sm">Set the day, time and employee for every block. This creates the recurring schedule.</p>
            </div>
            <ScheduleSetupStep
              client={client}
              onSave={handleScheduleSave}
              onSaveAndFinish={handleScheduleSaveAndFinish}
            />
          </>
        )}

        {view === 'complete' && client && (
          <OnboardingCompletion
            client={client}
            progress={progress}
            onActivate={handleActivate}
            saving={saving}
          />
        )}
      </div>

      {/* Footer nav */}
      {['phase1', 'phase2', 'schedule'].includes(view) && (
        <div className="sticky bottom-0 bg-card border-t border-border px-6 py-4 flex justify-between items-center max-w-3xl mx-auto w-full">
          <button
            onClick={handleBack}
            disabled={view === 'phase1' && currentStepIdx === 0}
            className="flex items-center gap-2 px-4 py-2 border border-border rounded-lg text-sm font-medium text-foreground hover:bg-secondary disabled:opacity-30 transition-colors"
          >
            <ArrowLeft size={15} /> Back
          </button>

          {view === 'phase1' && (
            <button
              onClick={handleNext}
              disabled={!stepComplete}
              className="flex items-center gap-2 px-5 py-2 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accent/90 disabled:opacity-40 transition-colors"
            >
              {currentStepIdx === PHASE1_STEPS.length - 1 ? 'Continue to Phase 2' : 'Next'}
              <ArrowRight size={15} />
            </button>
          )}

          {view === 'phase2' && (
            <button
              onClick={handleActivate}
              disabled={!allDone || saving}
              className="flex items-center gap-2 px-5 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 disabled:opacity-40 transition-colors"
            >
              {saving ? 'Finishing...' : 'Finish Onboarding'}
            </button>
          )}
        </div>
      )}
    </div>
  );
}