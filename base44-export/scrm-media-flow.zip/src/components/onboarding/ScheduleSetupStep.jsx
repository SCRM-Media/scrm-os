import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { ROLE_FOR_BLOCK } from '@/lib/calendarBlocks';
import ScheduleDragDropEditor from '@/components/schedule/ScheduleDragDropEditor';

const WEEK_0_BLOCK_TYPES = new Set([
  'Content Planning Block',
  'Strategy Meeting',
  'Ad Scripting Block',
  'Meta Ad Setup Block',
]);

function mapFrequencyFromTemplate(tpl) {
  if (tpl.repeat_frequency === 'Weekly') return 'Weekly';
  if (tpl.repeat_frequency === 'Fortnightly') return 'Fortnightly';
  if (tpl.repeat_frequency === 'Monthly') {
    if (tpl.week_of_month === 'before' || WEEK_0_BLOCK_TYPES.has(tpl.block_type)) return 'Monthly Week 0';
    return 'Monthly Week 1';
  }
  return tpl.repeat_frequency;
}

export default function ScheduleSetupStep({ client, onSave, onSaveAndFinish }) {
  const [employees, setEmployees] = useState([]);
  const [packages, setPackages] = useState([]);
  const [allRules, setAllRules] = useState([]);
  const [packageBlocks, setPackageBlocks] = useState([]);
  const [placedRows, setPlacedRows] = useState([]);
  const [isValid, setIsValid] = useState(false);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      const [emps, pkgs, rules] = await Promise.all([
        base44.entities.Employee.list(),
        base44.entities.Package.list(),
        base44.entities.BlockRule.list(),
      ]);
      setEmployees(emps);
      setPackages(pkgs);
      setAllRules(rules);

      const pkg = pkgs.find(p => p.name === client?.package);
      if (pkg?.blocks) {
        const seen = new Set();
        const blocks = [];
        pkg.blocks.forEach(tpl => {
          if (!seen.has(tpl.block_type)) {
            seen.add(tpl.block_type);
            blocks.push({
              block_type: tpl.block_type,
              duration_minutes: tpl.duration_minutes || 60,
              repeat_frequency: mapFrequencyFromTemplate(tpl),
              role: ROLE_FOR_BLOCK[tpl.block_type] || '',
            });
          }
        });
        setPackageBlocks(blocks);
      }
      setLoading(false);
    };
    load();
  }, [client]);

  const handleChange = (rows, valid) => {
    setPlacedRows(rows);
    setIsValid(valid);
  };

  const saveRules = async () => {
    const ruleStartDate = client.cycle_start_date;
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
    await Promise.all(placedRows.map(async r => {
      const ruleData = {
        client: client.id,
        block_type: r.block_type,
        role: r.role,
        employee: r.employee || null,
        duration_minutes: r.duration_minutes,
        day_of_week: r.day_of_week,
        start_time: r.start_time,
        repeat_frequency: r.repeat_frequency,
        rule_start_date: ruleStartDate,
      };
      if (r.existingRuleId) {
        await base44.entities.BlockRule.update(r.existingRuleId, { rule_end_date: yesterday });
        await base44.entities.BlockRule.create({ ...ruleData });
      } else {
        await base44.entities.BlockRule.create(ruleData);
      }
    }));
  };

  const handleSave = async () => {
    setSaving(true);
    await saveRules();
    setSaving(false);
    onSave && onSave();
  };

  const handleSaveAndFinish = async () => {
    setSaving(true);
    await saveRules();
    setSaving(false);
    onSaveAndFinish && onSaveAndFinish();
  };

  if (loading) return <div className="text-xs text-muted-foreground">Loading schedule setup...</div>;

  if (packageBlocks.length === 0) {
    return <div className="text-sm text-muted-foreground italic">No package assigned to this client.</div>;
  }

  return (
    <div className="space-y-4">
      <div className="text-sm text-muted-foreground bg-blue-50 border border-blue-200 rounded-xl px-4 py-3">
        Drag block types from the left panel onto the calendar. Click a placed block to assign an employee.
      </div>

      <ScheduleDragDropEditor
        packageBlocks={packageBlocks}
        employees={employees}
        allRules={allRules}
        clientId={client.id}
        initialPlaced={[]}
        onChange={handleChange}
        clientCycleStartDate={client.cycle_start_date}
      />

      <div className="flex gap-3">
        <button
          onClick={handleSave}
          disabled={!isValid || saving}
          className="flex-1 py-3 border border-border text-foreground rounded-xl font-dm font-semibold text-sm hover:bg-secondary disabled:opacity-40 transition-colors"
        >
          {saving ? 'Saving...' : 'Save'}
        </button>
        <button
          onClick={handleSaveAndFinish}
          disabled={!isValid || saving}
          className="flex-1 py-3 bg-accent text-white rounded-xl font-dm font-semibold text-sm hover:bg-accent/90 disabled:opacity-40 transition-colors"
        >
          {saving ? 'Saving...' : 'Save and Finish'}
        </button>
      </div>
    </div>
  );
}