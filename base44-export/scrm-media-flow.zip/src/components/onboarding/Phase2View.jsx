import { getSectionsForClient, isSectionComplete, isPhase2Complete } from '@/lib/wizardSteps.js';
import SectionSMM from './phase2/SectionSMM';
import SectionMarketing from './phase2/SectionMarketing';
import SectionInventory from './phase2/SectionInventory';
import SectionOps from './phase2/SectionOps';
import { CheckCircle2 } from 'lucide-react';

const SECTION_COMPONENTS = {
  smm: SectionSMM,
  marketing: SectionMarketing,
  ops: SectionOps,
  inventory: SectionInventory,
};

export default function Phase2View({ progress, client, onChange, onGoToSchedule }) {
  const sections = getSectionsForClient(client);

  const handleTaskChange = (taskId, data) => {
    onChange(taskId, data);
  };

  return (
    <div className="space-y-8">
      <div className="bg-primary/5 border border-primary/20 rounded-xl px-5 py-4">
        <p className="text-sm text-foreground font-medium">The following steps can be completed at the same time by different team members. Each person completes their own section.</p>
      </div>

      {sections.map(section => {
        const SectionComp = SECTION_COMPONENTS[section.id];
        const complete = isSectionComplete(section.id, progress, client);

        return (
          <div key={section.id} className={`rounded-2xl border-2 overflow-hidden ${complete ? 'border-green-300' : 'border-border'}`}>
            {/* Section header */}
            <div className={`px-5 py-4 flex items-start justify-between ${complete ? 'bg-green-50' : 'bg-secondary/40'}`}>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  {complete && <CheckCircle2 size={16} className="text-green-500" />}
                  <h3 className="font-dm font-bold text-foreground text-sm">{section.label}</h3>
                </div>
                <div className="text-xs font-semibold text-accent">{section.role}</div>
                <p className="text-xs text-muted-foreground mt-0.5">{section.subtitle}</p>
              </div>
              {complete && (
                <span className="text-xs font-semibold text-green-700 bg-green-100 px-2.5 py-1 rounded-full shrink-0">Complete</span>
              )}
            </div>

            {/* Section content */}
            <div className="px-5 py-4">
              {SectionComp ? (
                <SectionComp
                  progress={progress}
                  onChange={handleTaskChange}
                  client={client}
                  onGoToSchedule={section.id === 'ops' ? onGoToSchedule : undefined}
                />
              ) : (
                <p className="text-xs text-muted-foreground">Section coming soon.</p>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}