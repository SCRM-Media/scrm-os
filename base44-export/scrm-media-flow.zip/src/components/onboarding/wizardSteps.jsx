// Wizard step definitions — Phase 1 (sequential) + Phase 2 (parallel sections)

// Phase 1 sequential steps
export const PHASE1_STEPS = [
  {
    id: 'dealership',
    title: 'Dealership Details',
    subtitle: 'Start here — fill in the basics for this new client.',
    owner: '👤 Operations Manager',
    isComplete: (d) => !!(d.dealership_name && d.state && d.address),
  },
  {
    id: 'contact',
    title: 'Primary Contact',
    subtitle: 'Who is the main person we deal with at this dealership?',
    owner: '👤 Operations Manager',
    isComplete: (d) => !!(d.full_name && d.position && d.phone && d.email),
  },
  {
    id: 'package',
    title: 'Package and Invoice',
    subtitle: 'Select the package and confirm pricing. The total calculates automatically.',
    owner: '👤 Operations Manager',
    isComplete: (d) => !!(d.package),
  },
  {
    id: 'agreement',
    title: 'Service Agreement',
    subtitle: 'The service agreement must be sent and signed before production begins.',
    owner: '👤 Operations Manager',
    isComplete: (d) => !!(d.agreement_sent && d.agreement_signed && d.date_signed),
  },
  {
    id: 'invoice',
    title: 'First Invoice',
    subtitle: 'Send the first invoice to the primary contact via Xero before onboarding continues.',
    owner: '👤 Operations Manager',
    isComplete: (d) => !!(d.invoice_sent),
  },
  {
    id: 'meeting',
    title: 'Onboarding Meeting',
    subtitle: 'Book and run the onboarding meeting with all relevant parties.',
    owner: '👤 Operations Manager',
    isComplete: (d) => !!(d.meeting_date && d.meeting_time && d.meeting_completed && d.meeting_calendar),
  },
  {
    id: 'questionnaire',
    title: 'Onboarding Questionnaire',
    subtitle: 'Complete the questionnaire with the client during or after the meeting.',
    owner: '👤 Social Media Manager + Marketing Manager',
    isComplete: (d) => !!(d.questionnaire_done),
  },
  {
    id: 'cycle_start',
    title: 'Monthly Cycle Start Date',
    subtitle: "Set the Monday this client's content cycle begins.",
    owner: '👤 Social Media Manager',
    isComplete: (d) => !!(d.cycle_start_date),
  },
];

// Phase 2 parallel sections
export const PHASE2_SECTIONS = [
  {
    id: 'smm',
    label: 'Section A — Social Media Manager Tasks',
    role: '👤 Social Media Manager',
    subtitle: 'These steps are owned by the Social Media Manager.',
    alwaysShow: true,
    tasks: ['smm_metricool', 'smm_platforms', 'smm_calendar', 'smm_first_meeting'],
  },
  {
    id: 'marketing',
    label: 'Section B — Marketing Manager Tasks',
    role: '👤 Marketing Manager',
    subtitle: 'Only required for Dominate and Partner packages.',
    showIf: (client) => ['Dominate', 'Partner'].includes(client?.package),
    tasks: ['mkt_meta', 'mkt_ad_account'],
  },
  {
    id: 'ops',
    label: 'Section C — Operations Manager Tasks',
    role: '👤 Operations Manager',
    subtitle: 'These steps are owned by the Operations Manager.',
    alwaysShow: true,
    tasks: ['ops_calendar_blocks'],
  },
  {
    id: 'inventory',
    label: 'Section D — Inventory Add-On Setup',
    role: '👤 Operations Manager',
    subtitle: 'Additional setup required for inventory add-ons.',
    showIf: (client) => {
      const addOns = client?.add_ons || [];
      return addOns.includes('Inventory Photography') || addOns.includes('CarBee Filming') || addOns.includes('Inventory Videos');
    },
    tasks: ['inv_setup'],
  },
];

export function getSectionsForClient(client) {
  return PHASE2_SECTIONS.filter(s => s.alwaysShow || (s.showIf && s.showIf(client)));
}

export function isSectionComplete(sectionId, progress, client) {
  const s = PHASE2_SECTIONS.find(x => x.id === sectionId);
  if (!s) return false;
  return s.tasks.every(taskId => isTaskComplete(taskId, progress[taskId] || {}, client));
}

export function isTaskComplete(taskId, d, client) {
  switch (taskId) {
    case 'smm_metricool': return !!(d.brand_added && d.admin_added);
    case 'smm_platforms': return !!(d.fb_connected && d.ig_connected && d.tiktok_connected);
    case 'smm_calendar': return !!(d.calendar_created && d.brand_pack_created);
    case 'smm_first_meeting': return !!(d.first_meeting_date && d.meeting_calendar_confirmed);
    case 'mkt_meta': return !!(d.meta_logged_in && d.partner_access && d.ig_connected && d.partial_confirmed);
    case 'mkt_ad_account': return !!(d.ad_account_added && d.partial_confirmed);
    case 'ops_calendar_blocks': return !!(d.all_blocks_created);
    case 'inv_setup': return !!(d.sheet_setup && d.account_created && d.gmail_sent && d.platform_logged_in && d.sheet_shared && d.drive_bookmark && d.cheatsheet_created);
    default: return false;
  }
}

export function isPhase2Complete(progress, client) {
  const sections = getSectionsForClient(client);
  return sections.every(s => isSectionComplete(s.id, progress, client));
}

export function loadProgress(client) {
  return client?.onboarding_progress || {};
}

export function getPhase1Progress(progress) {
  return PHASE1_STEPS.findIndex(s => !s.isComplete(progress[s.id] || {}));
}

export function isPhase1Complete(progress) {
  return PHASE1_STEPS.every(s => s.isComplete(progress[s.id] || {}));
}