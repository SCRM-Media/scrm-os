import { isTaskComplete } from '@/lib/wizardSteps.js';
import TaskBlock from './TaskBlock';
import { CalendarClock, CheckCircle2 } from 'lucide-react';

function CheckRow({ label, checked, onChange }) {
  return (
    <label className="flex items-start gap-3 py-2 cursor-pointer group">
      <input
        type="checkbox"
        checked={!!checked}
        onChange={e => onChange(e.target.checked)}
        className="mt-0.5 h-4 w-4 rounded border-border accent-accent shrink-0"
      />
      <span className={`text-sm transition-colors ${checked ? 'line-through text-muted-foreground' : 'text-foreground'}`}>{label}</span>
    </label>
  );
}

export default function SectionOps({ progress, onChange, client, onGoToSchedule }) {
  const cycleData = progress['ops_cycle_start'] || {};
  const setCycleData = (data) => onChange('ops_cycle_start', data);

  const opsData = progress['ops_blocks'] || {};
  const scheduleFinished = !!opsData.schedule_finished;

  const invData = progress['inv_setup'] || {};
  const setInvData = (data) => onChange('inv_setup', data);

  return (
    <div className="space-y-4">
      {/* C1 — Monthly Cycle Start Date */}
      <TaskBlock
        title="C1 — Monthly Cycle Start Date"
        complete={isTaskComplete('ops_cycle_start', cycleData)}
      >
        <div className="py-2 space-y-3">
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Cycle Start Date (must be a Monday)</label>
            <input
              type="date"
              value={cycleData.cycle_start_date || ''}
              onChange={e => setCycleData({ ...cycleData, cycle_start_date: e.target.value })}
              className="input-base"
            />
            {cycleData.cycle_start_date && (
              <p className="text-xs text-muted-foreground mt-1.5">
                This client's 28-day content cycle will begin on <span className="font-semibold text-foreground">{cycleData.cycle_start_date}</span>.
              </p>
            )}
          </div>
        </div>
      </TaskBlock>

      {/* C2 — Assign People & Organize Times */}
      <TaskBlock
        title="C2 — Assign People & Organize Block Times"
        complete={scheduleFinished}
      >
        {scheduleFinished ? (
          <div className="flex items-center gap-2 py-2 text-sm text-green-700">
            <CheckCircle2 size={16} className="text-green-500" />
            Schedule has been set up and saved.
          </div>
        ) : (
          <p className="text-xs text-muted-foreground mb-3">
            Open the timetable to assign team members to each block and set their times.
          </p>
        )}
        <button
          onClick={onGoToSchedule}
          className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors mt-1"
        >
          <CalendarClock size={15} />
          {scheduleFinished ? 'Edit Timetable' : 'Set Up Timetable'}
        </button>
      </TaskBlock>

      {/* C3 — Inventory Setup (optional) */}
      <TaskBlock
        title="C3 — Inventory Setup (Optional)"
        complete={isTaskComplete('inv_setup', invData)}
      >
        <p className="text-xs text-muted-foreground mb-3">
          Complete these steps if this client has an inventory add-on. This section is optional.
        </p>
        <div className="space-y-1">
          <CheckRow label="Set up Google Sheet" checked={invData.sheet_setup} onChange={v => setInvData({ ...invData, sheet_setup: v })} />
          <CheckRow label="Create Google Chrome Profile" checked={invData.chrome_profile} onChange={v => setInvData({ ...invData, chrome_profile: v })} />
          <CheckRow label="Set up uploading on chosen platform" checked={invData.platform_setup} onChange={v => setInvData({ ...invData, platform_setup: v })} />
          <CheckRow label="Log into new account on platform and save credentials" checked={invData.platform_logged_in} onChange={v => setInvData({ ...invData, platform_logged_in: v })} />
          <CheckRow label="Share inventory tracking Google Sheet to new account" checked={invData.sheet_shared} onChange={v => setInvData({ ...invData, sheet_shared: v })} />
          <CheckRow label="Bookmark Google Drive and create 'Inventory Photos' folder" checked={invData.drive_bookmark} onChange={v => setInvData({ ...invData, drive_bookmark: v })} />
        </div>
      </TaskBlock>
    </div>
  );
}