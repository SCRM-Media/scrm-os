import { isTaskComplete } from '@/components/onboarding/wizardSteps';
import TaskBlock from './TaskBlock';

function CheckRow({ label, checked, onChange }) {
  return (
    <label className="flex items-start gap-3 py-2 cursor-pointer group">
      <input
        type="checkbox"
        checked={!!checked}
        onChange={e => onChange(e.target.checked)}
        className="mt-0.5 h-4 w-4 rounded border-border accent-accent shrink-0"
      />
      <span className={`text-sm transition-colors ${checked ? 'line-through text-muted-foreground' : 'text-foreground'}`}>{label}</span>
    </label>
  );
}

export default function SectionMarketing({ progress, onChange }) {
  const get = (taskId) => progress[taskId] || {};
  const set = (taskId, data) => onChange(taskId, data);

  return (
    <div className="space-y-4">
      <TaskBlock
        title="B1 — Meta Business Portfolio Access"
        complete={isTaskComplete('mkt_meta', get('mkt_meta'))}
      >
        <CheckRow label="Logged into Meta Business Suite" checked={get('mkt_meta').meta_logged_in} onChange={v => set('mkt_meta', { ...get('mkt_meta'), meta_logged_in: v })} />
        <CheckRow label="Partner access granted — Partner ID: 1284234112252386" checked={get('mkt_meta').partner_access} onChange={v => set('mkt_meta', { ...get('mkt_meta'), partner_access: v })} />
        <CheckRow label="Instagram connected to Business Suite via Account > Pages > Connect Assets" checked={get('mkt_meta').ig_connected} onChange={v => set('mkt_meta', { ...get('mkt_meta'), ig_connected: v })} />
        <CheckRow label="Partial access confirmed" checked={get('mkt_meta').partial_confirmed} onChange={v => set('mkt_meta', { ...get('mkt_meta'), partial_confirmed: v })} />
      </TaskBlock>

      <TaskBlock
        title="B2 — Ad Account Access"
        complete={isTaskComplete('mkt_ad_account', get('mkt_ad_account'))}
      >
        <CheckRow label="Ad account added via Business Suite > Settings > Ad Accounts > Add Partner > Business ID — all partial access" checked={get('mkt_ad_account').ad_account_added} onChange={v => set('mkt_ad_account', { ...get('mkt_ad_account'), ad_account_added: v })} />
        <CheckRow label="Ad account partial access confirmed" checked={get('mkt_ad_account').partial_confirmed} onChange={v => set('mkt_ad_account', { ...get('mkt_ad_account'), partial_confirmed: v })} />
      </TaskBlock>
    </div>
  );
}