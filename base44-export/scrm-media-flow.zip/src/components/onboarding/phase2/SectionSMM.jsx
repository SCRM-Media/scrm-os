import { isTaskComplete } from '@/lib/wizardSteps.js';
import TaskBlock from './TaskBlock';

function CheckRow({ label, checked, onChange }) {
  return (
    <label className="flex items-start gap-3 py-2 cursor-pointer group">
      <input
        type="checkbox"
        checked={!!checked}
        onChange={e => onChange(e.target.checked)}
        className="mt-0.5 h-4 w-4 rounded border-border accent-accent shrink-0"
      />
      <span className={`text-sm transition-colors ${checked ? 'line-through text-muted-foreground' : 'text-foreground group-hover:text-foreground'}`}>{label}</span>
    </label>
  );
}

export default function SectionSMM({ progress, onChange }) {
  const get = (taskId) => progress[taskId] || {};
  const set = (taskId, data) => onChange(taskId, data);

  return (
    <div className="space-y-4">
      <TaskBlock
        title="A1 — Metricool Setup"
        complete={isTaskComplete('smm_metricool', get('smm_metricool'))}
      >
        <CheckRow label="Dealership added to empty brand slot on Metricool" checked={get('smm_metricool').brand_added} onChange={v => set('smm_metricool', { ...get('smm_metricool'), brand_added: v })} />
        <CheckRow label="Dealership added as admin to the Metricool brand" checked={get('smm_metricool').admin_added} onChange={v => set('smm_metricool', { ...get('smm_metricool'), admin_added: v })} />
      </TaskBlock>

      <TaskBlock
        title="A2 — Platform Access"
        complete={isTaskComplete('smm_platforms', get('smm_platforms'))}
      >
        <CheckRow label="Facebook page connected" checked={get('smm_platforms').fb_connected} onChange={v => set('smm_platforms', { ...get('smm_platforms'), fb_connected: v })} />
        <CheckRow label="Instagram account connected" checked={get('smm_platforms').ig_connected} onChange={v => set('smm_platforms', { ...get('smm_platforms'), ig_connected: v })} />
        <CheckRow label="TikTok account connected" checked={get('smm_platforms').tiktok_connected} onChange={v => set('smm_platforms', { ...get('smm_platforms'), tiktok_connected: v })} />
      </TaskBlock>

      <TaskBlock
        title="A3 — Content Calendar"
        complete={isTaskComplete('smm_calendar', get('smm_calendar'))}
      >
        <CheckRow label="Brand pack created based on questionnaire responses" checked={get('smm_calendar').brand_pack_created} onChange={v => set('smm_calendar', { ...get('smm_calendar'), brand_pack_created: v })} />
      </TaskBlock>

      <TaskBlock
        title="A4 — Onboarding Questionnaire"
        complete={isTaskComplete('smm_questionnaire', get('smm_questionnaire'))}
      >
        <CheckRow
          label="Onboarding questionnaire completed with client"
          checked={get('smm_questionnaire').questionnaire_done}
          onChange={v => set('smm_questionnaire', { ...get('smm_questionnaire'), questionnaire_done: v })}
        />
      </TaskBlock>
    </div>
  );
}