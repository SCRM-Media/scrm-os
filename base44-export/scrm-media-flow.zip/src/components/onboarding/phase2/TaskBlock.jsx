import { CheckCircle2 } from 'lucide-react';

export default function TaskBlock({ title, complete, children }) {
  return (
    <div className={`rounded-xl border p-4 ${complete ? 'border-green-300 bg-green-50' : 'border-border bg-card'}`}>
      <div className="flex items-center justify-between mb-3">
        <h4 className="text-sm font-semibold text-foreground">{title}</h4>
        {complete && <CheckCircle2 size={16} className="text-green-500 shrink-0" />}
      </div>
      <div className="divide-y divide-border/40">
        {children}
      </div>
    </div>
  );
}