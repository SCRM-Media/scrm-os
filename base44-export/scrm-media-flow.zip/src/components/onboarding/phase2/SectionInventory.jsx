import { isTaskComplete } from '@/components/onboarding/wizardSteps';
import TaskBlock from './TaskBlock';

function CheckRow({ label, checked, onChange }) {
  return (
    <label className="flex items-start gap-3 py-2 cursor-pointer group">
      <input
        type="checkbox"
        checked={!!checked}
        onChange={e => onChange(e.target.checked)}
        className="mt-0.5 h-4 w-4 rounded border-border accent-accent shrink-0"
      />
      <span className={`text-sm transition-colors ${checked ? 'line-through text-muted-foreground' : 'text-foreground'}`}>{label}</span>
    </label>
  );
}

export default function SectionInventory({ progress, onChange }) {
  const d = progress['inv_setup'] || {};
  const set = (data) => onChange('inv_setup', data);

  return (
    <div className="space-y-4">
      <TaskBlock
        title="D1 — Inventory Setup"
        complete={isTaskComplete('inv_setup', d)}
      >
        <CheckRow label="Google Sheet inventory tracking set up" checked={d.sheet_setup} onChange={v => set({ ...d, sheet_setup: v })} />
        <CheckRow label="New Google Account created via Chrome > Chrome Profile" checked={d.account_created} onChange={v => set({ ...d, account_created: v })} />
        <CheckRow label="New Gmail sent to dealership contact to create upload account" checked={d.gmail_sent} onChange={v => set({ ...d, gmail_sent: v })} />
        <CheckRow label="Logged into chosen platform on new Google Account" checked={d.platform_logged_in} onChange={v => set({ ...d, platform_logged_in: v })} />
        <CheckRow label="Inventory tracking sheet shared to new Google Account" checked={d.sheet_shared} onChange={v => set({ ...d, sheet_shared: v })} />
        <CheckRow label="Drive bookmark created and Inventory Photos folder added" checked={d.drive_bookmark} onChange={v => set({ ...d, drive_bookmark: v })} />
        <CheckRow label="Cheat sheet created and Chrome account login supplied to dealership" checked={d.cheatsheet_created} onChange={v => set({ ...d, cheatsheet_created: v })} />
      </TaskBlock>
    </div>
  );
}