import { useState } from 'react';
import { X } from 'lucide-react';

export default function PlanningMeetingModal({ meeting, onSave, onClose }) {
  const today = new Date();
  const defaultMonth = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;

  const [form, setForm] = useState({
    month: meeting?.month || defaultMonth,
    meeting_date: meeting?.meeting_date || '',
    status: meeting?.status || 'Scheduled',
    notes: meeting?.notes || '',
  });

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(form);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
      <div className="bg-card rounded-2xl border border-border shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <h2 className="font-dm font-bold text-foreground">{meeting ? 'Edit Meeting' : 'Add Planning Meeting'}</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X size={18} /></button>
        </div>
        <form onSubmit={handleSubmit} className="px-6 py-5 space-y-4">
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Month (YYYY-MM) *</label>
            <input required value={form.month} onChange={e => set('month', e.target.value)}
              className="input-base" placeholder="2026-05" pattern="\d{4}-\d{2}" />
          </div>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Meeting Date</label>
            <input type="date" value={form.meeting_date} onChange={e => set('meeting_date', e.target.value)} className="input-base" />
          </div>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Status</label>
            <select value={form.status} onChange={e => set('status', e.target.value)} className="input-base">
              {['Scheduled', 'Completed', 'Cancelled'].map(s => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Notes</label>
            <textarea value={form.notes} onChange={e => set('notes', e.target.value)}
              className="input-base resize-none h-20" placeholder="Meeting notes..." />
          </div>
          <div className="flex gap-3 pt-1">
            <button type="button" onClick={onClose}
              className="flex-1 px-4 py-2 rounded-lg border border-border text-sm font-medium text-foreground hover:bg-secondary transition-colors">
              Cancel
            </button>
            <button type="submit"
              className="flex-1 px-4 py-2 rounded-lg bg-accent text-white text-sm font-medium hover:bg-accent/90 transition-colors">
              {meeting ? 'Save' : 'Add Meeting'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}