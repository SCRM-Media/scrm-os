import StepField from '@/components/onboarding/StepField';
import WizardCheckbox from '@/components/onboarding/WizardCheckbox';

export default function StepAgreement({ data, onChange }) {
  const set = (k, v) => onChange({ ...data, [k]: v });
  return (
    <div className="bg-card rounded-xl border border-border p-6 space-y-5">
      <WizardCheckbox
        checked={!!data.agreement_signed}
        onChange={v => set('agreement_signed', v)}
        label="Service agreement has been sent to the client and is signed"
      />
      <StepField label="Date Signed">
        <input type="date" value={data.date_signed || ''} onChange={e => set('date_signed', e.target.value)} className="input-base" />
      </StepField>
    </div>
  );
}