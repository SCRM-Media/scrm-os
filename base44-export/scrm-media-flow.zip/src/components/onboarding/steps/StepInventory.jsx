import WizardCheckbox from '@/components/onboarding/WizardCheckbox';

const ITEMS = [
  { key: 'inventory_sheet', label: 'Google Sheet inventory tracking set up' },
  { key: 'inventory_account', label: 'New Google Account created via Chrome profile' },
  { key: 'inventory_gmail', label: 'New Gmail sent to dealership contact' },
  { key: 'inventory_logged_in', label: 'Logged into platform on new account' },
  { key: 'inventory_shared', label: 'Inventory tracking sheet shared to new account' },
  { key: 'inventory_drive', label: 'Drive bookmark + Inventory Photos folder created' },
  { key: 'inventory_cheatsheet', label: 'Cheat sheet created and Chrome account login supplied' },
];

export default function StepInventory({ data, onChange }) {
  const set = (k, v) => onChange({ ...data, [k]: v });
  return (
    <div className="bg-card rounded-xl border border-border p-6 space-y-3">
      {ITEMS.map(item => (
        <WizardCheckbox key={item.key} checked={!!data[item.key]} onChange={v => set(item.key, v)} label={item.label} />
      ))}
    </div>
  );
}