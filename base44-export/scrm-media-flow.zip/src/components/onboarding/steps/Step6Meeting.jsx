const ATTENDEES = [
  'SCRM Social Media Manager',
  'SCRM Marketing Manager',
  'Dealership Primary Contact',
  'Dealership Marketing Manager',
];

export default function Step6Meeting({ data, onChange }) {
  const set = (k, v) => onChange({ ...data, [k]: v });

  const toggleAttendee = (name) => {
    const current = data.attendees || [];
    const next = current.includes(name)
      ? current.filter(a => a !== name)
      : [...current, name];
    set('attendees', next);
  };

  return (
    <div className="space-y-4">
      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">Meeting Date <span className="text-red-500">*</span></label>
          <input type="date" value={data.meeting_date || ''} onChange={e => set('meeting_date', e.target.value)} className="input-base" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">Meeting Time <span className="text-red-500">*</span></label>
          <input type="time" value={data.meeting_time || ''} onChange={e => set('meeting_time', e.target.value)} className="input-base" />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-foreground mb-2">Attendees</label>
        <div className="space-y-2">
          {ATTENDEES.map(name => (
            <label key={name} className="flex items-center gap-3 p-3 bg-card border border-border rounded-lg cursor-pointer hover:bg-secondary/40 transition-colors">
              <input
                type="checkbox"
                checked={(data.attendees || []).includes(name)}
                onChange={() => toggleAttendee(name)}
                className="h-4 w-4 rounded border-border accent-accent"
              />
              <span className="text-sm text-foreground">{name}</span>
            </label>
          ))}
        </div>
      </div>

      <label className="flex items-start gap-3 p-4 bg-card border border-border rounded-xl cursor-pointer hover:bg-secondary/40 transition-colors">
        <input
          type="checkbox"
          checked={!!data.meeting_completed}
          onChange={e => set('meeting_completed', e.target.checked)}
          className="mt-0.5 h-4 w-4 rounded border-border accent-accent"
        />
        <div className="text-sm font-medium text-foreground">Meeting completed</div>
      </label>

      <label className="flex items-start gap-3 p-4 bg-card border border-border rounded-xl cursor-pointer hover:bg-secondary/40 transition-colors">
        <input
          type="checkbox"
          checked={!!data.meeting_calendar}
          onChange={e => set('meeting_calendar', e.target.checked)}
          className="mt-0.5 h-4 w-4 rounded border-border accent-accent"
        />
        <div>
          <div className="text-sm font-medium text-foreground">Confirmed in Google Calendar</div>
          <div className="text-xs text-muted-foreground mt-0.5">Make sure this meeting is added to Google Calendar for all attendees.</div>
        </div>
      </label>
    </div>
  );
}