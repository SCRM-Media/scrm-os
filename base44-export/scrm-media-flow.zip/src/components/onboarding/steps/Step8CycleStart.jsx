import { useState } from 'react';

function snapToMonday(dateStr) {
  if (!dateStr) return null;
  const [y, m, d] = dateStr.split('-').map(Number);
  const date = new Date(y, m - 1, d);
  const day = date.getDay(); // 0=Sun,1=Mon,...6=Sat
  if (day === 1) return dateStr; // already Monday
  const daysToMon = day === 0 ? 1 : 8 - day;
  date.setDate(date.getDate() + daysToMon);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

function formatDate(str) {
  if (!str) return '';
  const [y, m, d] = str.split('-').map(Number);
  return new Date(y, m - 1, d).toLocaleDateString('en-AU', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
}

export default function Step8CycleStart({ data, onChange }) {
  const [snapNote, setSnapNote] = useState('');

  const handleChange = (e) => {
    const raw = e.target.value;
    if (!raw) {
      onChange({ ...data, cycle_start_date: '' });
      setSnapNote('');
      return;
    }
    const snapped = snapToMonday(raw);
    if (snapped !== raw) {
      setSnapNote(`Cycle start dates must be a Monday. Snapped to ${formatDate(snapped)}.`);
    } else {
      setSnapNote('');
    }
    onChange({ ...data, cycle_start_date: snapped });
  };

  return (
    <div className="space-y-4">
      <div className="bg-secondary/40 border border-border rounded-xl p-4 text-sm text-muted-foreground">
        The cycle start date controls when filming, editing and planning blocks are scheduled each month. <strong className="text-foreground">Must be a Monday.</strong>
      </div>

      <div>
        <label className="block text-sm font-medium text-foreground mb-1.5">Cycle Start Date <span className="text-red-500">*</span></label>
        <input
          type="date"
          value={data.cycle_start_date || ''}
          onChange={handleChange}
          className="input-base"
        />
        {snapNote && (
          <p className="text-xs text-amber-600 mt-1.5 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">{snapNote}</p>
        )}
        {data.cycle_start_date && (
          <p className="text-xs text-green-600 mt-1.5 font-medium">✓ {formatDate(data.cycle_start_date)}</p>
        )}
      </div>
    </div>
  );
}