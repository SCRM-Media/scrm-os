import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import StepField from '@/components/onboarding/StepField';

export default function StepPackage({ data, onChange }) {
  const [packages, setPackages] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.Package.list().then(pkgs => {
      setPackages(pkgs);
      setLoading(false);
    });
  }, []);

  const set = (k, v) => onChange({ ...data, [k]: v });

  return (
    <div className="bg-card rounded-xl border border-border p-6 space-y-4">
      <StepField label="Package *">
        {loading ? (
          <div className="text-sm text-muted-foreground">Loading packages...</div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {packages.map(p => (
              <button
                key={p.id}
                type="button"
                onClick={() => set('package', p.name)}
                className={`py-2.5 px-3 rounded-lg text-sm font-medium border transition-colors ${
                  data.package === p.name
                    ? 'bg-accent text-white border-accent'
                    : 'bg-secondary text-foreground border-border hover:border-accent/40'
                }`}
              >{p.name}</button>
            ))}
          </div>
        )}
      </StepField>
      <StepField label="Monthly Value (AUD)">
        <input type="number" value={data.monthly_value || ''} onChange={e => set('monthly_value', e.target.value)}
          className="input-base" placeholder="e.g. 2500" />
      </StepField>
      <StepField label="Inventory Pricing (if applicable)">
        <input value={data.inventory_pricing || ''} onChange={e => set('inventory_pricing', e.target.value)}
          className="input-base" placeholder="e.g. $500/mo for inventory photography" />
      </StepField>
      <StepField label="Special Conditions / Pricing Notes">
        <textarea value={data.special_conditions || ''} onChange={e => set('special_conditions', e.target.value)}
          className="input-base resize-none h-20" placeholder="Any special conditions agreed with this client..." />
      </StepField>
    </div>
  );
}