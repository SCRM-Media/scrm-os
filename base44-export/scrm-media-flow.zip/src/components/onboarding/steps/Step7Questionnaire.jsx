export default function Step7Questionnaire({ data, onChange }) {
  const set = (k, v) => onChange({ ...data, [k]: v });

  return (
    <div className="space-y-4">
      <label className="flex items-start gap-3 p-4 bg-card border border-border rounded-xl cursor-pointer hover:bg-secondary/40 transition-colors">
        <input
          type="checkbox"
          checked={!!data.questionnaire_done}
          onChange={e => set('questionnaire_done', e.target.checked)}
          className="mt-0.5 h-4 w-4 rounded border-border accent-accent"
        />
        <div>
          <div className="text-sm font-medium text-foreground">Onboarding questionnaire completed with client</div>
          <div className="text-xs text-muted-foreground mt-0.5">Complete the questionnaire document with the client during or immediately after the meeting.</div>
        </div>
      </label>

      <div>
        <label className="block text-sm font-medium text-foreground mb-1.5">Notes (optional)</label>
        <textarea
          value={data.notes || ''}
          onChange={e => set('notes', e.target.value)}
          className="input-base resize-none h-24"
          placeholder="Any key points from the questionnaire to record..."
        />
      </div>
    </div>
  );
}