import { useState } from 'react';

function formatPhone(value) {
  const digits = value.replace(/\D/g, '').slice(0, 10);
  const parts = [];
  if (digits.length > 0) parts.push(digits.slice(0, 4));
  if (digits.length > 4) parts.push(digits.slice(4, 7));
  if (digits.length > 7) parts.push(digits.slice(7, 10));
  return parts.join(' ');
}

export default function Step2Contact({ data, onChange }) {
  const set = (k, v) => onChange({ ...data, [k]: v });

  const handlePhone = (e) => {
    set('phone', formatPhone(e.target.value));
  };

  return (
    <div className="space-y-4">
      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">Full Name <span className="text-red-500">*</span></label>
          <input
            value={data.full_name || ''}
            onChange={e => set('full_name', e.target.value)}
            className="input-base"
            placeholder="e.g. James Wilson"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">Position <span className="text-red-500">*</span></label>
          <input
            value={data.position || ''}
            onChange={e => set('position', e.target.value)}
            className="input-base"
            placeholder="e.g. Marketing Manager"
          />
        </div>
      </div>
      <div>
        <label className="block text-sm font-medium text-foreground mb-1.5">Phone Number <span className="text-red-500">*</span></label>
        <div className="flex gap-2">
          <select
            value={data.country_code || '+61'}
            onChange={e => set('country_code', e.target.value)}
            className="input-base w-28 shrink-0"
          >
            <option value="+61">🇦🇺 +61</option>
            <option value="+1">🇺🇸 +1</option>
            <option value="+44">🇬🇧 +44</option>
            <option value="+64">🇳🇿 +64</option>
          </select>
          <input
            value={data.phone || ''}
            onChange={handlePhone}
            className="input-base flex-1"
            placeholder="0421 362 889"
            type="tel"
          />
        </div>
      </div>
      <div>
        <label className="block text-sm font-medium text-foreground mb-1.5">Email <span className="text-red-500">*</span></label>
        <input
          value={data.email || ''}
          onChange={e => set('email', e.target.value)}
          className="input-base"
          placeholder="james@dealership.com.au"
          type="email"
        />
      </div>
    </div>
  );
}