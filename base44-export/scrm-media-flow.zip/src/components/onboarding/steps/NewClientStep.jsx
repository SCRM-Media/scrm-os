import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Building2 } from 'lucide-react';

export default function NewClientStep({ onCreated, onCancel }) {
  const [form, setForm] = useState({ name: '', location: '', package: 'Minimum', status: 'Onboarding' });
  const [saving, setSaving] = useState(false);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    const client = await base44.entities.Client.create({ ...form, status: 'Onboarding' });
    setSaving(false);
    onCreated(client);
  };

  return (
    <div>
      <div className="flex items-center gap-3 mb-2">
        <div className="w-10 h-10 bg-accent/10 rounded-xl flex items-center justify-center">
          <Building2 size={20} className="text-accent" />
        </div>
        <div>
          <h2 className="font-dm font-bold text-foreground text-xl">New Client</h2>
          <p className="text-sm text-muted-foreground">Start by creating the client record.</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="mt-6 space-y-4 bg-card rounded-xl border border-border p-6">
        <div>
          <label className="block text-xs font-medium text-muted-foreground mb-1.5">Dealership Name *</label>
          <input required value={form.name} onChange={e => set('name', e.target.value)}
            className="input-base" placeholder="e.g. Sunshine Coast Hyundai" />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Location / State</label>
            <input value={form.location} onChange={e => set('location', e.target.value)}
              className="input-base" placeholder="e.g. Queensland" />
          </div>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Package</label>
            <select value={form.package} onChange={e => set('package', e.target.value)} className="input-base">
              {['Minimum', 'Momentum', 'Dominate', 'Partner'].map(p => <option key={p}>{p}</option>)}
            </select>
          </div>
        </div>
        <div className="flex gap-3 pt-2">
          <button type="button" onClick={onCancel}
            className="flex-1 px-4 py-2.5 border border-border rounded-lg text-sm font-medium text-foreground hover:bg-secondary transition-colors">
            Cancel
          </button>
          <button type="submit" disabled={saving}
            className="flex-1 px-4 py-2.5 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accent/90 transition-colors disabled:opacity-50">
            {saving ? 'Creating...' : 'Create & Start Onboarding'}
          </button>
        </div>
      </form>
    </div>
  );
}