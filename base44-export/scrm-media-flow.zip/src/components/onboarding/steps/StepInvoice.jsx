import WizardCheckbox from '@/components/onboarding/WizardCheckbox';

export default function StepInvoice({ data, onChange }) {
  const set = (k, v) => onChange({ ...data, [k]: v });
  return (
    <div className="bg-card rounded-xl border border-border p-6">
      <WizardCheckbox
        checked={!!data.invoice_sent}
        onChange={v => set('invoice_sent', v)}
        label="First invoice sent via Xero to the primary contact"
      />
    </div>
  );
}