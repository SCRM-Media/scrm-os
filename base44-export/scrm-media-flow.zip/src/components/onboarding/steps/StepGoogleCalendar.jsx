import WizardCheckbox from '@/components/onboarding/WizardCheckbox';

export default function StepGoogleCalendar({ data, onChange, client }) {
  const set = (k, v) => onChange({ ...data, [k]: v });
  const isAdvanced = ['Dominate', 'Partner'].includes(client?.package);

  const blocks = [
    { key: 'block_planning', label: 'SMM: 1.25 hours Content Planning Block (monthly, week 0)' },
    { key: 'block_sendoff', label: 'SMM: 15 min Send off/Approvals + 20 min Scheduling/Posting (weekly, 35 min total)' },
    { key: 'block_editing', label: 'Editor: 1.5 hours Social Media Editing Block (weekly)' },
    { key: 'block_filming', label: 'Content Creator: 1.5 hours Social Media Filming Block (weekly)' },
    ...(isAdvanced ? [
      { key: 'block_ad_scripting', label: 'Marketing Manager: 1 hour Ad Scripting + 2 hours Meta Ad Setup (monthly week 0)' },
      { key: 'block_check_ads', label: 'Marketing Manager: 20 min Check Ads and Optimise (weekly)' },
    ] : []),
  ];

  return (
    <div className="bg-card rounded-xl border border-border p-6 space-y-3">
      {isAdvanced && (
        <div className="mb-2 text-xs text-accent font-medium">Includes Dominate/Partner ad blocks</div>
      )}
      {blocks.map(b => (
        <WizardCheckbox key={b.key} checked={!!data[b.key]} onChange={v => set(b.key, v)} label={b.label} />
      ))}
    </div>
  );
}