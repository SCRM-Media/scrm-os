import WizardCheckbox from '@/components/onboarding/WizardCheckbox';

export default function StepMetricool({ data, onChange }) {
  const set = (k, v) => onChange({ ...data, [k]: v });
  return (
    <div className="bg-card rounded-xl border border-border p-6 space-y-3">
      <WizardCheckbox checked={!!data.metricool_brand} onChange={v => set('metricool_brand', v)}
        label="Dealership added to an empty brand on Metricool" />
      <WizardCheckbox checked={!!data.metricool_admin} onChange={v => set('metricool_admin', v)}
        label="Dealership added as admin to the brand" />
    </div>
  );
}