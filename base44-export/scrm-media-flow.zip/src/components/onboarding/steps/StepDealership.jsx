import StepField from '@/components/onboarding/StepField';

export default function StepDealership({ data, onChange }) {
  const set = (k, v) => onChange({ ...data, [k]: v });
  return (
    <div className="bg-card rounded-xl border border-border p-6 space-y-4">
      <StepField label="Dealership Name *">
        <input value={data.dealership_name || ''} onChange={e => set('dealership_name', e.target.value)}
          className="input-base" placeholder="e.g. Melbourne City Toyota" />
      </StepField>
      <div className="grid sm:grid-cols-2 gap-4">
        <StepField label="State *">
          <select value={data.state || ''} onChange={e => set('state', e.target.value)} className="input-base">
            <option value="">Select state...</option>
            {['VIC', 'NSW', 'QLD', 'WA', 'SA', 'TAS', 'NT', 'ACT'].map(s => <option key={s}>{s}</option>)}
          </select>
        </StepField>
        <StepField label="Address">
          <input value={data.address || ''} onChange={e => set('address', e.target.value)}
            className="input-base" placeholder="Street address" />
        </StepField>
      </div>
      <StepField label="Dealer Group (if applicable)">
        <input value={data.dealer_group || ''} onChange={e => set('dealer_group', e.target.value)}
          className="input-base" placeholder="e.g. Autopact Group" />
      </StepField>
    </div>
  );
}