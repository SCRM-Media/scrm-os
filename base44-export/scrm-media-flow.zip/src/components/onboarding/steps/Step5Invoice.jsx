export default function Step5Invoice({ data, onChange, stepData }) {
  const contactName = stepData?.contact?.full_name || 'the primary contact';

  return (
    <div className="space-y-4">
      <div className="bg-secondary/40 border border-border rounded-xl p-4 text-sm text-muted-foreground">
        Send the first invoice via Xero to <strong className="text-foreground">{contactName}</strong> before proceeding.
      </div>
      <label className="flex items-start gap-3 p-4 bg-card border border-border rounded-xl cursor-pointer hover:bg-secondary/40 transition-colors">
        <input
          type="checkbox"
          checked={!!data.invoice_sent}
          onChange={e => onChange({ ...data, invoice_sent: e.target.checked })}
          className="mt-0.5 h-4 w-4 rounded border-border accent-accent"
        />
        <div>
          <div className="text-sm font-medium text-foreground">
            First invoice sent via Xero to {contactName}
          </div>
        </div>
      </label>
    </div>
  );
}