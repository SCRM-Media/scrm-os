import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';

const AU_STATES = ['VIC', 'NSW', 'QLD', 'WA', 'SA', 'TAS', 'NT', 'ACT'];
const ADD_ONS = ['Inventory Photography', 'CarBee Filming', 'Inventory Videos'];

const ADDON_ICONS = {
  'Inventory Photography': '📸',
  'CarBee Filming': '🚗',
  'Inventory Videos': '🎬',
};

function AddOnPricingCard({ label, icon, data, onChange }) {
  const cars = Number(data?.cars_per_month || 0);
  const price = Number(data?.price_per_car || 0);
  const estMonthly = cars && price ? Math.round(cars * price * 1.1) : 0;

  const set = (k, v) => onChange({ ...data, [k]: v });

  return (
    <div className="border border-border rounded-xl p-4 space-y-3 bg-card">
      <div className="text-sm font-semibold text-foreground">{icon} {label}</div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-medium text-muted-foreground mb-1.5">Cars / month</label>
          <input
            type="number"
            value={data?.cars_per_month || ''}
            onChange={e => set('cars_per_month', e.target.value)}
            className="input-base"
            placeholder="e.g. 20"
            min="0"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-muted-foreground mb-1.5">Price / car (ex GST)</label>
          <input
            type="number"
            value={data?.price_per_car || ''}
            onChange={e => set('price_per_car', e.target.value)}
            className="input-base"
            placeholder="e.g. 25"
            min="0"
          />
        </div>
      </div>
      {estMonthly > 0 && (
        <div className="text-sm font-semibold text-accent">
          Est. ${estMonthly.toLocaleString()}/mo incl. GST
        </div>
      )}
    </div>
  );
}

export default function Step1ClientInfo({ data, onChange }) {
  const [packages, setPackages] = useState([]);

  useEffect(() => {
    base44.entities.Package.list().then(setPackages);
  }, []);

  const set = (k, v) => onChange({ ...data, [k]: v });

  const toggleAddon = (addon) => {
    const current = data.add_ons || [];
    const next = current.includes(addon)
      ? current.filter(a => a !== addon)
      : [...current, addon];
    // Clear pricing data for removed addon
    const addonKey = addonDataKey(addon);
    if (!next.includes(addon)) {
      onChange({ ...data, add_ons: next, [addonKey]: undefined });
    } else {
      onChange({ ...data, add_ons: next });
    }
  };

  const addonDataKey = (addon) => {
    if (addon === 'Inventory Photography') return 'addon_inv_photo';
    if (addon === 'CarBee Filming') return 'addon_carbee';
    if (addon === 'Inventory Videos') return 'addon_inv_video';
    return addon;
  };

  const activeAddons = data.add_ons || [];

  // Auto-calculate base price from selected package
  const selectedPkg = packages.find(p => p.name === data.package);
  const basePrice = selectedPkg?.base_price ? Number(selectedPkg.base_price) : 0;
  const addonTotal = activeAddons.reduce((sum, addon) => {
    const key = addonDataKey(addon);
    const addonData = data[key] || {};
    const cars = Number(addonData.cars_per_month || 0);
    const price = Number(addonData.price_per_car || 0);
    return sum + (cars && price ? Math.round(cars * price * 1.1) : 0);
  }, 0);
  const totalMonthly = basePrice + addonTotal;

  return (
    <div className="space-y-5">
      {/* Dealership Name */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-1.5">Dealership Name <span className="text-red-500">*</span></label>
        <input
          value={data.dealership_name || ''}
          onChange={e => set('dealership_name', e.target.value)}
          className="input-base"
          placeholder="e.g. Melbourne City Toyota"
        />
      </div>

      {/* State + Address */}
      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">State <span className="text-red-500">*</span></label>
          <select value={data.state || ''} onChange={e => set('state', e.target.value)} className="input-base">
            <option value="">Select state...</option>
            {AU_STATES.map(s => <option key={s}>{s}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">Address</label>
          <input
            value={data.address || ''}
            onChange={e => set('address', e.target.value)}
            className="input-base"
            placeholder="Street address"
          />
        </div>
      </div>

      {/* Contact */}
      <div className="border border-border rounded-xl p-4 space-y-3 bg-secondary/20">
        <div className="text-sm font-semibold text-foreground">Primary Contact</div>
        <div className="grid sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Full Name <span className="text-red-500">*</span></label>
            <input value={data.contact_name || ''} onChange={e => set('contact_name', e.target.value)} className="input-base" placeholder="e.g. John Smith" />
          </div>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Position <span className="text-red-500">*</span></label>
            <input value={data.contact_position || ''} onChange={e => set('contact_position', e.target.value)} className="input-base" placeholder="e.g. Dealer Principal" />
          </div>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Phone <span className="text-red-500">*</span></label>
            <input value={data.contact_phone || ''} onChange={e => set('contact_phone', e.target.value)} className="input-base" placeholder="04xx xxx xxx" />
          </div>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Email <span className="text-red-500">*</span></label>
            <input value={data.contact_email || ''} onChange={e => set('contact_email', e.target.value)} className="input-base" placeholder="email@dealership.com" />
          </div>
        </div>
      </div>

      {/* Package */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">Package <span className="text-red-500">*</span></label>
        <div className="grid sm:grid-cols-2 gap-2">
          {packages.map(pkg => (
            <button
              key={pkg.id}
              type="button"
              onClick={() => onChange({ ...data, package: pkg.name })}
              className={`flex items-center justify-between px-4 py-3 rounded-xl border text-sm font-medium transition-all ${
                data.package === pkg.name
                  ? 'border-accent bg-accent/5 text-foreground'
                  : 'border-border bg-card hover:border-accent/40 text-foreground'
              }`}
            >
              <span>{pkg.name}</span>
                      {pkg.base_price && (
                <span className={`text-xs font-semibold ${data.package === pkg.name ? 'text-accent' : 'text-muted-foreground'}`}>
                  ${Number(pkg.base_price).toLocaleString()}/mo
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Add-Ons */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">Add-Ons</label>
        <div className="flex flex-wrap gap-2 mb-4">
          {ADD_ONS.map(addon => (
            <button
              key={addon}
              type="button"
              onClick={() => toggleAddon(addon)}
              className={`px-3 py-1.5 rounded-full text-sm font-medium border transition-colors ${
                activeAddons.includes(addon)
                  ? 'bg-accent text-white border-accent'
                  : 'bg-secondary text-muted-foreground border-border hover:border-accent/50'
              }`}
            >
              {addon}
            </button>
          ))}
        </div>

        {/* Pricing cards for active add-ons */}
        {activeAddons.length > 0 && (
          <div className="space-y-3">
            {activeAddons.map(addon => (
              <AddOnPricingCard
                key={addon}
                label={addon}
                icon={ADDON_ICONS[addon] || ''}
                data={data[addonDataKey(addon)] || {}}
                onChange={v => onChange({ ...data, [addonDataKey(addon)]: v })}
              />
            ))}
          </div>
        )}
      </div>

      {/* Total */}
      {(basePrice > 0 || addonTotal > 0) && (
        <div className="bg-primary text-primary-foreground rounded-xl px-5 py-4">
          <div className="text-xs opacity-70 mb-1">Est. Monthly Value</div>
          <div className="text-2xl font-dm font-bold">${totalMonthly.toLocaleString('en-AU', { maximumFractionDigits: 0 })}</div>
          <div className="text-xs opacity-60 mt-0.5 space-y-0.5">
            {basePrice > 0 && <div>{data.package} package: ${basePrice.toLocaleString()}/mo</div>}
            {addonTotal > 0 && <div>Add-ons: +${addonTotal.toLocaleString()} (incl. GST)</div>}
          </div>
        </div>
      )}
    </div>
  );
}