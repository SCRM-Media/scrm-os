import WizardCheckbox from '@/components/onboarding/WizardCheckbox';

export default function StepCalendar({ data, onChange }) {
  const set = (k, v) => onChange({ ...data, [k]: v });
  return (
    <div className="bg-card rounded-xl border border-border p-6 space-y-3">
      <WizardCheckbox checked={!!data.calendar_created} onChange={v => set('calendar_created', v)}
        label="Client calendar created in SCRM OS" />
      <WizardCheckbox checked={!!data.brand_pack_created} onChange={v => set('brand_pack_created', v)}
        label="Brand pack created based on questionnaire responses" />
    </div>
  );
}