import StepField from '@/components/onboarding/StepField';
import WizardCheckbox from '@/components/onboarding/WizardCheckbox';

const ATTENDEES = [
  { key: 'att_smm', label: 'SCRM Social Media Manager' },
  { key: 'att_mm', label: 'SCRM Marketing Manager' },
  { key: 'att_dealer', label: 'Dealership Contact' },
  { key: 'att_dealer_mm', label: 'Dealership Marketing Manager' },
];

export default function StepMeeting({ data, onChange }) {
  const set = (k, v) => onChange({ ...data, [k]: v });
  return (
    <div className="bg-card rounded-xl border border-border p-6 space-y-5">
      <StepField label="Meeting Date">
        <input type="date" value={data.meeting_date || ''} onChange={e => set('meeting_date', e.target.value)} className="input-base" />
      </StepField>
      <StepField label="Attendees">
        <div className="space-y-2 mt-1">
          {ATTENDEES.map(a => (
            <WizardCheckbox
              key={a.key}
              checked={!!data[a.key]}
              onChange={v => set(a.key, v)}
              label={a.label}
            />
          ))}
        </div>
      </StepField>
      <WizardCheckbox
        checked={!!data.meeting_completed}
        onChange={v => set('meeting_completed', v)}
        label="Onboarding meeting set up in Google Calendar ✓"
        bold
      />
    </div>
  );
}