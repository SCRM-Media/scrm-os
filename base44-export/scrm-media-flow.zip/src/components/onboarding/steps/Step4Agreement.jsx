export default function Step4Agreement({ data, onChange }) {
  const set = (k, v) => onChange({ ...data, [k]: v });

  return (
    <div className="space-y-4">
      <label className="flex items-start gap-3 p-4 bg-card border border-border rounded-xl cursor-pointer hover:bg-secondary/40 transition-colors">
        <input
          type="checkbox"
          checked={!!data.agreement_sent}
          onChange={e => set('agreement_sent', e.target.checked)}
          className="mt-0.5 h-4 w-4 rounded border-border accent-accent"
        />
        <div>
          <div className="text-sm font-medium text-foreground">Service agreement has been sent to client</div>
          <div className="text-xs text-muted-foreground mt-0.5">Send the standard service agreement document to the primary contact.</div>
        </div>
      </label>

      <label className="flex items-start gap-3 p-4 bg-card border border-border rounded-xl cursor-pointer hover:bg-secondary/40 transition-colors">
        <input
          type="checkbox"
          checked={!!data.agreement_signed}
          onChange={e => set('agreement_signed', e.target.checked)}
          className="mt-0.5 h-4 w-4 rounded border-border accent-accent"
        />
        <div>
          <div className="text-sm font-medium text-foreground">Service agreement has been signed</div>
          <div className="text-xs text-muted-foreground mt-0.5">Production cannot begin until the agreement is signed.</div>
        </div>
      </label>

      {data.agreement_signed && (
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">Date Signed <span className="text-red-500">*</span></label>
          <input
            type="date"
            value={data.date_signed || ''}
            onChange={e => set('date_signed', e.target.value)}
            className="input-base"
          />
        </div>
      )}
    </div>
  );
}