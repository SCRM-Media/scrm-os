import WizardCheckbox from '@/components/onboarding/WizardCheckbox';

export default function StepAdAccount({ data, onChange }) {
  const set = (k, v) => onChange({ ...data, [k]: v });
  return (
    <div className="bg-card rounded-xl border border-border p-6 space-y-3">
      <WizardCheckbox checked={!!data.ad_account_added} onChange={v => set('ad_account_added', v)}
        label="Ad account added via Meta Business Suite" />
      <WizardCheckbox checked={!!data.ad_account_partial} onChange={v => set('ad_account_partial', v)}
        label="Partial access confirmed" />
    </div>
  );
}