import StepField from '@/components/onboarding/StepField';
import WizardCheckbox from '@/components/onboarding/WizardCheckbox';

export default function StepFirstMeeting({ data, onChange }) {
  const set = (k, v) => onChange({ ...data, [k]: v });
  return (
    <div className="bg-card rounded-xl border border-border p-6 space-y-4">
      <StepField label="First Planning Meeting Date">
        <input type="date" value={data.first_meeting_date || ''} onChange={e => set('first_meeting_date', e.target.value)} className="input-base" />
      </StepField>
      <WizardCheckbox checked={!!data.first_meeting_calendar} onChange={v => set('first_meeting_calendar', v)}
        label="Meeting confirmed in Google Calendar" />
    </div>
  );
}