import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { formatDuration } from '@/lib/calendarBlocks';

// Auto-calc: snap to nearest 15 min ceiling
function calcDuration(cars, carsPerHour) {
  if (!cars || !carsPerHour || carsPerHour <= 0) return 0;
  const raw = (cars / carsPerHour) * 60;
  return Math.ceil(raw / 15) * 15;
}

function Toggle({ value, onChange }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!value)}
      className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors shrink-0 ${value ? 'bg-accent' : 'bg-border'}`}
    >
      <span className={`inline-block h-3.5 w-3.5 rounded-full bg-white shadow transition-transform ${value ? 'translate-x-4' : 'translate-x-1'}`} />
    </button>
  );
}

function CarBeeSetup({ data, onChange }) {
  const carsPerSession = Number(data.carbee_cars_per_session || 0);
  const PRODUCTION_RATE = 5; // fixed
  const sessionDur = calcDuration(carsPerSession, PRODUCTION_RATE);
  const h = Math.floor(sessionDur / 60);
  const m = sessionDur % 60;
  const durLabel = sessionDur > 0 ? `${h > 0 ? h + 'h ' : ''}${m > 0 ? m + 'm' : ''}`.trim() : '—';

  const totalStock = Number(data.carbee_total_stock || 0);
  const pct = Number(data.carbee_stock_percentage || 0);
  const targetCars = totalStock && pct ? Math.ceil(totalStock * pct / 100) : 0;
  const turnover = Number(data.carbee_monthly_turnover || 0);
  const minSessions = carsPerSession > 0 && turnover > 0 ? Math.ceil(turnover / carsPerSession) : 0;
  const estimatedMonthlyCarbee = carsPerSession * 25 * (minSessions || 1);

  const set = (k, v) => {
    const updated = { ...data, [k]: v };
    // auto-calc session duration
    const cars = Number(k === 'carbee_cars_per_session' ? v : data.carbee_cars_per_session || 0);
    updated.carbee_session_duration_minutes = calcDuration(cars, PRODUCTION_RATE);
    onChange(updated);
  };

  return (
    <div className="border border-yellow-200 bg-yellow-50 rounded-xl px-4 py-4 space-y-4">
      <div className="text-sm font-semibold text-yellow-800">CarBee Filming Setup</div>

      <div>
        <label className="block text-xs font-medium text-muted-foreground mb-1.5">Model</label>
        <select value={data.carbee_model || ''} onChange={e => set('carbee_model', e.target.value)} className="input-base">
          <option value="">Select model...</option>
          <option value="Recurring Sessions">Recurring Sessions</option>
          <option value="Stock Target">Stock Target</option>
        </select>
      </div>

      {data.carbee_model === 'Recurring Sessions' && (
        <>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Cars Per Session</label>
            <input type="number" value={data.carbee_cars_per_session || ''} onChange={e => set('carbee_cars_per_session', e.target.value)} className="input-base" placeholder="e.g. 10" min="1" />
          </div>
          {sessionDur > 0 && (
            <div className="bg-yellow-100 border border-yellow-200 rounded-lg px-3 py-2 text-xs text-yellow-800">
              Session duration: {carsPerSession} cars ÷ {PRODUCTION_RATE}/hr × 60 = <strong>{sessionDur} min ({durLabel})</strong>
            </div>
          )}
          {minSessions > 0 && (
            <div className="bg-card border border-border rounded-lg px-3 py-2 flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Est. monthly CarBee revenue</span>
              <span className="font-semibold text-foreground">{carsPerSession} cars × $25 × {minSessions} sessions = <strong>${estimatedMonthlyCarbee.toLocaleString()}</strong></span>
            </div>
          )}
        </>
      )}

      {data.carbee_model === 'Stock Target' && (
        <>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Total Stock</label>
              <input type="number" value={data.carbee_total_stock || ''} onChange={e => set('carbee_total_stock', e.target.value)} className="input-base" placeholder="0" />
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Target % of Stock Filmed</label>
              <input type="number" value={data.carbee_stock_percentage || ''} onChange={e => set('carbee_stock_percentage', e.target.value)} className="input-base" placeholder="e.g. 80" min="0" max="100" />
            </div>
          </div>
          {targetCars > 0 && (
            <div className="bg-yellow-100 border border-yellow-200 rounded-lg px-3 py-2 text-xs text-yellow-800">
              Target cars filmed: {totalStock} × {pct}% = <strong>{targetCars} cars</strong>
            </div>
          )}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Cars Per Session</label>
              <input type="number" value={data.carbee_cars_per_session || ''} onChange={e => set('carbee_cars_per_session', e.target.value)} className="input-base" placeholder="e.g. 10" min="1" />
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Monthly Turnover (cars sold)</label>
              <input type="number" value={data.carbee_monthly_turnover || ''} onChange={e => set('carbee_monthly_turnover', e.target.value)} className="input-base" placeholder="0" />
            </div>
          </div>
          {sessionDur > 0 && (
            <div className="bg-yellow-100 border border-yellow-200 rounded-lg px-3 py-2 text-xs text-yellow-800">
              Session duration: {carsPerSession} cars ÷ {PRODUCTION_RATE}/hr = <strong>{durLabel} per session</strong>
              {minSessions > 0 && <span className="ml-2">· Min {minSessions} sessions/month to maintain stock</span>}
            </div>
          )}
        </>
      )}
    </div>
  );
}

function InventorySetup({ data, onChange }) {
  const carsPerSession = Number(data.inventory_cars_per_session || 0);
  const includesVideo = !!data.inventory_includes_video;
  const cphPhotos = Number(data.inventory_cars_per_hour_photos || 0);
  const cphVideo = Number(data.inventory_cars_per_hour_video || 0);
  const effectiveCph = includesVideo ? cphVideo : cphPhotos;
  const sessionDur = calcDuration(carsPerSession, effectiveCph);
  const h = Math.floor(sessionDur / 60);
  const m = sessionDur % 60;
  const durLabel = sessionDur > 0 ? `${h > 0 ? h + 'h ' : ''}${m > 0 ? m + 'm' : ''}`.trim() : '—';

  const set = (k, v) => {
    const updated = { ...data, [k]: v };
    const cars = Number(k === 'inventory_cars_per_session' ? v : data.inventory_cars_per_session || 0);
    const iv = k === 'inventory_includes_video' ? v : !!data.inventory_includes_video;
    const cphP = Number(k === 'inventory_cars_per_hour_photos' ? v : data.inventory_cars_per_hour_photos || 0);
    const cphV = Number(k === 'inventory_cars_per_hour_video' ? v : data.inventory_cars_per_hour_video || 0);
    const eff = iv ? cphV : cphP;
    updated.inventory_session_duration_minutes = calcDuration(cars, eff);
    onChange(updated);
  };

  return (
    <div className="border border-teal-200 bg-teal-50 rounded-xl px-4 py-4 space-y-4">
      <div className="text-sm font-semibold text-teal-800">Inventory Photography Setup</div>

      <div className="flex items-center justify-between">
        <span className="text-xs font-medium text-foreground">Includes Inventory Video</span>
        <Toggle value={includesVideo} onChange={v => set('inventory_includes_video', v)} />
      </div>

      <div>
        <label className="block text-xs font-medium text-muted-foreground mb-1.5">Cars Per Hour — Photos Only<span className="ml-1 opacity-60">(established at discovery visit)</span></label>
        <input type="number" value={data.inventory_cars_per_hour_photos || ''} onChange={e => set('inventory_cars_per_hour_photos', e.target.value)} className="input-base" placeholder="e.g. 5" min="0.5" step="0.5" />
      </div>

      {includesVideo && (
        <>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Cars Per Hour — Photos + Video<span className="ml-1 opacity-60">(lower rate when filming video)</span></label>
            <input type="number" value={data.inventory_cars_per_hour_video || ''} onChange={e => set('inventory_cars_per_hour_video', e.target.value)} className="input-base" placeholder="e.g. 3" min="0.5" step="0.5" />
          </div>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Video Style</label>
            <select value={data.inventory_video_style || ''} onChange={e => set('inventory_video_style', e.target.value)} className="input-base">
              <option value="">Select style...</option>
              <option value="Style 1 Phone Edited On Spot">Style 1 — Phone Edited On Spot</option>
              <option value="Style 2 Camera Edited Next Day">Style 2 — Camera Edited Next Day</option>
            </select>
          </div>
        </>
      )}

      <div>
        <label className="block text-xs font-medium text-muted-foreground mb-1.5">Cars Per Session</label>
        <input type="number" value={data.inventory_cars_per_session || ''} onChange={e => set('inventory_cars_per_session', e.target.value)} className="input-base" placeholder="e.g. 20" min="1" />
      </div>

      {sessionDur > 0 && (
        <div className="bg-teal-100 border border-teal-200 rounded-lg px-3 py-2 text-xs text-teal-800">
          Session duration: {carsPerSession} cars ÷ {effectiveCph}/hr = <strong>{sessionDur} min ({durLabel})</strong>
          {includesVideo && <span className="ml-1 opacity-70">(video rate)</span>}
        </div>
      )}

      <div className="bg-card border border-border rounded-lg px-3 py-2 text-xs text-muted-foreground">
        Pricing set per client — confirm rate separately
      </div>
    </div>
  );
}

export default function Step3Package({ data, onChange }) {
  const [packages, setPackages] = useState([]);

  useEffect(() => {
    base44.entities.Package.list().then(setPackages);
  }, []);

  const set = (k, v) => onChange({ ...data, [k]: v });

  const basePrice = Number(data.base_price || 0);
  const totalMonthly = basePrice;

  const handlePackageSelect = (pkg) => {
    onChange({ ...data, package: pkg.name, base_price: pkg.base_price || 0 });
  };

  // Sync add_ons array
  useEffect(() => {
    const addOns = [];
    if (data.carbee_enabled) addOns.push('CarBee Filming');
    if (data.inventory_enabled) addOns.push('Inventory Photography');
    if (JSON.stringify(addOns) !== JSON.stringify(data.add_ons) || totalMonthly !== data.monthly_value) {
      onChange({ ...data, add_ons: addOns, monthly_value: totalMonthly });
    }
  }, [data.carbee_enabled, data.inventory_enabled, data.base_price, data.package]);

  return (
    <div className="space-y-5">
      {/* Package selection */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">Package <span className="text-red-500">*</span></label>
        <div className="space-y-2">
          {packages.map(pkg => (
            <button
              key={pkg.id}
              type="button"
              onClick={() => handlePackageSelect(pkg)}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl border text-sm font-medium transition-all ${
                data.package === pkg.name
                  ? 'border-accent bg-accent/5 text-foreground'
                  : 'border-border bg-card hover:border-accent/40 text-foreground'
              }`}
            >
              <span>{pkg.name}</span>
              {pkg.base_price && (
                <span className={`text-xs font-semibold ${data.package === pkg.name ? 'text-accent' : 'text-muted-foreground'}`}>
                  ${Number(pkg.base_price).toLocaleString()}/mo
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {data.package && (
        <>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">Base Package Price (AUD/month)</label>
            <input
              type="number"
              value={data.base_price || ''}
              onChange={e => set('base_price', Number(e.target.value))}
              className="input-base"
              placeholder="0"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">Special Conditions</label>
            <textarea
              value={data.special_conditions || ''}
              onChange={e => set('special_conditions', e.target.value)}
              className="input-base resize-none h-16"
              placeholder="Any special pricing conditions or discounts."
            />
          </div>

          {/* Add-on toggles */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Add-Ons</label>
            <div className="space-y-3">
              {/* CarBee toggle */}
              <div className={`rounded-xl border transition-all ${data.carbee_enabled ? 'border-yellow-300 bg-yellow-50/60' : 'border-border bg-secondary/30'}`}>
                <div className="flex items-center justify-between px-4 py-3">
                  <span className="text-sm font-medium text-foreground">CarBee Filming</span>
                  <Toggle value={!!data.carbee_enabled} onChange={v => onChange({ ...data, carbee_enabled: v })} />
                </div>
                {data.carbee_enabled && (
                  <div className="px-4 pb-4 border-t border-yellow-200">
                    <CarBeeSetup data={data} onChange={onChange} />
                  </div>
                )}
              </div>

              {/* Inventory Photography toggle */}
              <div className={`rounded-xl border transition-all ${data.inventory_enabled ? 'border-teal-300 bg-teal-50/60' : 'border-border bg-secondary/30'}`}>
                <div className="flex items-center justify-between px-4 py-3">
                  <span className="text-sm font-medium text-foreground">Inventory Photography</span>
                  <Toggle value={!!data.inventory_enabled} onChange={v => onChange({ ...data, inventory_enabled: v })} />
                </div>
                {data.inventory_enabled && (
                  <div className="px-4 pb-4 border-t border-teal-200">
                    <InventorySetup data={data} onChange={onChange} />
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Total */}
          <div className="bg-primary text-primary-foreground rounded-xl px-5 py-4">
            <div className="text-xs opacity-70 mb-1">Total Monthly Value (Social Package)</div>
            <div className="text-2xl font-dm font-bold">${totalMonthly.toLocaleString('en-AU', { maximumFractionDigits: 0 })}</div>
            <div className="text-xs opacity-60 mt-0.5">CarBee and Inventory billed separately per session</div>
          </div>
        </>
      )}
    </div>
  );
}