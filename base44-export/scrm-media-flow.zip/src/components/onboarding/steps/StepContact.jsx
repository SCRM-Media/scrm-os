import StepField from '@/components/onboarding/StepField';

export default function StepContact({ data, onChange }) {
  const set = (k, v) => onChange({ ...data, [k]: v });
  return (
    <div className="bg-card rounded-xl border border-border p-6 space-y-4">
      <div className="grid sm:grid-cols-2 gap-4">
        <StepField label="Full Name *">
          <input value={data.full_name || ''} onChange={e => set('full_name', e.target.value)}
            className="input-base" placeholder="e.g. Sarah Johnson" />
        </StepField>
        <StepField label="Position / Title">
          <input value={data.position || ''} onChange={e => set('position', e.target.value)}
            className="input-base" placeholder="e.g. Marketing Manager" />
        </StepField>
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        <StepField label="Phone">
          <input type="tel" value={data.phone || ''} onChange={e => set('phone', e.target.value)}
            className="input-base" placeholder="+61 4xx xxx xxx" />
        </StepField>
        <StepField label="Email *">
          <input type="email" value={data.email || ''} onChange={e => set('email', e.target.value)}
            className="input-base" placeholder="contact@dealership.com.au" />
        </StepField>
      </div>
    </div>
  );
}