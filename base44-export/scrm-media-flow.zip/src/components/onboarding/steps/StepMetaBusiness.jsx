import WizardCheckbox from '@/components/onboarding/WizardCheckbox';

export default function StepMetaBusiness({ data, onChange }) {
  const set = (k, v) => onChange({ ...data, [k]: v });
  return (
    <div className="bg-card rounded-xl border border-border p-6 space-y-3">
      <div className="mb-4 p-3 bg-secondary/50 rounded-lg text-xs text-muted-foreground">
        Partner ID: <span className="font-mono font-semibold text-foreground">1284234112252386</span>
      </div>
      <WizardCheckbox checked={!!data.meta_logged_in} onChange={v => set('meta_logged_in', v)}
        label="Logged into client's Meta Business Suite" />
      <WizardCheckbox checked={!!data.meta_partner_access} onChange={v => set('meta_partner_access', v)}
        label="Partner access granted (Partner ID: 1284234112252386)" />
      <WizardCheckbox checked={!!data.meta_ig_connected} onChange={v => set('meta_ig_connected', v)}
        label="Instagram connected to Meta Business Suite" />
    </div>
  );
}