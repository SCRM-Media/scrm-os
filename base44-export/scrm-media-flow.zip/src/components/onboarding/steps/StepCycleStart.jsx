import StepField from '@/components/onboarding/StepField';

export default function StepCycleStart({ data, onChange }) {
  const set = (k, v) => onChange({ ...data, [k]: v });

  return (
    <div className="bg-card rounded-xl border border-border p-6 space-y-4">
      <StepField label="Cycle Start Date (must be a Monday)">
        <input
          type="date"
          value={data.cycle_start_date || ''}
          onChange={e => set('cycle_start_date', e.target.value)}
          className="input-base"
        />
      </StepField>
      {data.cycle_start_date && (
        <p className="text-xs text-muted-foreground">
          This client's 28-day content cycle will begin on <span className="font-semibold text-foreground">{data.cycle_start_date}</span>.
          Make sure this is a Monday.
        </p>
      )}
    </div>
  );
}