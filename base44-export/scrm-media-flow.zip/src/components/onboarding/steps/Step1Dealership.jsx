export default function Step1Dealership({ data, onChange }) {
  const set = (k, v) => onChange({ ...data, [k]: v });

  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-foreground mb-1.5">Dealership Name <span className="text-red-500">*</span></label>
        <input
          value={data.dealership_name || ''}
          onChange={e => set('dealership_name', e.target.value)}
          className="input-base"
          placeholder="e.g. Melbourne City Toyota"
        />
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">State <span className="text-red-500">*</span></label>
          <select value={data.state || ''} onChange={e => set('state', e.target.value)} className="input-base">
            <option value="">Select state...</option>
            {['VIC', 'NSW', 'QLD', 'WA', 'SA', 'TAS', 'NT', 'ACT'].map(s => <option key={s}>{s}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">Address <span className="text-red-500">*</span></label>
          <input
            value={data.address || ''}
            onChange={e => set('address', e.target.value)}
            className="input-base"
            placeholder="Street address"
          />
        </div>
      </div>
      <div>
        <label className="block text-sm font-medium text-foreground mb-1.5">Dealer Group</label>
        <input
          value={data.dealer_group || ''}
          onChange={e => set('dealer_group', e.target.value)}
          className="input-base"
          placeholder="Leave blank if independent"
        />
        <p className="text-xs text-muted-foreground mt-1">Leave blank if independent</p>
      </div>
    </div>
  );
}