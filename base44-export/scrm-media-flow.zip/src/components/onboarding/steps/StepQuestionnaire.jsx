import WizardCheckbox from '@/components/onboarding/WizardCheckbox';

export default function StepQuestionnaire({ data, onChange }) {
  const set = (k, v) => onChange({ ...data, [k]: v });
  return (
    <div className="bg-card rounded-xl border border-border p-6">
      <WizardCheckbox
        checked={!!data.questionnaire_done}
        onChange={v => set('questionnaire_done', v)}
        label="Onboarding questionnaire document completed with client"
        bold
      />
    </div>
  );
}