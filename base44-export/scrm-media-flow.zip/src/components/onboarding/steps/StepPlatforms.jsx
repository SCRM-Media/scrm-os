import WizardCheckbox from '@/components/onboarding/WizardCheckbox';

export default function StepPlatforms({ data, onChange }) {
  const set = (k, v) => onChange({ ...data, [k]: v });
  return (
    <div className="bg-card rounded-xl border border-border p-6 space-y-3">
      <WizardCheckbox checked={!!data.fb_connected} onChange={v => set('fb_connected', v)} label="Facebook connected" />
      <WizardCheckbox checked={!!data.ig_connected} onChange={v => set('ig_connected', v)} label="Instagram connected" />
      <WizardCheckbox checked={!!data.tiktok_connected} onChange={v => set('tiktok_connected', v)} label="TikTok connected" />
    </div>
  );
}