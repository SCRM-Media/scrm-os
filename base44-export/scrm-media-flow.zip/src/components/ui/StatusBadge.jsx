export const contentStatusColors = {
  'Planned': 'bg-gray-100 text-gray-600',
  'Shoot Booked': 'bg-blue-100 text-blue-700',
  'Filmed': 'bg-purple-100 text-purple-700',
  'Editing': 'bg-indigo-100 text-indigo-700',
  'QC': 'bg-orange-100 text-orange-700',
  'Caption': 'bg-pink-100 text-pink-700',
  'Scheduled': 'bg-teal-100 text-teal-700',
  'Published': 'bg-green-100 text-green-700',
};

export const healthColors = {
  'Green': 'bg-green-100 text-green-700',
  'Amber': 'bg-amber-100 text-amber-700',
  'Red': 'bg-red-100 text-red-700',
};

export const clientStatusColors = {
  'Active': 'bg-green-100 text-green-700',
  'Onboarding': 'bg-blue-100 text-blue-700',
  'Paused': 'bg-amber-100 text-amber-700',
  'Churned': 'bg-red-100 text-red-700',
};

export const packageColors = {
  'Minimum': 'bg-gray-100 text-gray-600',
  'Momentum': 'bg-blue-100 text-blue-700',
  'Dominate': 'bg-purple-100 text-purple-700',
  'Partner': 'bg-orange-100 text-orange-700',
};

export default function StatusBadge({ label, colorMap }) {
  const color = (colorMap || {})[label] || 'bg-gray-100 text-gray-600';
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${color}`}>
      {label}
    </span>
  );
}