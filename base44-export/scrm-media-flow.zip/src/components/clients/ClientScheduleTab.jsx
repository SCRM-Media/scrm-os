import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { ROLE_FOR_BLOCK } from '@/lib/calendarBlocks';
import { formatDuration } from '@/lib/cycleEngine';
import ScheduleDragDropEditor from '@/components/schedule/ScheduleDragDropEditor';

const WEEK_0_BLOCK_TYPES = new Set([
  'Content Planning Block',
  'Strategy Meeting',
  'Ad Scripting Block',
  'Meta Ad Setup Block',
]);

function mapFrequencyFromTemplate(tpl) {
  if (tpl.repeat_frequency === 'Weekly') return 'Weekly';
  if (tpl.repeat_frequency === 'Fortnightly') return 'Fortnightly';
  if (tpl.repeat_frequency === 'Monthly') {
    // week_of_month from packageDefaults; fall back to block-type-based logic for DB packages
    if (tpl.week_of_month === 'before' || WEEK_0_BLOCK_TYPES.has(tpl.block_type)) return 'Monthly Week 0';
    return 'Monthly Week 1';
  }
  return tpl.repeat_frequency;
}

export default function ClientScheduleTab({ client }) {
  const [rules, setRules] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [allRules, setAllRules] = useState([]);
  const [packageBlocks, setPackageBlocks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [placedRows, setPlacedRows] = useState([]);
  const [isValid, setIsValid] = useState(false);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    const [rls, emps, allRls, pkgs] = await Promise.all([
      base44.entities.BlockRule.filter({ client: client.id }),
      base44.entities.Employee.list(),
      base44.entities.BlockRule.list(),
      base44.entities.Package.list(),
    ]);
    setRules(rls);
    setEmployees(emps);
    setAllRules(allRls);

    const pkg = pkgs.find(p => p.name === client?.package);
    const blocks = [];
    const seen = new Set();

    if (pkg?.blocks) {
      pkg.blocks.forEach(tpl => {
        if (!seen.has(tpl.block_type)) {
          seen.add(tpl.block_type);
          blocks.push({
            block_type: tpl.block_type,
            duration_minutes: tpl.duration_minutes || 60,
            repeat_frequency: mapFrequencyFromTemplate(tpl),
            role: ROLE_FOR_BLOCK[tpl.block_type] || '',
          });
        }
      });
    }

    // Inject CarBee Filming Block if enabled + Recurring Sessions
    if (client?.carbee_enabled && client?.carbee_model === 'Recurring Sessions' && !seen.has('CarBee Filming Block')) {
      const dur = client.carbee_session_duration_minutes || 120;
      blocks.push({ block_type: 'CarBee Filming Block', duration_minutes: dur, repeat_frequency: 'Weekly', role: 'Content Creator' });
    }

    // Inject Inventory Photography Block if enabled
    if (client?.inventory_enabled && !seen.has('Inventory Photography Block')) {
      const dur = client.inventory_session_duration_minutes || 120;
      blocks.push({ block_type: 'Inventory Photography Block', duration_minutes: dur, repeat_frequency: 'Weekly', role: 'Content Creator' });
    }

    setPackageBlocks(blocks);
    setLoading(false);
  };

  useEffect(() => { load(); }, [client.id]);

  const today = new Date().toISOString().split('T')[0];
  const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
  const activeRules = rules.filter(r => !r.rule_end_date || r.rule_end_date >= today);

  const initialPlaced = activeRules.map(r => ({
    id: r.id,
    block_type: r.block_type,
    duration_minutes: r.duration_minutes || 60,
    repeat_frequency: r.repeat_frequency,
    role: r.role || ROLE_FOR_BLOCK[r.block_type] || '',
    day_of_week: r.day_of_week,
    start_time: r.start_time,
    employee: r.employee || '',
    existingRuleId: r.id,
  }));

  const handleSave = async () => {
    setSaving(true);
    await Promise.all(placedRows.map(async r => {
      const ruleData = {
        client: client.id,
        block_type: r.block_type,
        role: r.role,
        employee: r.employee || null,
        duration_minutes: r.duration_minutes,
        day_of_week: r.day_of_week,
        start_time: r.start_time,
        repeat_frequency: r.repeat_frequency,
        rule_start_date: client.cycle_start_date || today,
      };
      if (r.existingRuleId) {
        await base44.entities.BlockRule.update(r.existingRuleId, { rule_end_date: yesterday });
        await base44.entities.BlockRule.create(ruleData);
      } else {
        await base44.entities.BlockRule.create(ruleData);
      }
    }));
    setSaving(false);
    setEditing(false);
    load();
  };

  if (loading) return <div className="text-xs text-muted-foreground py-4">Loading schedule...</div>;

  if (!editing && activeRules.length === 0) {
    return (
      <div className="space-y-3 py-2">
        <p className="text-sm text-muted-foreground italic">No schedule rules set for this client yet.</p>
        <button
          onClick={() => setEditing(true)}
          className="px-4 py-2 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accent/90 transition-colors">
          Set Up Schedule
        </button>
      </div>
    );
  }

  if (!editing) {
    return (
      <div className="space-y-3">
        <div className="flex justify-end">
          <button
            onClick={() => setEditing(true)}
            className="px-3 py-1.5 border border-border rounded-lg text-xs font-medium text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
            Update Schedule
          </button>
        </div>
        <div className="border border-border rounded-xl overflow-hidden">
          <table className="w-full text-xs">
            <thead className="bg-secondary/40 border-b border-border">
              <tr>
                <th className="text-left px-3 py-2 font-medium text-muted-foreground">Block Type</th>
                <th className="text-left px-3 py-2 font-medium text-muted-foreground">Freq</th>
                <th className="text-left px-3 py-2 font-medium text-muted-foreground">Day</th>
                <th className="text-left px-3 py-2 font-medium text-muted-foreground">Time</th>
                <th className="text-left px-3 py-2 font-medium text-muted-foreground">Employee</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {activeRules.map(rule => {
                const emp = employees.find(e => e.id === rule.employee);
                return (
                  <tr key={rule.id}>
                    <td className="px-3 py-2 font-medium text-foreground">{rule.block_type.replace(' Block', '')}</td>
                    <td className="px-3 py-2 text-muted-foreground">{rule.repeat_frequency}</td>
                    <td className="px-3 py-2 text-muted-foreground">{rule.day_of_week}</td>
                    <td className="px-3 py-2 text-muted-foreground">{rule.start_time} · {formatDuration(rule.duration_minutes)}</td>
                    <td className="px-3 py-2 text-muted-foreground">{emp?.name || <span className="italic opacity-60">Unassigned</span>}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  // Editing mode — show drag-drop editor
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">Drag blocks onto the calendar. Click a block to assign an employee.</p>
        <button
          onClick={() => setEditing(false)}
          className="px-3 py-1.5 border border-border rounded-lg text-xs font-medium text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
          Cancel
        </button>
      </div>

      <ScheduleDragDropEditor
        packageBlocks={packageBlocks}
        employees={employees}
        allRules={allRules}
        clientId={client.id}
        initialPlaced={initialPlaced}
        onChange={(rows, valid) => { setPlacedRows(rows); setIsValid(valid); }}
        clientCycleStartDate={client.cycle_start_date}
      />

      <button
        onClick={handleSave}
        disabled={!isValid || saving}
        className="w-full py-2.5 bg-accent text-white rounded-xl font-dm font-semibold text-sm hover:bg-accent/90 disabled:opacity-40 transition-colors"
      >
        {saving ? 'Saving...' : 'Save Schedule'}
      </button>
    </div>
  );
}