import { useState, useEffect } from 'react';
import { X, AlertTriangle } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import BlockAssignmentsSection from '@/components/clients/BlockAssignmentsSection';

const ADD_ONS = ['CarBee Filming', 'Inventory Photography'];
const TABS = ['Details', 'Brand Pack', 'Block Assignments'];

// Returns true if the given date string is a Monday
function isMonday(dateStr) {
  if (!dateStr) return false;
  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  return dt.getDay() === 1;
}

// Snap a date string to the nearest Monday (backward)
function snapToMonday(dateStr) {
  if (!dateStr) return '';
  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  const dow = dt.getDay();
  const daysToMon = dow === 0 ? 6 : dow - 1;
  dt.setDate(dt.getDate() - daysToMon);
  return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')}`;
}

export default function ClientModal({ client, employees, onSave, onClose }) {
  const [tab, setTab] = useState('Details');
  const [packageOptions, setPackageOptions] = useState([]);
  const [employeesMap, setEmployeesMap] = useState({});
  const [form, setForm] = useState({
    name: client?.name || '',
    package: client?.package || '',
    status: client?.status || 'Active',
    monthly_value: client?.monthly_value || '',
    filming_cadence: client?.filming_cadence || 'Weekly',
    location: client?.location || '',
    account_health: client?.account_health || 'Green',
    content_notes: client?.content_notes || '',
    add_ons: client?.add_ons || [],
    monthly_google_reviews: client?.monthly_google_reviews || '',
    brand_pack: client?.brand_pack || '',
    cycle_start_date: client?.cycle_start_date || '',
  });
  const [cycleWarning, setCycleWarning] = useState('');

  useEffect(() => {
    base44.entities.Package.list().then(pkgs => setPackageOptions(pkgs.map(p => p.name)));
    if (employees) {
      setEmployeesMap(Object.fromEntries(employees.map(e => [e.id, e])));
    } else {
      base44.entities.Employee.list().then(es => setEmployeesMap(Object.fromEntries(es.map(e => [e.id, e]))));
    }
  }, []);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const toggleAddon = (addon) => {
    set('add_ons', form.add_ons.includes(addon)
      ? form.add_ons.filter(a => a !== addon)
      : [...form.add_ons, addon]
    );
  };

  const handleCycleDateChange = (val) => {
    if (!val) { set('cycle_start_date', ''); setCycleWarning(''); return; }
    if (isMonday(val)) {
      set('cycle_start_date', val);
      setCycleWarning('');
    } else {
      const snapped = snapToMonday(val);
      set('cycle_start_date', snapped);
      setCycleWarning(`Date snapped to Monday: ${snapped}`);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave({
      ...form,
      monthly_value: form.monthly_value ? Number(form.monthly_value) : undefined,
      monthly_google_reviews: form.monthly_google_reviews ? Number(form.monthly_google_reviews) : undefined,
      carbee_enabled: form.add_ons.includes('CarBee Filming'),
      inventory_enabled: form.add_ons.includes('Inventory Photography'),
    });
  };

  const showBlockAssignments = client && tab === 'Block Assignments';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
      <div className="bg-card rounded-2xl border border-border shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border sticky top-0 bg-card z-10">
          <h2 className="font-dm font-bold text-foreground">{client ? 'Edit Client' : 'Add Client'}</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X size={18} /></button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-border px-6 overflow-x-auto">
          {(client ? TABS : ['Details', 'Brand Pack']).map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`py-2.5 px-1 mr-5 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${tab === t ? 'border-accent text-accent' : 'border-transparent text-muted-foreground hover:text-foreground'}`}>
              {t}
            </button>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="px-6 py-5 space-y-4">
          {showBlockAssignments ? (
            <BlockAssignmentsSection client={client} employeesMap={employeesMap} />
          ) : tab === 'Details' ? (
            <>
              <Field label="Dealership Name *">
                <input required value={form.name} onChange={e => set('name', e.target.value)}
                  className="input-base" placeholder="e.g. Melbourne City Toyota" />
              </Field>

              <div className="grid grid-cols-2 gap-4">
                <Field label="Package">
                  <select value={form.package} onChange={e => set('package', e.target.value)} className="input-base">
                    <option value="">None</option>
                    {packageOptions.map(p => <option key={p}>{p}</option>)}
                  </select>
                </Field>
                <Field label="Status">
                  <select value={form.status} onChange={e => set('status', e.target.value)} className="input-base">
                    {['Active', 'Onboarding', 'Paused', 'Churned'].map(s => <option key={s}>{s}</option>)}
                  </select>
                </Field>
              </div>

              <Field label="Monthly cycle start date — the date this client's content month begins.">
                <input
                  type="date"
                  value={form.cycle_start_date}
                  onChange={e => handleCycleDateChange(e.target.value)}
                  className="input-base"
                />
                {cycleWarning && (
                  <p className="text-xs text-amber-600 mt-1">{cycleWarning}</p>
                )}
                {form.cycle_start_date && !isMonday(form.cycle_start_date) && (
                  <p className="text-xs text-red-600 mt-1">Must be a Monday.</p>
                )}
                {!form.cycle_start_date && (
                  <p className="text-xs text-muted-foreground mt-1">Select a Monday. Blocks cannot be generated without this.</p>
                )}
              </Field>

              <div className="grid grid-cols-2 gap-4">
                <Field label="Monthly Value (AUD)">
                  <input type="number" value={form.monthly_value} onChange={e => set('monthly_value', e.target.value)}
                    className="input-base" placeholder="0" />
                </Field>
                <Field label="Filming Cadence">
                  <select value={form.filming_cadence} onChange={e => set('filming_cadence', e.target.value)} className="input-base">
                    {['Weekly', 'Fortnightly'].map(f => <option key={f}>{f}</option>)}
                  </select>
                </Field>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <Field label="Location">
                  <input value={form.location} onChange={e => set('location', e.target.value)}
                    className="input-base" placeholder="e.g. Melbourne" />
                </Field>
                <Field label="Account Health">
                  <select value={form.account_health} onChange={e => set('account_health', e.target.value)} className="input-base">
                    {['Green', 'Amber', 'Red'].map(h => <option key={h}>{h}</option>)}
                  </select>
                </Field>
              </div>

              <Field label="Monthly Google Reviews ⭐">
                <input type="number" value={form.monthly_google_reviews} onChange={e => set('monthly_google_reviews', e.target.value)}
                  className="input-base" placeholder="Number of 5-star reviews this month" min="0" />
              </Field>

              <Field label="Add-ons">
                <div className="flex flex-wrap gap-2 mt-1">
                  {ADD_ONS.map(addon => (
                    <button key={addon} type="button" onClick={() => toggleAddon(addon)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                        form.add_ons.includes(addon)
                          ? 'bg-accent text-white border-accent'
                          : 'bg-secondary text-secondary-foreground border-border hover:border-accent/50'
                      }`}>
                      {addon}
                    </button>
                  ))}
                </div>
              </Field>

              <Field label="Content Notes">
                <textarea value={form.content_notes} onChange={e => set('content_notes', e.target.value)}
                  className="input-base resize-none h-20" placeholder="Preferred content styles, restrictions, etc." />
              </Field>
            </>
          ) : tab === 'Brand Pack' ? (
            <div>
              <p className="text-xs text-muted-foreground mb-3">Tone of voice, filming preferences, what to avoid, key contacts, and parking instructions.</p>
              <textarea value={form.brand_pack} onChange={e => set('brand_pack', e.target.value)}
                className="input-base resize-none h-64" placeholder="e.g. Keep tone upbeat and aspirational..." />
            </div>
          ) : null}

          {!showBlockAssignments && (
            <div className="flex gap-3 pt-2">
              <button type="button" onClick={onClose}
                className="flex-1 px-4 py-2 rounded-lg border border-border text-sm font-medium text-foreground hover:bg-secondary transition-colors">
                Cancel
              </button>
              <button type="submit"
                className="flex-1 px-4 py-2 rounded-lg bg-accent text-white text-sm font-medium hover:bg-accent/90 transition-colors">
                {client ? 'Save Changes' : 'Add Client'}
              </button>
            </div>
          )}
        </form>
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label className="block text-xs font-medium text-muted-foreground mb-1.5">{label}</label>
      {children}
    </div>
  );
}