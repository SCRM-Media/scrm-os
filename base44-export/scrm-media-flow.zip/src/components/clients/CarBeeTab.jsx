import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { ExternalLink, Plus, CheckCircle2, ChevronDown, ChevronUp } from 'lucide-react';

function Field({ label, hint, children }) {
  return (
    <div>
      <label className="block text-xs font-medium text-muted-foreground mb-1.5">
        {label}{hint && <span className="ml-1 opacity-60 font-normal">{hint}</span>}
      </label>
      {children}
    </div>
  );
}

function calcDuration(cars, rate = 5) {
  if (!cars || cars <= 0) return 0;
  const raw = (cars / rate) * 60;
  return Math.ceil(raw / 15) * 15;
}

function formatDurLabel(mins) {
  if (!mins) return '—';
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${h} hour${h !== 1 ? 's' : ''} ${m} minute${m !== 1 ? 's' : ''}`;
}

function LogSessionModal({ client, employees, onClose, onSaved }) {
  const videographers = employees.filter(e => e.role === 'Content Creator');
  const [form, setForm] = useState({
    session_date: new Date().toISOString().split('T')[0],
    filmer_employee: '',
    cars_filmed: '',
    stock_numbers: '',
    google_sheet_updated: false,
    upload_destination_link: '',
    session_notes: '',
  });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!form.session_date || !form.cars_filmed) return;
    setSaving(true);
    await base44.entities.InventorySession.create({
      client: client.id,
      session_date: form.session_date,
      session_type: 'CarBee',
      filmer_employee: form.filmer_employee || null,
      cars_filmed: Number(form.cars_filmed),
      stock_numbers: form.stock_numbers,
      google_sheet_updated: form.google_sheet_updated,
      upload_destination_link: form.upload_destination_link,
      session_notes: form.session_notes,
      edit_task_created: false,
    });
    setSaving(false);
    onSaved();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-card border border-border rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border sticky top-0 bg-card">
          <h3 className="font-dm font-bold text-foreground">Log CarBee Session</h3>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground text-xl leading-none">×</button>
        </div>
        <div className="px-6 py-5 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Session Date *">
              <input type="date" value={form.session_date} onChange={e => setForm(f => ({ ...f, session_date: e.target.value }))} className="input-base" required />
            </Field>
            <Field label="Cars Filmed *">
              <input type="number" value={form.cars_filmed} onChange={e => setForm(f => ({ ...f, cars_filmed: e.target.value }))} className="input-base" placeholder="0" min="0" />
            </Field>
          </div>
          <Field label="Filmer">
            <select value={form.filmer_employee} onChange={e => setForm(f => ({ ...f, filmer_employee: e.target.value }))} className="input-base">
              <option value="">— None —</option>
              {videographers.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
            </select>
          </Field>
          <Field label="Stock / Rego Numbers">
            <textarea value={form.stock_numbers} onChange={e => setForm(f => ({ ...f, stock_numbers: e.target.value }))}
              className="input-base resize-none h-20" placeholder="Enter stock numbers or rego numbers, comma separated" />
          </Field>
          <Field label="Upload Destination Link">
            <input type="url" value={form.upload_destination_link} onChange={e => setForm(f => ({ ...f, upload_destination_link: e.target.value }))} className="input-base" placeholder="https://..." />
          </Field>
          <Field label="Notes">
            <textarea value={form.session_notes} onChange={e => setForm(f => ({ ...f, session_notes: e.target.value }))} className="input-base resize-none h-16" />
          </Field>
          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" checked={form.google_sheet_updated} onChange={e => setForm(f => ({ ...f, google_sheet_updated: e.target.checked }))} className="w-4 h-4 rounded" />
            <span className="text-sm text-foreground">Google Sheet updated</span>
          </label>
          <div className="flex gap-3 pt-1">
            <button onClick={onClose} className="flex-1 px-4 py-2.5 border border-border rounded-lg text-sm font-medium text-muted-foreground hover:bg-secondary transition-colors">Cancel</button>
            <button onClick={handleSave} disabled={saving || !form.session_date || !form.cars_filmed}
              className="flex-1 px-4 py-2.5 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accent/90 disabled:opacity-50 transition-colors">
              {saving ? 'Saving...' : 'Log Session'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

function SessionScheduleRow({ index, value, onChange, onRemove, canRemove }) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-xs text-muted-foreground w-16 shrink-0">Session {index + 1}</span>
      <select value={value.day_of_week} onChange={e => onChange({ ...value, day_of_week: e.target.value })} className="input-base flex-1 text-sm">
        {DAYS.map(d => <option key={d}>{d}</option>)}
      </select>
      <input type="time" value={value.start_time} onChange={e => onChange({ ...value, start_time: e.target.value })} className="input-base w-28 text-sm" />
      {canRemove && (
        <button type="button" onClick={onRemove} className="p-1.5 text-muted-foreground hover:text-red-600 transition-colors">×</button>
      )}
    </div>
  );
}

export default function CarBeeTab({ client, employees, onClientUpdate }) {
  const RATE = 5; // cars per hour

  const defaultSchedule = client.carbee_session_schedule?.length
    ? client.carbee_session_schedule
    : [{ day_of_week: 'Monday', start_time: '09:00' }];

  const [form, setForm] = useState({
    carbee_model: client.carbee_model || 'Recurring Sessions',
    carbee_cars_per_session: client.carbee_cars_per_session || '',
    carbee_total_stock: client.carbee_total_stock || '',
    carbee_stock_percentage: client.carbee_stock_percentage || '',
    carbee_monthly_turnover: client.carbee_monthly_turnover || '',
    carbee_google_sheet_link: client.carbee_google_sheet_link || '',
    carbee_notes: client.carbee_notes || '',
  });
  const [schedule, setSchedule] = useState(defaultSchedule);

  const addSession = () => setSchedule(s => [...s, { day_of_week: 'Monday', start_time: '09:00' }]);
  const removeSession = (i) => setSchedule(s => s.filter((_, idx) => idx !== i));
  const updateSession = (i, val) => setSchedule(s => s.map((row, idx) => idx === i ? val : row));


  const [sessions, setSessions] = useState([]);
  const [showLog, setShowLog] = useState(false);
  const [saving, setSaving] = useState(false);
  const [expandedStock, setExpandedStock] = useState({});

  const loadSessions = async () => {
    const all = await base44.entities.InventorySession.filter({ client: client.id });
    setSessions(all.filter(s => s.session_type === 'CarBee').sort((a, b) => b.session_date.localeCompare(a.session_date)));
  };

  useEffect(() => { loadSessions(); }, [client.id]);

  const save = async () => {
    setSaving(true);
    const cars = Number(form.carbee_cars_per_session || 0);
    const dur = calcDuration(cars, RATE);
    await base44.entities.Client.update(client.id, {
      ...form,
      carbee_cars_per_session: form.carbee_cars_per_session !== '' ? Number(form.carbee_cars_per_session) : null,
      carbee_total_stock: form.carbee_total_stock !== '' ? Number(form.carbee_total_stock) : null,
      carbee_stock_percentage: form.carbee_stock_percentage !== '' ? Number(form.carbee_stock_percentage) : null,
      carbee_monthly_turnover: form.carbee_monthly_turnover !== '' ? Number(form.carbee_monthly_turnover) : null,
      carbee_session_duration_minutes: dur || null,
      carbee_sessions_per_week: schedule.length,
      carbee_session_schedule: schedule,
    });

    // Sync BlockRules for CarBee (Recurring Sessions model)
    if (form.carbee_model === 'Recurring Sessions' && dur > 0) {
      const today = new Date().toISOString().split('T')[0];
      const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
      const existingRules = await base44.entities.BlockRule.filter({ client: client.id, block_type: 'CarBee Filming Block' });
      const activeRules = existingRules.filter(r => !r.rule_end_date || r.rule_end_date >= today);

      // End all existing active rules
      await Promise.all(activeRules.map(r => base44.entities.BlockRule.update(r.id, { rule_end_date: yesterday })));

      // Create one rule per session slot
      await Promise.all(schedule.map(slot =>
        base44.entities.BlockRule.create({
          client: client.id,
          block_type: 'CarBee Filming Block',
          role: 'Content Creator',
          employee: null,
          duration_minutes: dur,
          day_of_week: slot.day_of_week,
          start_time: slot.start_time,
          repeat_frequency: 'Weekly',
          rule_start_date: client.cycle_start_date || today,
        })
      ));
    }

    setSaving(false);
    onClientUpdate && onClientUpdate();
  };

  // Derived values
  const carsPerSession = Number(form.carbee_cars_per_session || 0);
  const sessionDurMins = calcDuration(carsPerSession, RATE);
  const totalStock = Number(form.carbee_total_stock || 0);
  const pct = Number(form.carbee_stock_percentage || 0);
  const targetCars = totalStock && pct ? Math.ceil(totalStock * pct / 100) : 0;
  const turnover = Number(form.carbee_monthly_turnover || 0);
  const minSessions = carsPerSession > 0 && turnover > 0 ? Math.ceil(turnover / carsPerSession) : 0;

  // Live tracker
  const carsFilmed = sessions.reduce((sum, s) => sum + (s.cars_filmed || 0), 0);
  const carsRemaining = Math.max(0, targetCars - carsFilmed);
  const remainingColor = carsRemaining === 0 ? 'text-green-600' : carsRemaining <= 10 ? 'text-amber-600' : 'text-red-600';
  const remainingBg = carsRemaining === 0 ? 'bg-green-50 border-green-200' : carsRemaining <= 10 ? 'bg-amber-50 border-amber-200' : 'bg-red-50 border-red-200';

  // Revenue estimate
  const estimatedSessions = form.carbee_model === 'Stock Target' ? minSessions : (client.filming_cadence === 'Fortnightly' ? 2 : 4);
  const estimatedRevenue = carsPerSession && estimatedSessions ? carsPerSession * 25 * estimatedSessions : 0;

  const videographers = employees.filter(e => e.role === 'Content Creator');

  return (
    <div className="space-y-6">
      {/* Section 1 — Configuration */}
      <div className="bg-card border border-border rounded-xl p-4 space-y-4">
        <div className="font-dm font-semibold text-foreground text-sm">Configuration</div>

        <Field label="Model">
          <select value={form.carbee_model}
            onChange={e => setForm(f => ({ ...f, carbee_model: e.target.value }))}
            className="input-base">
            <option value="Recurring Sessions">Recurring Sessions</option>
            <option value="Stock Target">Stock Target</option>
          </select>
        </Field>

        <Field label="Cars Per Session">
          <input type="number" value={form.carbee_cars_per_session}
            onChange={e => setForm(f => ({ ...f, carbee_cars_per_session: e.target.value }))}
            className="input-base w-36" placeholder="0" min="1" />
          <p className="text-xs text-muted-foreground mt-1.5">CarBee rate is $25 per car ex GST at 5 cars per hour. Session duration calculates automatically.</p>
        </Field>

        <div>
          <label className="block text-xs font-medium text-muted-foreground mb-1.5">Session Duration (calculated)</label>
          <div className="px-3 py-2 bg-secondary/40 rounded-lg text-sm text-foreground border border-border">
            {sessionDurMins > 0 ? formatDurLabel(sessionDurMins) : '—'}
          </div>
        </div>

        {form.carbee_model === 'Recurring Sessions' && (
          <div className="space-y-2 border-t border-border pt-4">
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-medium text-muted-foreground">Session Schedule</label>
              {schedule.length < 4 && (
                <button type="button" onClick={addSession}
                  className="flex items-center gap-1 text-xs text-accent hover:text-accent/80 font-medium transition-colors">
                  <Plus size={12} /> Add session
                </button>
              )}
            </div>
            {schedule.map((slot, i) => (
              <SessionScheduleRow key={i} index={i} value={slot}
                onChange={val => updateSession(i, val)}
                onRemove={() => removeSession(i)}
                canRemove={schedule.length > 1} />
            ))}
            <p className="text-xs text-muted-foreground">These create recurring unassigned blocks in the employee calendar.</p>
          </div>
        )}

        {form.carbee_model === 'Stock Target' && (
          <div className="space-y-4 border-t border-border pt-4">
            <div className="grid sm:grid-cols-3 gap-3">
              <Field label="Total Stock">
                <input type="number" value={form.carbee_total_stock}
                  onChange={e => setForm(f => ({ ...f, carbee_total_stock: e.target.value }))}
                  className="input-base" placeholder="0" />
              </Field>
              <Field label="Target Percentage (%)">
                <input type="number" value={form.carbee_stock_percentage}
                  onChange={e => setForm(f => ({ ...f, carbee_stock_percentage: e.target.value }))}
                  className="input-base" placeholder="0" min="0" max="100" />
              </Field>
              <Field label="Monthly Turnover (cars sold)">
                <input type="number" value={form.carbee_monthly_turnover}
                  onChange={e => setForm(f => ({ ...f, carbee_monthly_turnover: e.target.value }))}
                  className="input-base" placeholder="0" />
              </Field>
            </div>

            {/* Prominent derived values */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-yellow-50 border border-yellow-200 rounded-xl px-4 py-3 text-center">
                <div className="text-xs text-yellow-700 font-medium mb-1">Target Cars to Film</div>
                <div className="text-3xl font-dm font-bold text-yellow-800">{targetCars || '—'}</div>
                {totalStock && pct ? <div className="text-xs text-yellow-600 mt-1">{totalStock} × {pct}%</div> : null}
              </div>
              <div className="bg-yellow-50 border border-yellow-200 rounded-xl px-4 py-3 text-center">
                <div className="text-xs text-yellow-700 font-medium mb-1">Min Sessions / Month</div>
                <div className="text-3xl font-dm font-bold text-yellow-800">{minSessions || '—'}</div>
                {minSessions > 0 ? <div className="text-xs text-yellow-600 mt-1">to maintain stock target</div> : null}
              </div>
            </div>

            {/* Live tracker */}
            {targetCars > 0 && (
              <div className={`border rounded-xl px-4 py-3 grid grid-cols-3 gap-3 text-center ${remainingBg}`}>
                <div>
                  <div className="text-xs text-muted-foreground mb-1">Cars Filmed</div>
                  <div className="text-xl font-dm font-bold text-foreground">{carsFilmed}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground mb-1">Target</div>
                  <div className="text-xl font-dm font-bold text-foreground">{targetCars}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground mb-1">Remaining</div>
                  <div className={`text-xl font-dm font-bold ${remainingColor}`}>{carsRemaining}</div>
                </div>
              </div>
            )}
          </div>
        )}

        <Field label="Google Sheet Link">
          <div className="flex gap-2">
            <input type="url" value={form.carbee_google_sheet_link}
              onChange={e => setForm(f => ({ ...f, carbee_google_sheet_link: e.target.value }))}
              className="input-base flex-1" placeholder="https://docs.google.com/spreadsheets/..." />
            {form.carbee_google_sheet_link && (
              <a href={form.carbee_google_sheet_link} target="_blank" rel="noreferrer"
                className="px-3 flex items-center rounded-lg border border-border text-accent hover:bg-secondary transition-colors">
                <ExternalLink size={15} />
              </a>
            )}
          </div>
        </Field>

        <Field label="Notes">
          <textarea value={form.carbee_notes}
            onChange={e => setForm(f => ({ ...f, carbee_notes: e.target.value }))}
            className="input-base resize-none h-20" placeholder="Notes about CarBee setup..." />
        </Field>

        <div className="flex justify-end pt-1">
          <button onClick={save} disabled={saving}
            className="px-4 py-2 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accent/90 disabled:opacity-50 transition-colors">
            {saving ? 'Saving...' : 'Save'}
          </button>
        </div>
      </div>

      {/* Section 2 — Session Log */}
      <div className="bg-card border border-border rounded-xl p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="font-dm font-semibold text-foreground text-sm">Session Log</div>
          <button onClick={() => setShowLog(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-accent text-white rounded-lg text-xs font-medium hover:bg-accent/90 transition-colors">
            <Plus size={13} /> Log Session
          </button>
        </div>

        {sessions.length === 0 ? (
          <p className="text-xs text-muted-foreground italic">No CarBee sessions logged yet.</p>
        ) : (
          <div className="border border-border rounded-xl overflow-hidden">
            <table className="w-full text-xs">
              <thead className="bg-secondary/40 border-b border-border">
                <tr>
                  <th className="text-left px-3 py-2 font-medium text-muted-foreground">Date</th>
                  <th className="text-left px-3 py-2 font-medium text-muted-foreground">Filmer</th>
                  <th className="text-left px-3 py-2 font-medium text-muted-foreground">Cars</th>
                  <th className="text-left px-3 py-2 font-medium text-muted-foreground hidden sm:table-cell">Stock #s</th>
                  <th className="text-center px-3 py-2 font-medium text-muted-foreground">Sheet</th>
                  <th className="text-left px-3 py-2 font-medium text-muted-foreground">Upload</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {sessions.map(s => {
                  const filmer = employees.find(e => e.id === s.filmer_employee);
                  const stockFull = s.stock_numbers || '';
                  const stockShort = stockFull.length > 50 ? stockFull.slice(0, 50) + '…' : stockFull;
                  const isExpanded = expandedStock[s.id];
                  return (
                    <tr key={s.id} className="hover:bg-secondary/20">
                      <td className="px-3 py-2 font-medium text-foreground whitespace-nowrap">{s.session_date}</td>
                      <td className="px-3 py-2 text-muted-foreground">{filmer?.name || '—'}</td>
                      <td className="px-3 py-2 text-foreground font-medium">{s.cars_filmed}</td>
                      <td className="px-3 py-2 text-muted-foreground hidden sm:table-cell max-w-[140px]">
                        {stockFull ? (
                          <span>
                            {isExpanded ? stockFull : stockShort}
                            {stockFull.length > 50 && (
                              <button onClick={() => setExpandedStock(p => ({ ...p, [s.id]: !p[s.id] }))}
                                className="ml-1 text-accent hover:underline text-[10px]">
                                {isExpanded ? 'less' : 'more'}
                              </button>
                            )}
                          </span>
                        ) : '—'}
                      </td>
                      <td className="px-3 py-2 text-center">
                        {s.google_sheet_updated
                          ? <CheckCircle2 size={13} className="text-green-500 mx-auto" />
                          : <span className="text-muted-foreground">—</span>}
                      </td>
                      <td className="px-3 py-2">
                        {s.upload_destination_link
                          ? <a href={s.upload_destination_link} target="_blank" rel="noreferrer" className="text-accent hover:underline flex items-center gap-1">Link <ExternalLink size={11} /></a>
                          : <span className="text-muted-foreground">—</span>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Section 3 — Revenue Estimate */}
      <div className="bg-card border border-border rounded-xl p-4 space-y-3">
        <div className="font-dm font-semibold text-foreground text-sm">Revenue Estimate <span className="text-xs font-normal text-muted-foreground ml-1">— estimate only</span></div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-secondary/40 rounded-lg px-3 py-2.5 text-center">
            <div className="text-xs text-muted-foreground mb-1">Rate per car</div>
            <div className="text-lg font-dm font-bold text-foreground">$25 <span className="text-xs font-normal text-muted-foreground">ex GST</span></div>
          </div>
          <div className="bg-secondary/40 rounded-lg px-3 py-2.5 text-center">
            <div className="text-xs text-muted-foreground mb-1">Cars per session</div>
            <div className="text-lg font-dm font-bold text-foreground">{carsPerSession || '—'}</div>
          </div>
          <div className="bg-secondary/40 rounded-lg px-3 py-2.5 text-center">
            <div className="text-xs text-muted-foreground mb-1">
              {form.carbee_model === 'Stock Target' ? 'Min sessions/month' : 'Est. sessions/month'}
            </div>
            <div className="text-lg font-dm font-bold text-foreground">{estimatedSessions || '—'}</div>
            {form.carbee_model !== 'Stock Target' && (
              <div className="text-[10px] text-muted-foreground mt-0.5">{client.filming_cadence || 'Weekly'}</div>
            )}
          </div>
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg px-3 py-2.5 text-center">
            <div className="text-xs text-yellow-700 mb-1">Est. monthly revenue</div>
            <div className="text-lg font-dm font-bold text-yellow-800">{estimatedRevenue ? `$${estimatedRevenue.toLocaleString()}` : '—'}</div>
          </div>
        </div>
      </div>

      {showLog && (
        <LogSessionModal
          client={client}
          employees={employees}
          onClose={() => setShowLog(false)}
          onSaved={() => { setShowLog(false); loadSessions(); }}
        />
      )}
    </div>
  );
}