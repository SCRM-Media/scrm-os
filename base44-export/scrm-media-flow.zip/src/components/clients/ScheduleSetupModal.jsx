import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { ROLE_FOR_BLOCK } from '@/lib/calendarBlocks';
import { formatDuration, timesOverlap, minutesToTime, timeToMinutes } from '@/lib/cycleEngine';
import { AlertTriangle, CheckCircle2, X } from 'lucide-react';

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

function mapFrequency(freq) {
  if (freq === 'Weekly') return 'Weekly';
  if (freq === 'Fortnightly') return 'Fortnightly';
  if (freq === 'Monthly') return 'Monthly Week 1';
  return 'Monthly Week 1';
}

function getConflict(row, allRows, employees, allRules, clientId) {
  if (!row.employee || !row.day_of_week || !row.start_time) return null;
  const today = new Date().toISOString().split('T')[0];
  // Check within modal rows
  for (const other of allRows) {
    if (other.block_type === row.block_type) continue;
    if (other.employee !== row.employee) continue;
    if (other.day_of_week !== row.day_of_week) continue;
    if (!other.start_time) continue;
    if (timesOverlap(row.start_time, row.duration_minutes, other.start_time, other.duration_minutes)) {
      const otherEnd = minutesToTime(timeToMinutes(other.start_time) + (other.duration_minutes || 60));
      return `Conflict with ${other.block_type.replace(' Block', '')} at ${other.start_time}–${otherEnd} on ${other.day_of_week}`;
    }
  }
  // Check against other clients' rules
  const otherClientRules = (allRules || []).filter(r =>
    r.client !== clientId &&
    r.employee === row.employee &&
    r.day_of_week === row.day_of_week &&
    (!r.rule_end_date || r.rule_end_date >= today)
  );
  for (const other of otherClientRules) {
    if (!other.start_time) continue;
    if (timesOverlap(row.start_time, row.duration_minutes, other.start_time, other.duration_minutes)) {
      const otherEnd = minutesToTime(timeToMinutes(other.start_time) + (other.duration_minutes || 60));
      return `Conflict (another client): ${other.block_type.replace(' Block', '')} at ${other.start_time}–${otherEnd} on ${other.day_of_week}`;
    }
  }
  return null;
}

function EmployeeSchedulePopover({ employeeId, allRules, clientId, onClose }) {
  const today = new Date().toISOString().split('T')[0];
  const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  const empRules = allRules.filter(r =>
    r.employee === employeeId &&
    (!r.rule_end_date || r.rule_end_date >= today)
  );
  const byDay = {};
  DAYS.forEach(d => { byDay[d] = empRules.filter(r => r.day_of_week === d); });
  const activeDays = DAYS.filter(d => byDay[d].length > 0);
  return (
    <div className="absolute z-50 right-0 top-8 w-72 bg-card border border-border rounded-xl shadow-xl p-4 space-y-2" onClick={e => e.stopPropagation()}>
      <div className="flex items-center justify-between mb-1">
        <span className="text-xs font-semibold text-foreground">Weekly Schedule</span>
        <button onClick={onClose} className="text-muted-foreground hover:text-foreground text-xs">✕</button>
      </div>
      {activeDays.length === 0 ? (
        <p className="text-xs text-muted-foreground italic">No existing blocks assigned.</p>
      ) : activeDays.map(day => (
        <div key={day}>
          <div className="text-xs font-medium text-muted-foreground mb-0.5">{day}</div>
          {byDay[day].sort((a, b) => a.start_time.localeCompare(b.start_time)).map(r => (
            <div key={r.id} className={`text-xs px-2 py-1 rounded mb-0.5 ${r.client === clientId ? 'bg-accent/10 text-accent' : 'bg-secondary text-foreground'}`}>
              {r.start_time} · {r.block_type.replace(' Block', '')} · {r.repeat_frequency}
              {r.client !== clientId && <span className="ml-1 opacity-60">(other client)</span>}
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

export default function ScheduleSetupModal({ client, existingRules, onClose, onSaved }) {
  const [employees, setEmployees] = useState([]);
  const [allRules, setAllRules] = useState([]);
  const [rows, setRows] = useState([]);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [expandedEmployee, setExpandedEmployee] = useState(null);
  const isUpdate = existingRules.length > 0;

  useEffect(() => {
    const load = async () => {
      const [emps, pkgs, allRls] = await Promise.all([
        base44.entities.Employee.list(),
        base44.entities.Package.list(),
        base44.entities.BlockRule.list(),
      ]);
      setAllRules(allRls);
      setEmployees(emps);

      const pkg = pkgs.find(p => p.name === client?.package);
      if (pkg?.blocks) {
        const seen = new Set();
        const r = [];
        pkg.blocks.forEach(tpl => {
          if (!seen.has(tpl.block_type)) {
            seen.add(tpl.block_type);
            // Pre-fill from existing rule if available
            const existing = existingRules.find(rule => rule.block_type === tpl.block_type && (!rule.rule_end_date || rule.rule_end_date >= new Date().toISOString().split('T')[0]));
            r.push({
              block_type: tpl.block_type,
              duration_minutes: existing?.duration_minutes || tpl.duration_minutes || 60,
              repeat_frequency: existing?.repeat_frequency || mapFrequency(tpl.repeat_frequency),
              role: ROLE_FOR_BLOCK[tpl.block_type] || '',
              employee: existing?.employee || '',
              day_of_week: existing?.day_of_week || 'Monday',
              start_time: existing?.start_time || '09:00',
              existingRuleId: existing?.id || null,
            });
          }
        });
        setRows(r);
      }
      setLoading(false);
    };
    load();
  }, [client]);

  const updateRow = (idx, field, value) => {
    setRows(prev => prev.map((r, i) => i === idx ? { ...r, [field]: value } : r));
  };

  const allValid = rows.every(r => r.employee && r.day_of_week && r.start_time && !getConflict(r, rows, employees, allRules, client.id));

  const handleSave = async () => {
    setSaving(true);
    const today = new Date().toISOString().split('T')[0];
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
    const ruleStartDate = client.cycle_start_date || today;

    await Promise.all(rows.map(async r => {
      const ruleData = {
        client: client.id,
        block_type: r.block_type,
        role: r.role,
        employee: r.employee || null,
        duration_minutes: r.duration_minutes,
        day_of_week: r.day_of_week,
        start_time: r.start_time,
        repeat_frequency: r.repeat_frequency,
        rule_start_date: ruleStartDate,
      };
      if (r.existingRuleId) {
        // End old rule and create new one from today
        await base44.entities.BlockRule.update(r.existingRuleId, { rule_end_date: yesterday });
        await base44.entities.BlockRule.create({ ...ruleData, rule_start_date: today });
      } else {
        await base44.entities.BlockRule.create(ruleData);
      }
    }));

    setSaving(false);
    onSaved();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
      <div className="bg-card rounded-2xl border border-border shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border sticky top-0 bg-card z-10">
          <div>
            <h2 className="font-dm font-bold text-foreground">{isUpdate ? 'Update Schedule' : 'Set Up Schedule'}</h2>
            <p className="text-xs text-muted-foreground mt-0.5">{client.name} · {client.package}</p>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X size={18} /></button>
        </div>

        <div className="px-6 py-5 space-y-4">
          {loading ? (
            <div className="text-xs text-muted-foreground py-4">Loading package blocks...</div>
          ) : rows.length === 0 ? (
            <div className="text-sm text-muted-foreground italic">No package assigned to this client.</div>
          ) : (
            <>
              {isUpdate && (
                <div className="text-sm text-muted-foreground bg-amber-50 border border-amber-200 rounded-xl px-4 py-3">
                  Saving will end current rules and create new ones from today onwards.
                </div>
              )}
              <div className="border border-border rounded-xl overflow-x-auto">
                <table className="w-full text-xs">
                  <thead className="bg-secondary/40 border-b border-border">
                    <tr>
                      <th className="text-left px-3 py-2 font-medium text-muted-foreground">Block Type</th>
                      <th className="text-left px-3 py-2 font-medium text-muted-foreground">Freq</th>
                      <th className="text-left px-3 py-2 font-medium text-muted-foreground">Day</th>
                      <th className="text-left px-3 py-2 font-medium text-muted-foreground">Time</th>
                      <th className="text-left px-3 py-2 font-medium text-muted-foreground">Employee</th>
                      <th className="px-3 py-2"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {rows.map((row, idx) => {
                      const conflict = getConflict(row, rows, employees, allRules, client.id);
                      const isComplete = row.employee && row.day_of_week && row.start_time && !conflict;
                      const eligible = employees.filter(e => !row.role || e.role === row.role);
                      return (
                        <>
                          <tr key={row.block_type} className={conflict ? 'bg-red-50' : ''}>
                            <td className="px-3 py-2 font-medium text-foreground whitespace-nowrap">{row.block_type.replace(' Block', '')}</td>
                            <td className="px-3 py-2 text-muted-foreground whitespace-nowrap">{row.repeat_frequency}</td>
                            <td className="px-3 py-2">
                              <select value={row.day_of_week} onChange={e => updateRow(idx, 'day_of_week', e.target.value)}
                                className="input-base py-1 text-xs min-w-[100px]">
                                {DAYS.map(d => <option key={d}>{d}</option>)}
                              </select>
                            </td>
                            <td className="px-3 py-2">
                              <input type="time" value={row.start_time} onChange={e => updateRow(idx, 'start_time', e.target.value)}
                                className="input-base py-1 text-xs w-24" />
                            </td>
                            <td className="px-3 py-2">
                              <div className="relative">
                                <select value={row.employee} onChange={e => updateRow(idx, 'employee', e.target.value)}
                                  className={`input-base py-1 text-xs min-w-[140px] ${conflict ? 'border-red-400' : ''}`}>
                                  <option value="">Select...</option>
                                  {eligible.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
                                </select>
                                {row.employee && (
                                  <button
                                    onClick={() => setExpandedEmployee(expandedEmployee === `${idx}` ? null : `${idx}`)}
                                    className="mt-1 text-[10px] text-accent underline hover:no-underline block">
                                    View schedule
                                  </button>
                                )}
                                {expandedEmployee === `${idx}` && row.employee && (
                                  <EmployeeSchedulePopover
                                    employeeId={row.employee}
                                    allRules={allRules}
                                    clientId={client.id}
                                    onClose={() => setExpandedEmployee(null)}
                                  />
                                )}
                              </div>
                            </td>
                            <td className="px-3 py-2">
                              {isComplete
                                ? <CheckCircle2 size={14} className="text-green-500" />
                                : <div className="w-3.5 h-3.5 rounded-full border-2 border-border" />}
                            </td>
                          </tr>
                          {conflict && (
                            <tr key={`${row.block_type}-conflict`} className="bg-red-50">
                              <td colSpan={6} className="px-3 pb-2 text-xs text-red-700">
                                <div className="flex items-center gap-1.5">
                                  <AlertTriangle size={12} className="shrink-0" /> {conflict}
                                </div>
                              </td>
                            </tr>
                          )}
                        </>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              <button onClick={handleSave} disabled={!allValid || saving}
                className="w-full py-3 bg-accent text-white rounded-xl font-dm font-semibold text-sm hover:bg-accent/90 disabled:opacity-40 transition-colors">
                {saving ? 'Saving...' : isUpdate ? 'Update Schedule' : 'Create Schedule'}
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}