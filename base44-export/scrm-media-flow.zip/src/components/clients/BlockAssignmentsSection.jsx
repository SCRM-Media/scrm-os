import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Trash2 } from 'lucide-react';

export default function BlockAssignmentsSection({ client, employeesMap }) {
  const [assignments, setAssignments] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    const data = await base44.entities.ClientBlockAssignment.filter({ client: client.id });
    setAssignments(data);
    setLoading(false);
  };

  useEffect(() => { load(); }, [client.id]);

  const handleRemove = async (id) => {
    if (!confirm('Remove this permanent assignment?')) return;
    await base44.entities.ClientBlockAssignment.delete(id);
    load();
  };

  return (
    <div>
      <div className="text-xs font-medium text-muted-foreground mb-2 uppercase tracking-wide">Block Assignments</div>
      {loading ? (
        <div className="text-xs text-muted-foreground">Loading...</div>
      ) : assignments.length === 0 ? (
        <div className="text-xs text-muted-foreground italic">No permanent assignments set.</div>
      ) : (
        <div className="border border-border rounded-lg overflow-hidden">
          <table className="w-full text-xs">
            <thead className="bg-secondary/50">
              <tr>
                <th className="text-left px-3 py-2 font-medium text-muted-foreground">Block Type</th>
                <th className="text-left px-3 py-2 font-medium text-muted-foreground">Employee</th>
                <th className="text-left px-3 py-2 font-medium text-muted-foreground">Set On</th>
                <th className="px-3 py-2"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {assignments.map(a => (
                <tr key={a.id} className="hover:bg-secondary/20">
                  <td className="px-3 py-2 text-foreground font-medium">{a.block_type}</td>
                  <td className="px-3 py-2 text-foreground">{employeesMap[a.employee]?.name || 'Unknown'}</td>
                  <td className="px-3 py-2 text-muted-foreground">{a.created_date ? new Date(a.created_date).toLocaleDateString('en-AU') : '—'}</td>
                  <td className="px-3 py-2 text-right">
                    <button onClick={() => handleRemove(a.id)} className="text-muted-foreground hover:text-destructive transition-colors">
                      <Trash2 size={13} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}