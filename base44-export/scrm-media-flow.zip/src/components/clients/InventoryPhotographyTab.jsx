import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { ExternalLink, Plus, CheckCircle2, Trash2, ZoomIn, X, Printer } from 'lucide-react';

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

function SessionScheduleRow({ index, value, onChange, onRemove, canRemove }) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-xs text-muted-foreground w-16 shrink-0">Session {index + 1}</span>
      <select value={value.day_of_week} onChange={e => onChange({ ...value, day_of_week: e.target.value })} className="input-base flex-1 text-sm">
        {DAYS.map(d => <option key={d}>{d}</option>)}
      </select>
      <input type="time" value={value.start_time} onChange={e => onChange({ ...value, start_time: e.target.value })} className="input-base w-28 text-sm" />
      {canRemove && (
        <button type="button" onClick={onRemove} className="p-1.5 text-muted-foreground hover:text-red-600 transition-colors">×</button>
      )}
    </div>
  );
}

function Field({ label, hint, children }) {
  return (
    <div>
      <label className="block text-xs font-medium text-muted-foreground mb-1.5">
        {label}{hint && <span className="ml-1 opacity-60 font-normal">{hint}</span>}
      </label>
      {children}
    </div>
  );
}

function Toggle({ value, onChange }) {
  return (
    <button type="button" onClick={() => onChange(!value)}
      className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors shrink-0 ${value ? 'bg-accent' : 'bg-border'}`}>
      <span className={`inline-block h-3.5 w-3.5 rounded-full bg-white shadow transition-transform ${value ? 'translate-x-4' : 'translate-x-1'}`} />
    </button>
  );
}

function calcDuration(cars, cph) {
  if (!cars || !cph || cph <= 0) return 0;
  return Math.ceil((cars / cph) * 60 / 15) * 15;
}

function formatDurLabel(mins) {
  if (!mins) return '—';
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${h} hour${h !== 1 ? 's' : ''} ${m} minute${m !== 1 ? 's' : ''}`;
}

// ─── Log Session Modal ────────────────────────────────────────────────────────
function LogSessionModal({ client, employees, onClose, onSaved }) {
  const videographers = employees.filter(e => e.role === 'Content Creator');
  const editors = employees.filter(e => e.role === 'Editor');
  const [form, setForm] = useState({
    session_date: new Date().toISOString().split('T')[0],
    session_type: 'Inventory Photography',
    filmer_employee: '',
    cars_filmed: '',
    stock_numbers: '',
    google_sheet_updated: false,
    upload_destination_link: '',
    session_notes: '',
  });
  const [editTask, setEditTask] = useState({ assigned_editor: '', due_date: '', notes: '' });
  const [saving, setSaving] = useState(false);
  const isStyle2 = form.session_type === 'Inventory Video Style 2';

  const handleSave = async () => {
    if (!form.session_date || !form.cars_filmed) return;
    setSaving(true);
    const session = await base44.entities.InventorySession.create({
      client: client.id,
      session_date: form.session_date,
      session_type: form.session_type,
      filmer_employee: form.filmer_employee || null,
      cars_filmed: Number(form.cars_filmed),
      stock_numbers: form.stock_numbers,
      google_sheet_updated: form.google_sheet_updated,
      upload_destination_link: form.upload_destination_link,
      session_notes: form.session_notes,
      edit_task_created: isStyle2,
    });
    if (isStyle2 && Number(form.cars_filmed) > 0) {
      await base44.entities.InventoryEditTask.create({
        client: client.id,
        inventory_session: session.id,
        session_date: form.session_date,
        video_count: Number(form.cars_filmed),
        estimated_minutes: Number(form.cars_filmed) * 20,
        assigned_editor: editTask.assigned_editor || null,
        due_date: editTask.due_date || null,
        notes: editTask.notes || '',
        status: 'Not Started',
      });
    }
    setSaving(false);
    onSaved();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-card border border-border rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border sticky top-0 bg-card">
          <h3 className="font-dm font-bold text-foreground">Log Inventory Session</h3>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground text-xl leading-none">×</button>
        </div>
        <div className="px-6 py-5 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Session Date *">
              <input type="date" value={form.session_date} onChange={e => setForm(f => ({ ...f, session_date: e.target.value }))} className="input-base" />
            </Field>
            <Field label="Session Type">
              <select value={form.session_type} onChange={e => setForm(f => ({ ...f, session_type: e.target.value }))} className="input-base">
                <option value="Inventory Photography">Inventory Photography</option>
                <option value="Inventory Video Style 1">Inventory Video Style 1</option>
                <option value="Inventory Video Style 2">Inventory Video Style 2</option>
              </select>
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Photographer">
              <select value={form.filmer_employee} onChange={e => setForm(f => ({ ...f, filmer_employee: e.target.value }))} className="input-base">
                <option value="">— None —</option>
                {videographers.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
              </select>
            </Field>
            <Field label="Cars Filmed *">
              <input type="number" value={form.cars_filmed} onChange={e => setForm(f => ({ ...f, cars_filmed: e.target.value }))} className="input-base" placeholder="0" min="0" />
            </Field>
          </div>
          <Field label="Stock / Rego Numbers">
            <textarea value={form.stock_numbers} onChange={e => setForm(f => ({ ...f, stock_numbers: e.target.value }))}
              className="input-base resize-none h-20" placeholder="Enter stock numbers or rego numbers, comma separated" />
          </Field>
          <Field label="Upload Destination Link">
            <input type="url" value={form.upload_destination_link} onChange={e => setForm(f => ({ ...f, upload_destination_link: e.target.value }))} className="input-base" placeholder="https://..." />
          </Field>
          <Field label="Notes">
            <textarea value={form.session_notes} onChange={e => setForm(f => ({ ...f, session_notes: e.target.value }))} className="input-base resize-none h-16" />
          </Field>
          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" checked={form.google_sheet_updated} onChange={e => setForm(f => ({ ...f, google_sheet_updated: e.target.checked }))} className="w-4 h-4 rounded" />
            <span className="text-sm text-foreground">Google Sheet updated</span>
          </label>

          {/* Style 2 edit task — auto-expanded */}
          {isStyle2 && (
            <div className="border border-teal-200 bg-teal-50 rounded-xl p-4 space-y-3">
              <div className="text-xs font-semibold text-teal-800">Create Edit Task</div>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Assigned Editor">
                  <select value={editTask.assigned_editor} onChange={e => setEditTask(t => ({ ...t, assigned_editor: e.target.value }))} className="input-base">
                    <option value="">— None —</option>
                    {editors.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
                  </select>
                </Field>
                <Field label="Due Date">
                  <input type="date" value={editTask.due_date} onChange={e => setEditTask(t => ({ ...t, due_date: e.target.value }))} className="input-base" />
                </Field>
              </div>
              <Field label="Notes">
                <textarea value={editTask.notes} onChange={e => setEditTask(t => ({ ...t, notes: e.target.value }))} className="input-base resize-none h-14" />
              </Field>
              {form.cars_filmed && (
                <p className="text-xs text-teal-700">Edit task will be auto-created: {form.cars_filmed} videos, ~{Number(form.cars_filmed) * 20}min est.</p>
              )}
            </div>
          )}

          <div className="flex gap-3 pt-1">
            <button onClick={onClose} className="flex-1 px-4 py-2.5 border border-border rounded-lg text-sm font-medium text-muted-foreground hover:bg-secondary transition-colors">Cancel</button>
            <button onClick={handleSave} disabled={saving || !form.session_date || !form.cars_filmed}
              className="flex-1 px-4 py-2.5 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accent/90 disabled:opacity-50 transition-colors">
              {saving ? 'Saving...' : 'Log Session'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Print Cheat Sheet ────────────────────────────────────────────────────────
function printCheatSheet(client, form, photos) {
  const win = window.open('', '_blank');
  win.document.write(`
    <html><head><title>${client.name} — Inventory Cheat Sheet</title>
    <style>
      body { font-family: Arial, sans-serif; max-width: 800px; margin: 40px auto; color: #111; }
      h1 { font-size: 22px; margin-bottom: 4px; }
      h2 { font-size: 14px; font-weight: 600; color: #555; margin: 24px 0 6px; border-bottom: 1px solid #ddd; padding-bottom: 4px; }
      p, pre { font-size: 13px; white-space: pre-wrap; margin: 0 0 8px; line-height: 1.6; }
      .gallery { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 8px; }
      .gallery img { width: 130px; height: 100px; object-fit: cover; border-radius: 6px; border: 1px solid #ddd; }
      @media print { body { margin: 20px; } }
    </style></head><body>
    <h1>${client.name} — Inventory Photography Cheat Sheet</h1>
    <p style="color:#888;font-size:12px;">Printed ${new Date().toLocaleDateString('en-AU')}</p>
    ${form.inventory_shot_list ? `<h2>Shot List</h2><pre>${form.inventory_shot_list}</pre>` : ''}
    ${form.inventory_positioning_instructions ? `<h2>Positioning Instructions</h2><pre>${form.inventory_positioning_instructions}</pre>` : ''}
    ${form.inventory_photos_per_car ? `<h2>Photos Per Car</h2><p>${form.inventory_photos_per_car}</p>` : ''}
    ${form.inventory_upload_destination ? `<h2>Upload Destination</h2><p>${form.inventory_upload_destination}</p>` : ''}
    ${form.inventory_specific_angles ? `<h2>Specific Angles</h2><pre>${form.inventory_specific_angles}</pre>` : ''}
    ${form.inventory_extra_notes ? `<h2>Extra Notes</h2><pre>${form.inventory_extra_notes}</pre>` : ''}
    ${photos.length ? `<h2>Reference Photos</h2><div class="gallery">${photos.map(u => `<img src="${u}" />`).join('')}</div>` : ''}
    <script>window.onload=()=>{ window.print(); }<\/script>
    </body></html>
  `);
  win.document.close();
}

// ─── Main Component ───────────────────────────────────────────────────────────
export default function InventoryPhotographyTab({ client, employees, onClientUpdate }) {
  const defaultSchedule = client.inventory_session_schedule?.length
    ? client.inventory_session_schedule
    : [{ day_of_week: 'Monday', start_time: '09:00' }];

  const [schedule, setSchedule] = useState(defaultSchedule);
  const addSession = () => setSchedule(s => [...s, { day_of_week: 'Monday', start_time: '09:00' }]);
  const removeSession = (i) => setSchedule(s => s.filter((_, idx) => idx !== i));
  const updateSession = (i, val) => setSchedule(s => s.map((row, idx) => idx === i ? val : row));

  const [form, setForm] = useState({
    inventory_includes_video: !!client.inventory_includes_video,
    inventory_video_style: client.inventory_video_style || '',
    inventory_cars_per_hour_photos: client.inventory_cars_per_hour_photos || '',
    inventory_cars_per_hour_video: client.inventory_cars_per_hour_video || '',
    inventory_cars_per_session: client.inventory_cars_per_session || '',
    inventory_upload_destination: client.inventory_upload_destination || '',
    inventory_google_sheet_link: client.inventory_google_sheet_link || '',
    inventory_notes: client.inventory_notes || '',
    inventory_shot_list: client.inventory_shot_list || '',
    inventory_positioning_instructions: client.inventory_positioning_instructions || '',
    inventory_photos_per_car: client.inventory_photos_per_car || '',
    inventory_specific_angles: client.inventory_specific_angles || '',
    inventory_extra_notes: client.inventory_extra_notes || '',
  });

  const [sessions, setSessions] = useState([]);
  const [editTasks, setEditTasks] = useState([]);
  const [showLog, setShowLog] = useState(false);
  const [lightboxUrl, setLightboxUrl] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [expandedStock, setExpandedStock] = useState({});
  const examplePhotos = client.inventory_example_photos || [];

  const loadData = async () => {
    const [sess, tasks] = await Promise.all([
      base44.entities.InventorySession.filter({ client: client.id }),
      base44.entities.InventoryEditTask.filter({ client: client.id }),
    ]);
    setSessions(
      sess.filter(s => ['Inventory Photography', 'Inventory Video Style 1', 'Inventory Video Style 2'].includes(s.session_type))
        .sort((a, b) => b.session_date.localeCompare(a.session_date))
    );
    // Sort: incomplete first (by due_date asc), then completed
    const incomplete = tasks.filter(t => t.status !== 'Completed').sort((a, b) => (a.due_date || '').localeCompare(b.due_date || ''));
    const complete = tasks.filter(t => t.status === 'Completed').sort((a, b) => (b.due_date || '').localeCompare(a.due_date || ''));
    setEditTasks([...incomplete, ...complete]);
  };

  useEffect(() => { loadData(); }, [client.id]);

  const save = async () => {
    setSaving(true);
    const cars = Number(form.inventory_cars_per_session || 0);
    const cphP = Number(form.inventory_cars_per_hour_photos || 0);
    const cphV = Number(form.inventory_cars_per_hour_video || 0);
    const dur = calcDuration(cars, form.inventory_includes_video ? cphV : cphP);
    await base44.entities.Client.update(client.id, {
      inventory_includes_video: form.inventory_includes_video,
      inventory_video_style: form.inventory_video_style || null,
      inventory_cars_per_hour_photos: cphP || null,
      inventory_cars_per_hour_video: cphV || null,
      inventory_cars_per_session: cars || null,
      inventory_upload_destination: form.inventory_upload_destination || null,
      inventory_google_sheet_link: form.inventory_google_sheet_link || null,
      inventory_notes: form.inventory_notes || null,
      inventory_shot_list: form.inventory_shot_list || null,
      inventory_positioning_instructions: form.inventory_positioning_instructions || null,
      inventory_photos_per_car: form.inventory_photos_per_car !== '' ? Number(form.inventory_photos_per_car) : null,
      inventory_specific_angles: form.inventory_specific_angles || null,
      inventory_extra_notes: form.inventory_extra_notes || null,
      inventory_session_duration_minutes: dur || null,
      inventory_sessions_per_week: schedule.length,
      inventory_session_schedule: schedule,
    });

    // Sync BlockRules for Inventory Photography
    if (dur > 0) {
      const today = new Date().toISOString().split('T')[0];
      const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
      const existingRules = await base44.entities.BlockRule.filter({ client: client.id, block_type: 'Inventory Photography Block' });
      const activeRules = existingRules.filter(r => !r.rule_end_date || r.rule_end_date >= today);

      // End all existing active rules
      await Promise.all(activeRules.map(r => base44.entities.BlockRule.update(r.id, { rule_end_date: yesterday })));

      // Create one rule per session slot
      await Promise.all(schedule.map(slot =>
        base44.entities.BlockRule.create({
          client: client.id,
          block_type: 'Inventory Photography Block',
          role: 'Content Creator',
          employee: null,
          duration_minutes: dur,
          day_of_week: slot.day_of_week,
          start_time: slot.start_time,
          repeat_frequency: 'Weekly',
          rule_start_date: client.cycle_start_date || today,
        })
      ));
    }

    setSaving(false);
    onClientUpdate && onClientUpdate();
  };

  // Derived
  const carsPerSession = Number(form.inventory_cars_per_session || 0);
  const cphPhotos = Number(form.inventory_cars_per_hour_photos || 0);
  const cphVideo = Number(form.inventory_cars_per_hour_video || 0);
  const effectiveCph = form.inventory_includes_video ? cphVideo : cphPhotos;
  const sessionDurMins = calcDuration(carsPerSession, effectiveCph);

  const handlePhotoUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;
    setUploading(true);
    const urls = await Promise.all(files.map(async file => {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      return file_url;
    }));
    const updated = [...examplePhotos, ...urls];
    await base44.entities.Client.update(client.id, { inventory_example_photos: updated });
    onClientUpdate && onClientUpdate();
    setUploading(false);
  };

  const handleDeletePhoto = async (url) => {
    if (!confirm('Remove this photo?')) return;
    const updated = examplePhotos.filter(p => p !== url);
    await base44.entities.Client.update(client.id, { inventory_example_photos: updated });
    onClientUpdate && onClientUpdate();
  };

  const handleTaskStatusChange = async (id, status) => {
    await base44.entities.InventoryEditTask.update(id, { status });
    loadData();
  };

  const today = new Date().toISOString().split('T')[0];

  const SESSION_TYPE_COLORS = {
    'Inventory Photography': 'bg-teal-100 text-teal-700',
    'Inventory Video Style 1': 'bg-blue-100 text-blue-700',
    'Inventory Video Style 2': 'bg-purple-100 text-purple-700',
  };

  return (
    <div className="space-y-6">
      {/* Section 1 — Configuration */}
      <div className="bg-card border border-border rounded-xl p-4 space-y-4">
        <div className="font-dm font-semibold text-foreground text-sm">Configuration</div>

        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-foreground">Includes Inventory Video</span>
          <Toggle value={form.inventory_includes_video}
            onChange={v => setForm(f => ({ ...f, inventory_includes_video: v }))} />
        </div>

        {form.inventory_includes_video && (
          <Field label="Video Style">
            <select value={form.inventory_video_style}
              onChange={e => setForm(f => ({ ...f, inventory_video_style: e.target.value }))}
              className="input-base">
              <option value="">Select...</option>
              <option value="Style 1 Phone Edited On Spot">Style 1 — Phone Edited On Spot</option>
              <option value="Style 2 Camera Edited Next Day">Style 2 — Camera Edited Next Day</option>
            </select>
          </Field>
        )}

        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Cars / Hour — Photos Only" hint="Set after discovery visit">
            <input type="number" value={form.inventory_cars_per_hour_photos}
              onChange={e => setForm(f => ({ ...f, inventory_cars_per_hour_photos: e.target.value }))}
              className="input-base" placeholder="e.g. 5" step="0.5" min="0.5" />
          </Field>
          {form.inventory_includes_video && (
            <Field label="Cars / Hour — Photos + Video" hint="Lower rate when filming video simultaneously">
              <input type="number" value={form.inventory_cars_per_hour_video}
                onChange={e => setForm(f => ({ ...f, inventory_cars_per_hour_video: e.target.value }))}
                className="input-base" placeholder="e.g. 3" step="0.5" min="0.5" />
            </Field>
          )}
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Cars Per Session">
            <input type="number" value={form.inventory_cars_per_session}
              onChange={e => setForm(f => ({ ...f, inventory_cars_per_session: e.target.value }))}
              className="input-base" placeholder="e.g. 20" min="1" />
          </Field>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Session Duration (calculated)</label>
            <div className="px-3 py-2 bg-secondary/40 rounded-lg text-sm text-foreground border border-border">
              {sessionDurMins > 0 ? formatDurLabel(sessionDurMins) : '—'}
            </div>
            {sessionDurMins > 0 && (
              <p className="text-[10px] text-muted-foreground mt-1">{carsPerSession} ÷ {effectiveCph}/hr = {sessionDurMins}min</p>
            )}
          </div>
        </div>

        {/* Session Schedule */}
        <div className="space-y-2 border-t border-border pt-4">
          <div className="flex items-center justify-between mb-1">
            <label className="text-xs font-medium text-muted-foreground">Session Schedule</label>
            {schedule.length < 5 && (
              <button type="button" onClick={addSession}
                className="flex items-center gap-1 text-xs text-accent hover:text-accent/80 font-medium transition-colors">
                <Plus size={12} /> Add session
              </button>
            )}
          </div>
          {schedule.map((slot, i) => (
            <SessionScheduleRow key={i} index={i} value={slot}
              onChange={val => updateSession(i, val)}
              onRemove={() => removeSession(i)}
              canRemove={schedule.length > 1} />
          ))}
          <p className="text-xs text-muted-foreground">Add multiple sessions for clients with 2–3 visits per week. Each creates a recurring unassigned block.</p>
        </div>

        <Field label="Upload Destination">
          <input type="text" value={form.inventory_upload_destination}
            onChange={e => setForm(f => ({ ...f, inventory_upload_destination: e.target.value }))}
            className="input-base" placeholder="e.g. Google Drive > Client > Inventory Photos" />
        </Field>

        <Field label="Google Sheet Link">
          <div className="flex gap-2">
            <input type="url" value={form.inventory_google_sheet_link}
              onChange={e => setForm(f => ({ ...f, inventory_google_sheet_link: e.target.value }))}
              className="input-base flex-1" placeholder="https://docs.google.com/spreadsheets/..." />
            {form.inventory_google_sheet_link && (
              <a href={form.inventory_google_sheet_link} target="_blank" rel="noreferrer"
                className="px-3 flex items-center rounded-lg border border-border text-accent hover:bg-secondary transition-colors">
                <ExternalLink size={15} />
              </a>
            )}
          </div>
        </Field>

        <Field label="Notes">
          <textarea value={form.inventory_notes}
            onChange={e => setForm(f => ({ ...f, inventory_notes: e.target.value }))}
            className="input-base resize-none h-16" placeholder="Any additional notes..." />
        </Field>

        <div className="flex justify-end pt-1">
          <button onClick={save} disabled={saving}
            className="px-4 py-2 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accent/90 disabled:opacity-50 transition-colors">
            {saving ? 'Saving...' : 'Save'}
          </button>
        </div>
      </div>

      {/* Section 2 — Cheat Sheet */}
      <div className="bg-card border border-border rounded-xl p-4 space-y-4">
        <div className="flex items-center justify-between">
          <div className="font-dm font-semibold text-foreground text-sm">Photographer Cheat Sheet</div>
          <button onClick={() => printCheatSheet(client, form, examplePhotos)}
            className="flex items-center gap-1.5 px-3 py-1.5 border border-border rounded-lg text-xs font-medium text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
            <Printer size={13} /> Print Cheat Sheet
          </button>
        </div>

        <Field label="Shot List" hint="Required shots in order">
          <textarea value={form.inventory_shot_list}
            onChange={e => setForm(f => ({ ...f, inventory_shot_list: e.target.value }))}
            className="input-base resize-none h-28" placeholder={"1. Front 3/4\n2. Rear 3/4\n3. Interior driver side..."} />
        </Field>

        <Field label="Positioning Instructions" hint="Where to position the car and camera">
          <textarea value={form.inventory_positioning_instructions}
            onChange={e => setForm(f => ({ ...f, inventory_positioning_instructions: e.target.value }))}
            className="input-base resize-none h-20" placeholder="Position the car facing north on the forecourt..." />
        </Field>

        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Number of Photos Per Car">
            <input type="number" value={form.inventory_photos_per_car}
              onChange={e => setForm(f => ({ ...f, inventory_photos_per_car: e.target.value }))}
              className="input-base" placeholder="0" />
          </Field>
          <Field label="Upload Destination" hint="Pre-filled from config, syncs back">
            <input type="text" value={form.inventory_upload_destination}
              onChange={e => setForm(f => ({ ...f, inventory_upload_destination: e.target.value }))}
              className="input-base" />
          </Field>
        </div>

        <Field label="Specific Angles Required">
          <textarea value={form.inventory_specific_angles}
            onChange={e => setForm(f => ({ ...f, inventory_specific_angles: e.target.value }))}
            className="input-base resize-none h-20" placeholder="Describe any specific angles required..." />
        </Field>

        <Field label="Extra Notes" hint="Anything else the photographer needs to know">
          <textarea value={form.inventory_extra_notes}
            onChange={e => setForm(f => ({ ...f, inventory_extra_notes: e.target.value }))}
            className="input-base resize-none h-16" placeholder="Any extra notes..." />
        </Field>

        {/* Example Gallery */}
        <div>
          <label className="block text-xs font-medium text-muted-foreground mb-2">Example Gallery <span className="opacity-60 font-normal">Reference photos showing correct angles and style for this dealership</span></label>
          <div className="flex flex-wrap gap-2">
            {examplePhotos.map((url, i) => (
              <div key={i} className="relative group w-24 h-20 rounded-lg overflow-hidden border border-border">
                <img src={url} alt={`Example ${i + 1}`} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-1">
                  <button onClick={() => setLightboxUrl(url)} className="p-1.5 bg-white/90 rounded text-foreground hover:bg-white">
                    <ZoomIn size={12} />
                  </button>
                  <button onClick={() => handleDeletePhoto(url)} className="p-1.5 bg-white/90 rounded text-red-600 hover:bg-white">
                    <Trash2 size={12} />
                  </button>
                </div>
              </div>
            ))}
            <label className="w-24 h-20 rounded-lg border-2 border-dashed border-border flex flex-col items-center justify-center cursor-pointer hover:border-accent/50 hover:bg-secondary/30 transition-colors">
              <Plus size={16} className="text-muted-foreground" />
              <span className="text-[10px] text-muted-foreground mt-1">{uploading ? 'Uploading...' : 'Add photo'}</span>
              <input type="file" accept="image/*" multiple onChange={handlePhotoUpload} className="hidden" disabled={uploading} />
            </label>
          </div>
        </div>
      </div>

      {/* Section 3 — Session Log */}
      <div className="bg-card border border-border rounded-xl p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="font-dm font-semibold text-foreground text-sm">Session Log</div>
          <button onClick={() => setShowLog(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-accent text-white rounded-lg text-xs font-medium hover:bg-accent/90 transition-colors">
            <Plus size={13} /> Log Session
          </button>
        </div>

        {sessions.length === 0 ? (
          <p className="text-xs text-muted-foreground italic">No sessions logged yet.</p>
        ) : (
          <div className="border border-border rounded-xl overflow-hidden">
            <table className="w-full text-xs">
              <thead className="bg-secondary/40 border-b border-border">
                <tr>
                  <th className="text-left px-3 py-2 font-medium text-muted-foreground">Date</th>
                  <th className="text-left px-3 py-2 font-medium text-muted-foreground">Type</th>
                  <th className="text-left px-3 py-2 font-medium text-muted-foreground hidden sm:table-cell">Photographer</th>
                  <th className="text-left px-3 py-2 font-medium text-muted-foreground">Cars</th>
                  <th className="text-left px-3 py-2 font-medium text-muted-foreground hidden md:table-cell">Stock #s</th>
                  <th className="text-center px-3 py-2 font-medium text-muted-foreground">Sheet</th>
                  <th className="text-left px-3 py-2 font-medium text-muted-foreground hidden sm:table-cell">Upload</th>
                  <th className="text-center px-3 py-2 font-medium text-muted-foreground">Edit Task</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {sessions.map(s => {
                  const photographer = employees.find(e => e.id === s.filmer_employee);
                  const stockFull = s.stock_numbers || '';
                  const stockShort = stockFull.length > 50 ? stockFull.slice(0, 50) + '…' : stockFull;
                  const isExpanded = expandedStock[s.id];
                  return (
                    <tr key={s.id} className="hover:bg-secondary/20">
                      <td className="px-3 py-2 font-medium text-foreground whitespace-nowrap">{s.session_date}</td>
                      <td className="px-3 py-2">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium ${SESSION_TYPE_COLORS[s.session_type] || 'bg-gray-100 text-gray-600'}`}>
                          {s.session_type.replace('Inventory ', '')}
                        </span>
                      </td>
                      <td className="px-3 py-2 text-muted-foreground hidden sm:table-cell">{photographer?.name || '—'}</td>
                      <td className="px-3 py-2 font-medium text-foreground">{s.cars_filmed}</td>
                      <td className="px-3 py-2 text-muted-foreground hidden md:table-cell max-w-[120px]">
                        {stockFull ? (
                          <span>
                            {isExpanded ? stockFull : stockShort}
                            {stockFull.length > 50 && (
                              <button onClick={() => setExpandedStock(p => ({ ...p, [s.id]: !p[s.id] }))}
                                className="ml-1 text-accent hover:underline text-[10px]">
                                {isExpanded ? 'less' : 'more'}
                              </button>
                            )}
                          </span>
                        ) : '—'}
                      </td>
                      <td className="px-3 py-2 text-center">
                        {s.google_sheet_updated ? <CheckCircle2 size={13} className="text-green-500 mx-auto" /> : <span className="text-muted-foreground">—</span>}
                      </td>
                      <td className="px-3 py-2 hidden sm:table-cell">
                        {s.upload_destination_link ? (
                          <a href={s.upload_destination_link} target="_blank" rel="noreferrer" className="text-accent hover:underline flex items-center gap-1">Link <ExternalLink size={11} /></a>
                        ) : <span className="text-muted-foreground">—</span>}
                      </td>
                      <td className="px-3 py-2 text-center">
                        {s.edit_task_created ? <CheckCircle2 size={13} className="text-green-500 mx-auto" /> : <span className="text-muted-foreground">—</span>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Edit Tasks subsection */}
        {editTasks.length > 0 && (
          <div className="mt-6 space-y-3">
            <div className="text-sm font-semibold text-foreground">Edit Tasks</div>
            {editTasks.map(task => {
              const editor = employees.find(e => e.id === task.assigned_editor);
              const isOverdue = task.due_date && task.due_date < today && task.status !== 'Completed';
              const h = Math.floor((task.estimated_minutes || 0) / 60);
              const m = (task.estimated_minutes || 0) % 60;
              const timeLabel = `${h}h ${m}m`;
              return (
                <div key={task.id} className={`border rounded-xl p-4 space-y-2 ${task.status === 'Completed' ? 'border-green-200 bg-green-50/30' : isOverdue ? 'border-red-200 bg-red-50/30' : 'border-border bg-card'}`}>
                  <div className="flex items-start justify-between gap-2 flex-wrap">
                    <div className="flex items-center gap-2">
                      {task.status === 'Completed' && <CheckCircle2 size={14} className="text-green-500 shrink-0" />}
                      <span className="text-sm font-medium text-foreground">{task.session_date} — {task.video_count} video{task.video_count !== 1 ? 's' : ''}</span>
                    </div>
                    <select value={task.status} onChange={e => handleTaskStatusChange(task.id, e.target.value)}
                      className="input-base text-xs w-32 py-1">
                      <option>Not Started</option>
                      <option>In Progress</option>
                      <option>Completed</option>
                    </select>
                  </div>
                  <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                    <span>Est: {timeLabel}</span>
                    {editor && <span>Editor: {editor.name}</span>}
                    {task.due_date && (
                      <span className={isOverdue ? 'text-red-600 font-medium' : ''}>
                        Due: {task.due_date}{isOverdue ? ' — Overdue' : ''}
                      </span>
                    )}
                  </div>
                  {task.notes && <p className="text-xs text-foreground">{task.notes}</p>}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Log Session Modal */}
      {showLog && (
        <LogSessionModal
          client={client}
          employees={employees}
          onClose={() => setShowLog(false)}
          onSaved={() => { setShowLog(false); loadData(); }}
        />
      )}

      {/* Lightbox */}
      {lightboxUrl && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80" onClick={() => setLightboxUrl(null)}>
          <button className="absolute top-4 right-4 p-2 bg-white/10 rounded-full text-white hover:bg-white/20">
            <X size={20} />
          </button>
          <img src={lightboxUrl} alt="Preview" className="max-w-[90vw] max-h-[85vh] rounded-xl object-contain" onClick={e => e.stopPropagation()} />
        </div>
      )}
    </div>
  );
}