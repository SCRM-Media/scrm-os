import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { BLOCK_COLORS } from '@/lib/calendarBlocks';
import { formatDuration } from '@/lib/cycleEngine';
import { base44 } from '@/api/base44Client';
import CreateBlockModal from './CreateBlockModal';

// ── Constants ────────────────────────────────────────────────────────────────
const START_HOUR = 7;   // 7am
const END_HOUR   = 20;  // 8pm
const TOTAL_HOURS = END_HOUR - START_HOUR;  // 13
const SLOT_HEIGHT = 60; // px per 60-min slot
const DAY_LABELS  = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

function timeToMinutes(timeStr) {
  if (!timeStr) return START_HOUR * 60;
  const [h, m] = timeStr.split(':').map(Number);
  return h * 60 + m;
}

function minutesToTime(totalMins) {
  const h = Math.floor(totalMins / 60);
  const m = totalMins % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

function minutesToPx(mins) {
  return (mins / 60) * SLOT_HEIGHT;
}

function pxToMinutes(px) {
  return (px / SLOT_HEIGHT) * 60;
}

function snapToQuarter(mins) {
  return Math.round(mins / 15) * 15;
}

function dateToStr(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

// ── TimeLabel column ─────────────────────────────────────────────────────────
const TIME_LABELS = Array.from({ length: TOTAL_HOURS * 2 + 1 }, (_, i) => {
  const totalMins = START_HOUR * 60 + i * 30;
  const h = Math.floor(totalMins / 60);
  const m = totalMins % 60;
  const label = m === 0 ? `${h > 12 ? h - 12 : h}${h >= 12 ? 'pm' : 'am'}` : '';
  return { label, top: i * (SLOT_HEIGHT / 2) };
});

// ── Block card ────────────────────────────────────────────────────────────────
function BlockCard({ block, clientsMap, employeesMap, style, onMouseDown, onClick, isDragging }) {
  const colors = BLOCK_COLORS[block.block_type] || { bg: 'bg-gray-100', text: 'text-gray-800', border: 'border-gray-300' };
  const client = clientsMap[block.client];
  const emp = employeesMap[block.employee];
  const durationMins = block.duration_minutes || 60;
  const isShort = durationMins <= 30;

  return (
    <div
      onMouseDown={onMouseDown}
      onClick={onClick}
      style={style}
      className={`absolute rounded-md border px-1.5 py-1 overflow-hidden select-none cursor-grab active:cursor-grabbing
        ${colors.bg} ${colors.text} ${colors.border}
        ${block.is_unassigned ? 'opacity-75 border-dashed' : ''}
        ${isDragging ? 'opacity-0' : 'hover:shadow-sm hover:brightness-95 transition-all'}
        `}
    >
      <div className="font-semibold text-xs truncate leading-tight">{client?.name || '—'}</div>
      {!isShort && (
        <>
          <div className="text-xs truncate opacity-80 leading-tight">{block.block_type.replace(' Block', '').replace(' Meeting', '')}</div>
          <div className="text-xs opacity-60 leading-tight flex items-center gap-1 mt-0.5">
            <span>{formatDuration(durationMins)}</span>
            {block.is_unassigned
              ? <span className="bg-amber-400 text-amber-900 rounded px-1 text-[10px] font-bold">Unassigned</span>
              : emp ? <span className="truncate">{emp.name}</span> : null}
          </div>
        </>
      )}
      {isShort && (
        <div className="text-[10px] opacity-70 truncate">
          {formatDuration(durationMins)}{emp ? ` · ${emp.name}` : block.is_unassigned ? ' · Unassigned' : ''}
        </div>
      )}
    </div>
  );
}

// ── Main component ─────────────────────────────────────────────────────────
export default function WeekTimeGrid({
  weekDates,
  blocks,
  clientsMap,
  employeesMap,
  clients,
  employees,
  packages,
  onSelectBlock,
  onBlockMoved,
  onBlockCreated,
}) {
  const scrollRef = useRef(null);
  const gridRef   = useRef(null);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [dragging, setDragging]         = useState(null); // { block, origDate, origTime, ghostDate, ghostTime, offsetMins }
  const [ghostPos, setGhostPos]         = useState(null);
  const [overlapPrompt, setOverlapPrompt] = useState(null); // { pendingDate, pendingTime, block }
  const [drawStart, setDrawStart]       = useState(null);   // { dateStr, startMins }
  const [drawEnd, setDrawEnd]           = useState(null);   // mins from grid top
  const [createModal, setCreateModal]   = useState(null);   // { date, start_time, duration_minutes }
  const [adjustedBlockId, setAdjustedBlockId] = useState(null); // animate adjusted block

  // Mobile single-day
  const [isMobile, setIsMobile]   = useState(window.innerWidth < 768);
  const [mobileDayIdx, setMobileDayIdx] = useState(() => {
    const today = dateToStr(new Date());
    const idx = weekDates.findIndex(d => dateToStr(d) === today);
    return idx >= 0 ? idx : 0;
  });

  useEffect(() => {
    const handler = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', handler);
    return () => window.removeEventListener('resize', handler);
  }, []);

  // Scroll to 8am on mount / week change
  useEffect(() => {
    if (scrollRef.current) {
      const scrollTo = minutesToPx((8 - START_HOUR) * 60);
      scrollRef.current.scrollTop = scrollTo;
    }
  }, [weekDates[0]?.toDateString()]);

  // Current time ticker
  useEffect(() => {
    const t = setInterval(() => setCurrentTime(new Date()), 60000);
    return () => clearInterval(t);
  }, []);

  // Build visible day list
  const visibleDays = useMemo(() => {
    if (isMobile) return [weekDates[mobileDayIdx]].filter(Boolean);
    return weekDates;
  }, [isMobile, mobileDayIdx, weekDates]);

  // Blocks grouped by date
  const blocksByDate = useMemo(() => {
    const map = {};
    blocks.forEach(b => {
      if (!map[b.date]) map[b.date] = [];
      map[b.date].push(b);
    });
    return map;
  }, [blocks]);

  // ── Overlap detection ────────────────────────────────────────────────────
  function getOverlap(dateStr, startMins, durationMins, excludeId) {
    const end = startMins + durationMins;
    const dayBlocks = (blocksByDate[dateStr] || []).filter(b => b.id !== excludeId);
    return dayBlocks.find(b => {
      const bStart = timeToMinutes(b.start_time);
      const bEnd   = bStart + (b.duration_minutes || 60);
      return startMins < bEnd && end > bStart;
    });
  }

  // ── Layout: side-by-side for overlapping blocks ──────────────────────────
  function computeLayout(dayBlocks) {
    // Sort by start time
    const sorted = [...dayBlocks].sort((a, b) => timeToMinutes(a.start_time) - timeToMinutes(b.start_time));
    const layout = []; // { block, col, totalCols }

    // Simple greedy column assignment
    const columns = []; // each entry = end time of last block in that column
    const colMap  = {};

    sorted.forEach(b => {
      const start = timeToMinutes(b.start_time);
      const end   = start + (b.duration_minutes || 60);
      let placed  = false;
      for (let c = 0; c < columns.length; c++) {
        if (columns[c] <= start) {
          columns[c] = end;
          colMap[b.id] = c;
          placed = true;
          break;
        }
      }
      if (!placed) {
        colMap[b.id] = columns.length;
        columns.push(end);
      }
    });

    // For each block, count how many columns overlap its time range
    sorted.forEach(b => {
      const start = timeToMinutes(b.start_time);
      const end   = start + (b.duration_minutes || 60);
      let maxCol  = 0;
      sorted.forEach(other => {
        const oStart = timeToMinutes(other.start_time);
        const oEnd   = oStart + (other.duration_minutes || 60);
        if (start < oEnd && end > oStart) {
          maxCol = Math.max(maxCol, colMap[other.id]);
        }
      });
      layout.push({ block: b, col: colMap[b.id], totalCols: maxCol + 1 });
    });

    return layout;
  }

  // ── Grid coordinate helpers ───────────────────────────────────────────────
  function getGridCoords(e, dayIdx) {
    const col = gridRef.current?.querySelector(`[data-day-col="${dayIdx}"]`);
    if (!col) return null;
    const rect = col.getBoundingClientRect();
    const scrollTop = scrollRef.current?.scrollTop || 0;
    const headerH = 48; // sticky header height approx
    const relY = e.clientY - rect.top + scrollTop - headerH;
    return { relY, dateStr: dateToStr(visibleDays[dayIdx]) };
  }

  function yToMins(relY) {
    return snapToQuarter(Math.round(pxToMinutes(relY))) + START_HOUR * 60;
  }

  function clampMins(mins) {
    return Math.max(START_HOUR * 60, Math.min(END_HOUR * 60, mins));
  }

  function getDayIdxFromEvent(e) {
    // Walk up DOM to find data-day-col
    let el = e.target;
    while (el && el !== gridRef.current) {
      const v = el.getAttribute?.('data-day-col');
      if (v !== null && v !== undefined) return parseInt(v);
      el = el.parentElement;
    }
    return -1;
  }

  // ── Drag handlers (block drag) ────────────────────────────────────────────
  const handleBlockMouseDown = useCallback((e, block) => {
    e.preventDefault();
    e.stopPropagation();

    const dayIdx = visibleDays.findIndex(d => dateToStr(d) === block.date);
    const blockStartMins = timeToMinutes(block.start_time);
    const col = gridRef.current?.querySelector(`[data-day-col="${dayIdx}"]`);
    if (!col) return;
    const rect = col.getBoundingClientRect();
    const scrollTop = scrollRef.current?.scrollTop || 0;
    const headerH   = 48;
    const blockTopPx = minutesToPx(blockStartMins - START_HOUR * 60);
    const clickRelY  = e.clientY - rect.top + scrollTop - headerH;
    const offsetMins = Math.max(0, Math.round(pxToMinutes(clickRelY - blockTopPx)));

    setDragging({ block, origDate: block.date, origTime: block.start_time, ghostDate: block.date, ghostTime: block.start_time, offsetMins });
    setGhostPos({ dateStr: block.date, startMins: blockStartMins });
  }, [visibleDays]);

  const handleMouseMove = useCallback((e) => {
    // Block drag
    if (dragging) {
      const dayIdx = getDayIdxFromEvent(e);
      const col = dayIdx >= 0
        ? gridRef.current?.querySelector(`[data-day-col="${dayIdx}"]`)
        : null;
      if (!col) return;
      const rect = col.getBoundingClientRect();
      const scrollTop = scrollRef.current?.scrollTop || 0;
      const headerH = 48;
      const relY = e.clientY - rect.top + scrollTop - headerH;
      const rawMins = yToMins(relY - minutesToPx(dragging.offsetMins));
      const clampedMins = clampMins(rawMins);
      const dateStr = dateToStr(visibleDays[dayIdx >= 0 ? dayIdx : 0]);
      setGhostPos({ dateStr, startMins: clampedMins });
      return;
    }

    // Draw new block
    if (drawStart) {
      const dayIdx = visibleDays.findIndex(d => dateToStr(d) === drawStart.dateStr);
      if (dayIdx < 0) return;
      const col = gridRef.current?.querySelector(`[data-day-col="${dayIdx}"]`);
      if (!col) return;
      const rect = col.getBoundingClientRect();
      const scrollTop = scrollRef.current?.scrollTop || 0;
      const headerH = 48;
      const relY = e.clientY - rect.top + scrollTop - headerH;
      const endMins = clampMins(snapToQuarter(Math.round(pxToMinutes(relY))) + START_HOUR * 60);
      setDrawEnd(endMins);
    }
  }, [dragging, drawStart, visibleDays]);

  const handleMouseUp = useCallback(async (e) => {
    // Block drag drop
    if (dragging && ghostPos) {
      const { block, origDate, origTime } = dragging;
      const { dateStr: newDate, startMins: newStartMins } = ghostPos;

      // Clamp duration within grid
      const duration = block.duration_minutes || 60;
      const clampedStart = Math.min(newStartMins, END_HOUR * 60 - duration);
      const finalStart = Math.max(START_HOUR * 60, clampedStart);

      // No movement?
      const origMins = timeToMinutes(origTime);
      if (newDate === origDate && Math.abs(finalStart - origMins) < 15) {
        setDragging(null);
        setGhostPos(null);
        return;
      }

      // Find overlap
      const overlap = getOverlap(newDate, finalStart, duration, block.id);

      if (overlap) {
        const samePerson = block.is_unassigned || overlap.is_unassigned || block.employee === overlap.employee;
        if (samePerson) {
          // Rule 1: push after existing block
          const overlapEnd = timeToMinutes(overlap.start_time) + (overlap.duration_minutes || 60);
          const adjustedStart = Math.min(overlapEnd, END_HOUR * 60 - duration);
          await base44.entities.CalendarBlock.update(block.id, { date: newDate, start_time: minutesToTime(adjustedStart) });
          setAdjustedBlockId(block.id);
          setTimeout(() => setAdjustedBlockId(null), 1500);
          onBlockMoved();
        } else {
          // Rule 2: different employee — prompt
          setOverlapPrompt({
            pendingDate: newDate,
            pendingTime: minutesToTime(finalStart),
            block,
            overlapBlock: overlap,
          });
        }
      } else {
        // Rule 3: no overlap — place directly
        await base44.entities.CalendarBlock.update(block.id, { date: newDate, start_time: minutesToTime(finalStart) });
        onBlockMoved();
      }

      setDragging(null);
      setGhostPos(null);
      return;
    }

    // Draw end
    if (drawStart) {
      const endMins = drawEnd || drawStart.startMins + 60;
      const durationMins = Math.max(15, endMins - drawStart.startMins);
      setCreateModal({
        date: drawStart.dateStr,
        start_time: minutesToTime(drawStart.startMins),
        duration_minutes: durationMins,
      });
      setDrawStart(null);
      setDrawEnd(null);
    }
  }, [dragging, ghostPos, drawStart, drawEnd, onBlockMoved]);

  // ── Grid mousedown (start draw or block click) ─────────────────────────────
  const handleGridMouseDown = useCallback((e, dayIdx) => {
    if (e.button !== 0) return;
    // Ignore if clicking on a block
    let el = e.target;
    while (el && el !== e.currentTarget) {
      if (el.dataset?.blockId) return;
      el = el.parentElement;
    }
    e.preventDefault();
    const col = gridRef.current?.querySelector(`[data-day-col="${dayIdx}"]`);
    if (!col) return;
    const rect = col.getBoundingClientRect();
    const scrollTop = scrollRef.current?.scrollTop || 0;
    const headerH = 48;
    const relY = e.clientY - rect.top + scrollTop - headerH;
    const startMins = clampMins(snapToQuarter(Math.round(pxToMinutes(relY))) + START_HOUR * 60);
    const dateStr = dateToStr(visibleDays[dayIdx]);
    setDrawStart({ dateStr, startMins });
    setDrawEnd(null);
  }, [visibleDays]);

  // ── Touch swipe for mobile ────────────────────────────────────────────────
  const touchStartX = useRef(null);
  const handleTouchStart = (e) => { touchStartX.current = e.touches[0].clientX; };
  const handleTouchEnd   = (e) => {
    if (touchStartX.current === null) return;
    const dx = e.changedTouches[0].clientX - touchStartX.current;
    if (Math.abs(dx) > 50) {
      setMobileDayIdx(i => dx < 0 ? Math.min(6, i + 1) : Math.max(0, i - 1));
    }
    touchStartX.current = null;
  };

  // ── Current time indicator ────────────────────────────────────────────────
  const currentTimeStr = `${String(currentTime.getHours()).padStart(2,'0')}:${String(currentTime.getMinutes()).padStart(2,'0')}`;
  const currentTimeMins = currentTime.getHours() * 60 + currentTime.getMinutes();
  const showTimeLine = currentTimeMins >= START_HOUR * 60 && currentTimeMins <= END_HOUR * 60;
  const timeLinePx   = minutesToPx(currentTimeMins - START_HOUR * 60);
  const todayStr     = dateToStr(new Date());

  const TIME_COL_W = 52; // px

  return (
    <div
      className="bg-card border border-border rounded-xl overflow-hidden shadow-sm select-none"
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={() => { if (dragging) { setDragging(null); setGhostPos(null); } if (drawStart) { setDrawStart(null); setDrawEnd(null); } }}
      onTouchStart={isMobile ? handleTouchStart : undefined}
      onTouchEnd={isMobile ? handleTouchEnd : undefined}
      ref={gridRef}
    >
      {/* ── Sticky header ─────────────────────────────────────────────────── */}
      <div className="sticky top-0 z-30 bg-card border-b border-border flex">
        {/* Time column header spacer */}
        <div style={{ width: TIME_COL_W, minWidth: TIME_COL_W }} className="shrink-0 border-r border-border/40" />

        {/* Mobile day nav */}
        {isMobile ? (
          <div className="flex-1 flex items-center justify-between px-3 py-2">
            <button onClick={() => setMobileDayIdx(i => Math.max(0, i - 1))} className="p-1 rounded hover:bg-secondary text-muted-foreground">‹</button>
            <div className="text-center">
              <div className="text-xs text-muted-foreground">{DAY_LABELS[mobileDayIdx]}</div>
              <div className={`text-sm font-semibold w-8 h-8 flex items-center justify-center rounded-full mx-auto
                ${dateToStr(weekDates[mobileDayIdx]) === todayStr ? 'bg-accent text-white' : 'text-foreground'}`}>
                {weekDates[mobileDayIdx]?.getDate()}
              </div>
            </div>
            <button onClick={() => setMobileDayIdx(i => Math.min(6, i + 1))} className="p-1 rounded hover:bg-secondary text-muted-foreground">›</button>
          </div>
        ) : (
          visibleDays.map((d, i) => {
            const isToday = dateToStr(d) === todayStr;
            return (
              <div key={i} className={`flex-1 py-2 text-center border-r border-border/40 last:border-r-0 ${isToday ? 'bg-accent/5' : ''}`}>
                <div className="text-xs text-muted-foreground">{DAY_LABELS[weekDates.indexOf(d)]}</div>
                <div className={`text-sm font-semibold w-8 h-8 flex items-center justify-center rounded-full mx-auto mt-0.5
                  ${isToday ? 'bg-accent text-white' : 'text-foreground'}`}>
                  {d.getDate()}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* ── Scrollable body ───────────────────────────────────────────────── */}
      <div ref={scrollRef} className="overflow-y-auto" style={{ maxHeight: 'calc(100vh - 280px)', minHeight: 400 }}>
        <div className="flex" style={{ height: SLOT_HEIGHT * TOTAL_HOURS }}>

          {/* ── Time labels column ─────────────────────────────────────────── */}
          <div
            className="shrink-0 relative border-r border-border/40"
            style={{ width: TIME_COL_W, minWidth: TIME_COL_W }}
          >
            {TIME_LABELS.map(({ label, top }, i) => (
              <div
                key={i}
                className="absolute right-2 text-xs text-muted-foreground"
                style={{ top: top - 8, lineHeight: '16px' }}
              >
                {label}
              </div>
            ))}
            {/* Current time label */}
            {showTimeLine && (
              <div className="absolute right-1 text-[10px] font-bold text-red-500 leading-none z-10"
                style={{ top: timeLinePx - 8 }}>
                {currentTimeStr}
              </div>
            )}
          </div>

          {/* ── Day columns ───────────────────────────────────────────────── */}
          {visibleDays.map((d, dayIdx) => {
            const dateStr = dateToStr(d);
            const isToday = dateStr === todayStr;
            const dayBlocks = blocksByDate[dateStr] || [];
            const layout    = computeLayout(dayBlocks);

            return (
              <div
                key={dateStr}
                data-day-col={dayIdx}
                className={`flex-1 relative border-r border-border/40 last:border-r-0 ${isToday ? 'bg-accent/[0.03]' : ''}`}
                style={{ minWidth: 0 }}
                onMouseDown={e => handleGridMouseDown(e, dayIdx)}
              >
                {/* Hour/half-hour grid lines */}
                {Array.from({ length: TOTAL_HOURS * 2 }).map((_, i) => (
                  <div
                    key={i}
                    className={`absolute left-0 right-0 border-t ${i % 2 === 0 ? 'border-border/60' : 'border-border/25'}`}
                    style={{ top: i * (SLOT_HEIGHT / 2) }}
                  />
                ))}

                {/* Current time line */}
                {isToday && showTimeLine && (
                  <div className="absolute left-0 right-0 z-20 pointer-events-none" style={{ top: timeLinePx }}>
                    <div className="h-[2px] bg-red-500 w-full" />
                    <div className="w-2 h-2 rounded-full bg-red-500 absolute -left-1 -top-[3px]" />
                  </div>
                )}

                {/* Draw ghost */}
                {drawStart?.dateStr === dateStr && drawEnd !== null && (
                  <div
                    className="absolute left-1 right-1 rounded-md border-2 border-dashed border-accent bg-accent/10 z-10 pointer-events-none"
                    style={{
                      top:    minutesToPx(drawStart.startMins - START_HOUR * 60),
                      height: Math.max(15, minutesToPx(Math.max(15, drawEnd - drawStart.startMins))),
                    }}
                  />
                )}

                {/* Ghost block while dragging */}
                {ghostPos?.dateStr === dateStr && dragging && (
                  <div
                    className="absolute left-1 right-1 rounded-md border-2 border-dashed border-accent/70 bg-accent/15 z-10 pointer-events-none"
                    style={{
                      top:    minutesToPx(ghostPos.startMins - START_HOUR * 60),
                      height: minutesToPx(dragging.block.duration_minutes || 60),
                    }}
                  />
                )}

                {/* Blocks */}
                {layout.map(({ block, col, totalCols }) => {
                  const startMins = timeToMinutes(block.start_time);
                  const top       = minutesToPx(startMins - START_HOUR * 60);
                  const height    = Math.max(20, minutesToPx(block.duration_minutes || 60) - 2);
                  const isDragging = dragging?.block?.id === block.id;
                  const isAdjusted = adjustedBlockId === block.id;
                  const widthPct   = 100 / totalCols;
                  const leftPct    = col * widthPct;

                  return (
                    <BlockCard
                      key={block.id}
                      block={block}
                      clientsMap={clientsMap}
                      employeesMap={employeesMap}
                      isDragging={isDragging}
                      style={{
                        top:    top + 1,
                        height,
                        left:   `calc(${leftPct}% + 2px)`,
                        width:  `calc(${widthPct}% - 4px)`,
                        zIndex: isDragging ? 50 : 5,
                        transition: isAdjusted ? 'top 0.3s ease, box-shadow 0.3s ease' : undefined,
                        boxShadow: isAdjusted ? '0 0 0 2px hsl(var(--accent))' : undefined,
                      }}
                      onMouseDown={e => { e.stopPropagation(); handleBlockMouseDown(e, block); }}
                      onClick={e => { e.stopPropagation(); if (!dragging) onSelectBlock(block); }}
                    />
                  );
                })}
              </div>
            );
          })}
        </div>
      </div>

      {/* ── Overlap confirmation prompt ───────────────────────────────────── */}
      {overlapPrompt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
          <div className="bg-card border border-border rounded-xl shadow-2xl p-5 max-w-sm w-full">
            <p className="text-sm text-foreground mb-4">
              This overlaps with <strong>{overlapPrompt.overlapBlock.block_type.replace(' Block','')}</strong> assigned to <strong>{employeesMap[overlapPrompt.overlapBlock.employee]?.name || 'someone'}</strong>.{' '}
              These are different people so this is allowed — are you sure?
            </p>
            <div className="flex gap-3">
              <button
                className="flex-1 px-4 py-2 border border-border rounded-lg text-sm font-medium hover:bg-secondary transition-colors"
                onClick={() => setOverlapPrompt(null)}
              >Cancel</button>
              <button
                className="flex-1 px-4 py-2 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accent/90 transition-colors"
                onClick={async () => {
                  await base44.entities.CalendarBlock.update(overlapPrompt.block.id, {
                    date: overlapPrompt.pendingDate,
                    start_time: overlapPrompt.pendingTime,
                  });
                  onBlockMoved();
                  setOverlapPrompt(null);
                }}
              >Confirm</button>
            </div>
          </div>
        </div>
      )}

      {/* ── Create Block modal (pre-filled) ──────────────────────────────── */}
      {createModal && (
        <CreateBlockModal
          clients={clients}
          employees={employees}
          packages={packages}
          defaultValues={createModal}
          onClose={() => setCreateModal(null)}
          onSave={() => { setCreateModal(null); onBlockCreated(); }}
        />
      )}
    </div>
  );
}