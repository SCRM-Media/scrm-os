import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { BLOCK_COLORS } from '@/lib/calendarBlocks';
import { formatDuration, timeToMinutes, minutesToTime, timesOverlap, dateToStr, addDays } from '@/lib/cycleEngine';

const START_HOUR = 7;
const END_HOUR = 20;
const TOTAL_HOURS = END_HOUR - START_HOUR;
const SLOT_HEIGHT = 60;
const DAY_LABELS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const TIME_COL_W = 52;

function minutesToPx(mins) { return (mins / 60) * SLOT_HEIGHT; }
function pxToMinutes(px) { return (px / SLOT_HEIGHT) * 60; }
function snapToQuarter(mins) { return Math.round(mins / 15) * 15; }

const TIME_LABELS = Array.from({ length: TOTAL_HOURS * 2 + 1 }, (_, i) => {
  const totalMins = START_HOUR * 60 + i * 30;
  const h = Math.floor(totalMins / 60);
  const m = totalMins % 60;
  const label = m === 0 ? `${h > 12 ? h - 12 : h}${h >= 12 ? 'pm' : 'am'}` : '';
  return { label, top: i * (SLOT_HEIGHT / 2) };
});

function InstanceCard({ instance, clientsMap, employeesMap, style, onMouseDown, onClick, isDragging }) {
  const colors = BLOCK_COLORS[instance.block_type] || { bg: 'bg-gray-100', text: 'text-gray-800', border: 'border-gray-300' };
  const client = clientsMap[instance.client];
  const emp = employeesMap[instance.employee];
  const durationMins = instance.duration_minutes || 60;
  const isShort = durationMins <= 30;

  return (
    <div
      onMouseDown={onMouseDown}
      onClick={onClick}
      style={style}
      className={`absolute rounded-md border px-1.5 py-1 overflow-hidden select-none cursor-grab active:cursor-grabbing
        ${colors.bg} ${colors.text} ${colors.border}
        ${instance.is_unassigned ? 'opacity-75 border-dashed' : ''}
        ${isDragging ? 'opacity-0' : 'hover:shadow-sm hover:brightness-95 transition-all'}`}
    >
      <div className="font-semibold text-xs truncate leading-tight">{client?.name || '—'}</div>
      {!isShort && (
        <>
          <div className="text-xs truncate opacity-80 leading-tight">{instance.block_type.replace(' Block', '').replace(' Meeting', '')}</div>
          <div className="text-xs opacity-60 leading-tight flex items-center gap-1 mt-0.5">
            <span>{formatDuration(durationMins)}</span>
            {instance.is_unassigned
              ? <span className="bg-amber-400 text-amber-900 rounded px-1 text-[10px] font-bold">Unassigned</span>
              : emp ? <span className="truncate">{emp.name}</span> : null}
          </div>
        </>
      )}
      {isShort && (
        <div className="text-[10px] opacity-70 truncate">
          {formatDuration(durationMins)}{emp ? ` · ${emp.name}` : instance.is_unassigned ? ' · Unassigned' : ''}
        </div>
      )}
    </div>
  );
}

function instKey(inst) {
  return `${inst.ruleId}||${inst.originalDate || inst.date}`;
}

function computeLayout(dayInstances, offsetMins = 0) {
  const valid = dayInstances.filter(inst => inst && inst.start_time && inst.ruleId && inst.date);
  const sorted = [...valid].sort((a, b) => (timeToMinutes(a.start_time) + offsetMins) - (timeToMinutes(b.start_time) + offsetMins));
  const columns = [];
  const colMap = {};
  sorted.forEach(inst => {
    const key = instKey(inst);
    const start = timeToMinutes(inst.start_time);
    const end = start + (inst.duration_minutes || 60);
    let placed = false;
    for (let c = 0; c < columns.length; c++) {
      if (columns[c] <= start) { columns[c] = end; colMap[key] = c; placed = true; break; }
    }
    if (!placed) { colMap[key] = columns.length; columns.push(end); }
  });
  return sorted.map(inst => {
    const key = instKey(inst);
    const start = timeToMinutes(inst.start_time);
    const end = start + (inst.duration_minutes || 60);
    let maxCol = 0;
    sorted.forEach(other => {
      const os = timeToMinutes(other.start_time);
      const oe = os + (other.duration_minutes || 60);
      if (start < oe && end > os) maxCol = Math.max(maxCol, colMap[instKey(other)] ?? 0);
    });
    return { instance: inst, col: colMap[key] ?? 0, totalCols: maxCol + 1 };
  });
}

export default function RuleWeekTimeGrid({ weekDates, instances = [], clientsMap, employeesMap, rules, exceptions, onSelectInstance, onRefresh, dstOffsetMins = 0 }) {
  const scrollRef = useRef(null);
  const gridRef = useRef(null);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [dragging, setDragging] = useState(null);
  const [ghostPos, setGhostPos] = useState(null);
  const [dragConflict, setDragConflict] = useState(null);
  const [movePrompt, setMovePrompt] = useState(null);
  const [drawStart, setDrawStart] = useState(null);
  const [drawEnd, setDrawEnd] = useState(null);
  const [createModal, setCreateModal] = useState(null);

  const [isMobile, setIsMobile] = useState(() => typeof window !== 'undefined' && window.innerWidth < 768);
  const [mobileDayIdx, setMobileDayIdx] = useState(() => {
    const today = dateToStr(new Date());
    const validDates = weekDates.filter(Boolean);
    const idx = validDates.findIndex(d => dateToStr(d) === today);
    return idx >= 0 ? idx : 0;
  });

  useEffect(() => {
    const h = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', h);
    return () => window.removeEventListener('resize', h);
  }, []);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = minutesToPx((8 - START_HOUR) * 60);
  }, [weekDates[0]?.toDateString()]);

  useEffect(() => {
    const t = setInterval(() => setCurrentTime(new Date()), 60000);
    return () => clearInterval(t);
  }, []);

  const visibleDays = useMemo(() => {
    const validDates = weekDates.filter(d => d instanceof Date && !isNaN(d.getTime()));
    if (validDates.length === 0) return [];
    if (isMobile) {
      const safeIdx = Math.min(mobileDayIdx, validDates.length - 1);
      return [validDates[safeIdx]];
    }
    return validDates;
  }, [isMobile, mobileDayIdx, weekDates]);

  const instancesByDate = useMemo(() => {
    const map = {};
    instances.forEach(inst => {
      const d = inst.date;
      if (!map[d]) map[d] = [];
      map[d].push(inst);
    });
    return map;
  }, [instances]);

  // Find all rules for a given employee
  function getEmployeeRules(employeeId) {
    return rules.filter(r => r.employee === employeeId && (!r.rule_end_date || r.rule_end_date >= dateToStr(new Date())));
  }

  function checkConflict(instance, newDate, newStartTime) {
    if (instance.is_unassigned) return null;
    const empId = instance.employee;
    const newDay = new Date(newDate + 'T00:00:00').toLocaleDateString('en-US', { weekday: 'long' });

    // Check against all other instances on the same date for same employee
    const sameDayInstances = instances.filter(i =>
      i.date === newDate &&
      i.employee === empId &&
      !(i.ruleId === instance.ruleId && i.originalDate === instance.originalDate)
    );

    for (const other of sameDayInstances) {
      if (timesOverlap(newStartTime, instance.duration_minutes, other.start_time, other.duration_minutes)) {
        const emp = employeesMap[empId];
        const otherEnd = minutesToTime(timeToMinutes(other.start_time) + (other.duration_minutes || 60));
        return `${emp?.name || 'This employee'} already has a block from ${other.start_time} to ${otherEnd} on ${newDate}. Choose a different time or employee.`;
      }
    }
    return null;
  }

  function yToMins(relY) {
    return snapToQuarter(Math.round(pxToMinutes(relY))) + START_HOUR * 60;
  }
  function clampMins(mins) { return Math.max(START_HOUR * 60, Math.min(END_HOUR * 60, mins)); }

  function getDayIdxFromEvent(e) {
    let el = e.target;
    while (el && el !== gridRef.current) {
      const v = el.getAttribute?.('data-day-col');
      if (v !== null && v !== undefined) return parseInt(v);
      el = el.parentElement;
    }
    return -1;
  }

  const handleInstanceMouseDown = useCallback((e, instance) => {
    e.preventDefault();
    e.stopPropagation();
    const dayIdx = visibleDays.findIndex(d => dateToStr(d) === instance.date);
    const blockStartMins = timeToMinutes(instance.start_time);
    const col = gridRef.current?.querySelector(`[data-day-col="${dayIdx}"]`);
    if (!col) return;
    const rect = col.getBoundingClientRect();
    const scrollTop = scrollRef.current?.scrollTop || 0;
    const clickRelY = e.clientY - rect.top + scrollTop - 48;
    const offsetMins = Math.max(0, Math.round(pxToMinutes(clickRelY - minutesToPx(blockStartMins - START_HOUR * 60))));
    setDragging({ instance, offsetMins });
    setGhostPos({ dateStr: instance.date, startMins: blockStartMins });
    setDragConflict(null);
  }, [visibleDays]);

  const handleMouseMove = useCallback((e) => {
    if (dragging) {
      const dayIdx = getDayIdxFromEvent(e);
      const col = dayIdx >= 0 ? gridRef.current?.querySelector(`[data-day-col="${dayIdx}"]`) : null;
      if (!col) return;
      const rect = col.getBoundingClientRect();
      const scrollTop = scrollRef.current?.scrollTop || 0;
      const relY = e.clientY - rect.top + scrollTop - 48;
      const rawMins = yToMins(relY - minutesToPx(dragging.offsetMins));
      const clampedMins = clampMins(rawMins);
      const dateStr = dateToStr(visibleDays[dayIdx >= 0 ? dayIdx : 0]);
      setGhostPos({ dateStr, startMins: clampedMins });

      // Real-time conflict check
      const newTime = minutesToTime(clampedMins);
      const conflict = checkConflict(dragging.instance, dateStr, newTime);
      setDragConflict(conflict);
      return;
    }
    if (drawStart) {
      const dayIdx = visibleDays.findIndex(d => dateToStr(d) === drawStart.dateStr);
      if (dayIdx < 0) return;
      const col = gridRef.current?.querySelector(`[data-day-col="${dayIdx}"]`);
      if (!col) return;
      const rect = col.getBoundingClientRect();
      const scrollTop = scrollRef.current?.scrollTop || 0;
      const relY = e.clientY - rect.top + scrollTop - 48;
      setDrawEnd(clampMins(snapToQuarter(Math.round(pxToMinutes(relY))) + START_HOUR * 60));
    }
  }, [dragging, drawStart, visibleDays, instances]);

  const handleMouseUp = useCallback(async (e) => {
    if (dragging && ghostPos) {
      const { instance } = dragging;
      const { dateStr: newDate, startMins: newStartMins } = ghostPos;
      const duration = instance.duration_minutes || 60;
      const finalStartMins = Math.min(newStartMins, END_HOUR * 60 - duration);
      const finalStart = minutesToTime(Math.max(START_HOUR * 60, finalStartMins));

      if (newDate === instance.date && finalStart === instance.start_time) {
        setDragging(null); setGhostPos(null); setDragConflict(null);
        return;
      }

      const conflict = checkConflict(instance, newDate, finalStart);
      if (conflict) {
        // Hard block — show error, don't move
        setDragConflict(conflict);
        setTimeout(() => { setDragging(null); setGhostPos(null); setDragConflict(null); }, 3000);
        return;
      }

      // Prompt: move just this instance or all future?
      setMovePrompt({ instance, newDate, newStartTime: finalStart });
      setDragging(null); setGhostPos(null); setDragConflict(null);
      return;
    }
    if (drawStart) {
      const endMins = drawEnd || drawStart.startMins + 60;
      const durationMins = Math.max(15, endMins - drawStart.startMins);
      setCreateModal({ date: drawStart.dateStr, start_time: minutesToTime(drawStart.startMins), duration_minutes: durationMins });
      setDrawStart(null); setDrawEnd(null);
    }
  }, [dragging, ghostPos, drawStart, drawEnd]);

  const handleGridMouseDown = useCallback((e, dayIdx) => {
    if (e.button !== 0) return;
    let el = e.target;
    while (el && el !== e.currentTarget) {
      if (el.dataset?.instanceKey) return;
      el = el.parentElement;
    }
    e.preventDefault();
    const col = gridRef.current?.querySelector(`[data-day-col="${dayIdx}"]`);
    if (!col) return;
    const rect = col.getBoundingClientRect();
    const scrollTop = scrollRef.current?.scrollTop || 0;
    const relY = e.clientY - rect.top + scrollTop - 48;
    const startMins = clampMins(snapToQuarter(Math.round(pxToMinutes(relY))) + START_HOUR * 60);
    setDrawStart({ dateStr: dateToStr(visibleDays[dayIdx]), startMins });
    setDrawEnd(null);
  }, [visibleDays]);

  const handleMoveSingle = async () => {
    const { instance, newDate, newStartTime } = movePrompt;
    // Create or update a BlockException for this specific instance
    const existingEx = exceptions.find(e => e.block_rule === instance.ruleId && e.original_date === instance.originalDate);
    if (existingEx) {
      await base44.entities.BlockException.update(existingEx.id, { new_date: newDate, new_start_time: newStartTime });
    } else {
      await base44.entities.BlockException.create({
        client: instance.client,
        block_type: instance.block_type,
        block_rule: instance.ruleId,
        original_date: instance.originalDate,
        new_date: newDate,
        new_start_time: newStartTime,
        is_cancelled: false,
      });
    }
    setMovePrompt(null);
    onRefresh();
  };

  const handleMoveAllFuture = async () => {
    const { instance, newDate, newStartTime } = movePrompt;
    const today = dateToStr(new Date());
    const yesterday = dateToStr(addDays(new Date(), -1));
    const rule = rules.find(r => r.id === instance.ruleId);
    if (!rule) { setMovePrompt(null); return; }

    // Get the new day of week from newDate
    const d = new Date(newDate + 'T00:00:00');
    const dowMap = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const newDayOfWeek = dowMap[d.getDay()];

    // End current rule at yesterday
    await base44.entities.BlockRule.update(rule.id, { rule_end_date: yesterday });
    // Create new rule from today
    await base44.entities.BlockRule.create({
      client: rule.client,
      block_type: rule.block_type,
      role: rule.role,
      employee: rule.employee,
      duration_minutes: rule.duration_minutes,
      day_of_week: newDayOfWeek,
      start_time: newStartTime,
      repeat_frequency: rule.repeat_frequency,
      rule_start_date: today,
    });
    setMovePrompt(null);
    onRefresh();
  };

  const todayStr = dateToStr(new Date());
  const currentTimeMins = currentTime.getHours() * 60 + currentTime.getMinutes();
  const showTimeLine = currentTimeMins >= START_HOUR * 60 && currentTimeMins <= END_HOUR * 60;
  const timeLinePx = minutesToPx(currentTimeMins - START_HOUR * 60);
  const currentTimeStr = `${String(currentTime.getHours()).padStart(2, '0')}:${String(currentTime.getMinutes()).padStart(2, '0')}`;

  const touchStartX = useRef(null);

  if (visibleDays.length === 0) return null;

  return (
    <div
      className="bg-card border border-border rounded-xl overflow-hidden shadow-sm select-none"
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={() => { setDragging(null); setGhostPos(null); setDragConflict(null); if (drawStart) { setDrawStart(null); setDrawEnd(null); } }}
      onTouchStart={isMobile ? (e) => { touchStartX.current = e.touches[0].clientX; } : undefined}
      onTouchEnd={isMobile ? (e) => {
        if (touchStartX.current === null) return;
        const dx = e.changedTouches[0].clientX - touchStartX.current;
        if (Math.abs(dx) > 50) setMobileDayIdx(i => dx < 0 ? Math.min(6, i + 1) : Math.max(0, i - 1));
        touchStartX.current = null;
      } : undefined}
      ref={gridRef}
    >
      {/* Conflict banner */}
      {dragConflict && (
        <div className="absolute top-2 left-1/2 -translate-x-1/2 z-50 bg-red-600 text-white text-xs font-semibold px-4 py-2 rounded-xl shadow-lg max-w-sm text-center">
          ⛔ {dragConflict}
        </div>
      )}

      {/* Sticky header */}
      <div className="sticky top-0 z-30 bg-card border-b border-border flex">
        <div style={{ width: TIME_COL_W, minWidth: TIME_COL_W }} className="shrink-0 border-r border-border/40" />
        {isMobile ? (
          <div className="flex-1 flex items-center justify-between px-3 py-2">
            <button onClick={() => setMobileDayIdx(i => Math.max(0, i - 1))} className="p-1 rounded hover:bg-secondary text-muted-foreground">‹</button>
            <div className="text-center">
              <div className="text-xs text-muted-foreground">{DAY_LABELS[mobileDayIdx]}</div>
              <div className={`text-sm font-semibold w-8 h-8 flex items-center justify-center rounded-full mx-auto ${weekDates[mobileDayIdx] && dateToStr(weekDates[mobileDayIdx]) === todayStr ? 'bg-accent text-white' : 'text-foreground'}`}>
                {weekDates[mobileDayIdx]?.getDate()}
              </div>
            </div>
            <button onClick={() => setMobileDayIdx(i => Math.min(6, i + 1))} className="p-1 rounded hover:bg-secondary text-muted-foreground">›</button>
          </div>
        ) : (
          visibleDays.filter(d => d instanceof Date && !isNaN(d.getTime())).map((d, i) => {
            const isToday = dateToStr(d) === todayStr;
            return (
              <div key={i} className={`flex-1 py-2 text-center border-r border-border/40 last:border-r-0 ${isToday ? 'bg-accent/5' : ''}`}>
                <div className="text-xs text-muted-foreground">{DAY_LABELS[i]}</div>
                <div className={`text-sm font-semibold w-8 h-8 flex items-center justify-center rounded-full mx-auto mt-0.5 ${isToday ? 'bg-accent text-white' : 'text-foreground'}`}>
                  {d.getDate()}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Scrollable body */}
      <div ref={scrollRef} className="overflow-y-auto" style={{ maxHeight: 'calc(100vh - 280px)', minHeight: 400 }}>
        <div className="flex" style={{ height: SLOT_HEIGHT * TOTAL_HOURS }}>
          {/* Time labels */}
          <div className="shrink-0 relative border-r border-border/40" style={{ width: TIME_COL_W, minWidth: TIME_COL_W }}>
            {TIME_LABELS.map(({ label, top }, i) => (
              <div key={i} className="absolute right-2 text-xs text-muted-foreground" style={{ top: top - 8, lineHeight: '16px' }}>{label}</div>
            ))}
            {showTimeLine && (
              <div className="absolute right-1 text-[10px] font-bold text-red-500 leading-none z-10" style={{ top: timeLinePx - 8 }}>
                {currentTimeStr}
              </div>
            )}
          </div>

          {/* Day columns */}
          {visibleDays.filter(d => d instanceof Date && !isNaN(d.getTime())).map((d, dayIdx) => {
            const dateStr = dateToStr(d);
            const isToday = dateStr === todayStr;
            const dayInstances = instancesByDate[dateStr] || [];
            const layout = computeLayout(dayInstances, dstOffsetMins);

            return (
              <div
                key={dateStr}
                data-day-col={dayIdx}
                className={`flex-1 relative border-r border-border/40 last:border-r-0 ${isToday ? 'bg-accent/[0.03]' : ''}`}
                style={{ minWidth: 0 }}
                onMouseDown={e => handleGridMouseDown(e, dayIdx)}
              >
                {Array.from({ length: TOTAL_HOURS * 2 }).map((_, i) => (
                  <div key={i} className={`absolute left-0 right-0 border-t ${i % 2 === 0 ? 'border-border/60' : 'border-border/25'}`}
                    style={{ top: i * (SLOT_HEIGHT / 2) }} />
                ))}

                {isToday && showTimeLine && (
                  <div className="absolute left-0 right-0 z-20 pointer-events-none" style={{ top: timeLinePx }}>
                    <div className="h-[2px] bg-red-500 w-full" />
                    <div className="w-2 h-2 rounded-full bg-red-500 absolute -left-1 -top-[3px]" />
                  </div>
                )}

                {drawStart?.dateStr === dateStr && drawEnd !== null && (
                  <div className="absolute left-1 right-1 rounded-md border-2 border-dashed border-accent bg-accent/10 z-10 pointer-events-none"
                    style={{ top: minutesToPx(drawStart.startMins - START_HOUR * 60), height: Math.max(15, minutesToPx(Math.max(15, drawEnd - drawStart.startMins))) }} />
                )}

                {ghostPos?.dateStr === dateStr && dragging && (
                  <div className={`absolute left-1 right-1 rounded-md border-2 border-dashed z-10 pointer-events-none ${dragConflict ? 'border-red-500 bg-red-100' : 'border-accent/70 bg-accent/15'}`}
                    style={{ top: minutesToPx(ghostPos.startMins - START_HOUR * 60), height: minutesToPx(dragging.instance.duration_minutes || 60) }} />
                )}

                {layout.filter(item => item && item.instance).map(({ instance: inst, col, totalCols }) => {
                  const startMins = timeToMinutes(inst.start_time) + dstOffsetMins;
                  const top = minutesToPx(startMins - START_HOUR * 60);
                  const height = Math.max(20, minutesToPx(inst.duration_minutes || 60) - 2);
                  const isDragging = dragging?.instance.ruleId === inst.ruleId && dragging?.instance.originalDate === inst.originalDate;
                  const widthPct = 100 / totalCols;
                  const leftPct = col * widthPct;
                  return (
                    <InstanceCard
                      key={`${inst.ruleId}-${inst.date}`}
                      instance={inst}
                      clientsMap={clientsMap}
                      employeesMap={employeesMap}
                      isDragging={isDragging}
                      style={{ top: top + 1, height, left: `calc(${leftPct}% + 2px)`, width: `calc(${widthPct}% - 4px)`, zIndex: isDragging ? 50 : 5 }}
                      onMouseDown={e => { e.stopPropagation(); handleInstanceMouseDown(e, inst); }}
                      onClick={e => { e.stopPropagation(); if (!dragging) onSelectInstance(inst); }}
                    />
                  );
                })}
              </div>
            );
          })}
        </div>
      </div>

      {/* Move prompt */}
      {movePrompt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
          <div className="bg-card border border-border rounded-xl shadow-2xl p-5 max-w-sm w-full space-y-3">
            <h3 className="font-dm font-semibold text-foreground">Move Block</h3>
            <p className="text-sm text-muted-foreground">
              Move <strong>{movePrompt.instance.block_type.replace(' Block', '')}</strong> to {movePrompt.newDate} at {movePrompt.newStartTime}
            </p>
            <div className="space-y-2 pt-1">
              <button onClick={handleMoveSingle}
                className="w-full px-4 py-2.5 border border-border rounded-lg text-sm font-medium hover:bg-secondary transition-colors text-left">
                Move just this instance
              </button>
              <button onClick={handleMoveAllFuture}
                className="w-full px-4 py-2.5 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accent/90 transition-colors text-left">
                Move all future instances of this block
              </button>
              <button onClick={() => setMovePrompt(null)}
                className="w-full px-4 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Create from draw — simple modal placeholder */}
      {createModal && (
        <CreateFromDrawModal
          defaultValues={createModal}
          onClose={() => setCreateModal(null)}
          onSave={onRefresh}
        />
      )}
    </div>
  );
}

// Minimal create modal for draw-to-create
function CreateFromDrawModal({ defaultValues, onClose, onSave }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
      <div className="bg-card border border-border rounded-xl shadow-2xl p-5 max-w-sm w-full">
        <h3 className="font-dm font-semibold text-foreground mb-2">New Block</h3>
        <p className="text-sm text-muted-foreground mb-4">
          {defaultValues.date} at {defaultValues.start_time} · {defaultValues.duration_minutes}min
        </p>
        <p className="text-xs text-muted-foreground mb-4">To create a scheduled block, go to the client's Schedule tab and add a BlockRule. Draw-to-create creates one-off exceptions.</p>
        <button onClick={onClose} className="w-full px-4 py-2 border border-border rounded-lg text-sm text-muted-foreground hover:bg-secondary transition-colors">Close</button>
      </div>
    </div>
  );
}