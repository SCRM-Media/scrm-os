import BlockCard from './BlockCard';

const DAY_LABELS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

function getMonthGrid(year, month) {
  const firstDay = new Date(year, month, 1);
  let startDow = firstDay.getDay();
  if (startDow === 0) startDow = 7;
  const offset = startDow - 1;
  const cells = [];
  for (let i = 0; i < 42; i++) {
    const d = new Date(year, month, 1 - offset + i);
    cells.push(d);
  }
  return cells;
}

function toKey(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export default function MonthView({ year, month, blocks, clientsMap, employeesMap, onBlockClick }) {
  const today = toKey(new Date());
  const cells = getMonthGrid(year, month);

  const itemsByDate = {};
  blocks.forEach(b => {
    if (!itemsByDate[b.date]) itemsByDate[b.date] = [];
    itemsByDate[b.date].push(b);
  });

  return (
    <div>
      <div className="grid grid-cols-7 border-b border-border">
        {DAY_LABELS.map(d => (
          <div key={d} className="text-center text-xs font-medium text-muted-foreground py-2">{d}</div>
        ))}
      </div>
      <div className="grid grid-cols-7">
        {cells.map((date, i) => {
          const key = toKey(date);
          const dayBlocks = itemsByDate[key] || [];
          const inMonth = date.getMonth() === month;
          return (
            <div key={i} className={`min-h-[100px] p-1 border-r border-b border-border/50 ${!inMonth ? 'bg-secondary/20' : ''}`}>
              <div className={`text-xs font-medium w-6 h-6 flex items-center justify-center rounded-full mb-1
                ${key === today ? 'bg-accent text-white' : inMonth ? 'text-foreground' : 'text-muted-foreground/40'}`}>
                {date.getDate()}
              </div>
              <div className="space-y-0.5">
                {dayBlocks.slice(0, 3).map(b => (
                  <BlockCard key={b.id} block={b} clientsMap={clientsMap} employeesMap={employeesMap} onClick={onBlockClick} compact />
                ))}
                {dayBlocks.length > 3 && (
                  <div className="text-xs text-muted-foreground pl-1">+{dayBlocks.length - 3} more</div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}