import { BLOCK_COLORS } from '@/lib/calendarBlocks';

// Group blocks by color group
const LEGEND_GROUPS = [
  { label: 'Filming', keys: ['Social Media Filming Block', 'Ad Filming Block'] },
  { label: 'CarBee', keys: ['CarBee Filming Block'] },
  { label: 'Editing', keys: ['Social Media Editing Block', 'Ad Editing Block'] },
  { label: 'Planning / Strategy', keys: ['Content Planning Block', 'Strategy Meeting'] },
  { label: 'Ads', keys: ['Ad Scripting Block', 'Meta Ad Setup Block', 'Ads Check and Optimise Block'] },
  { label: 'Delivery', keys: ['Video Send-off Block', 'Scheduling Block'] },
];

export default function CalendarLegend() {
  return (
    <div className="bg-card border border-border rounded-xl px-4 py-3 shadow-sm">
      <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Legend</h3>
      <div className="flex flex-wrap gap-x-5 gap-y-1.5">
        {LEGEND_GROUPS.map(group => {
          const colors = BLOCK_COLORS[group.keys[0]];
          return (
            <div key={group.label} className="flex items-center gap-1.5">
              <div className={`w-2.5 h-2.5 rounded-full shrink-0 ${colors?.dot || 'bg-gray-400'}`} />
              <span className="text-xs text-foreground font-medium">{group.label}</span>
              <span className="text-xs text-muted-foreground hidden sm:inline">
                ({group.keys.map(k => k.replace(' Block', '').replace(' Meeting', '')).join(', ')})
              </span>
            </div>
          );
        })}
        <div className="flex items-center gap-1.5">
          <div className="w-2.5 h-2.5 rounded-full border-2 border-dashed border-amber-400 shrink-0" />
          <span className="text-xs text-foreground font-medium">Unassigned</span>
        </div>
      </div>
    </div>
  );
}