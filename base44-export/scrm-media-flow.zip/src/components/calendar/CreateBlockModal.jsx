import { useState } from 'react';
import { X } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { BLOCK_TYPES, ROLE_FOR_BLOCK, DEFAULT_DURATION } from '@/lib/calendarBlocks';
import { dateToStr } from '@/lib/cycleEngine';

const REPEAT_OPTIONS = ['None', 'Weekly', 'Fortnightly', 'Monthly'];

export default function CreateBlockModal({ clients, employees, packages, onClose, onSave, defaultClient, defaultValues }) {
  const [form, setForm] = useState({
    client: defaultClient?.id || '',
    block_type: 'Social Media Filming Block',
    employee: '',
    date: defaultValues?.date || new Date().toISOString().split('T')[0],
    start_time: defaultValues?.start_time || '09:00',
    duration_minutes: defaultValues?.duration_minutes || DEFAULT_DURATION['Social Media Filming Block'],
    repeat_frequency: 'None',
    repeat_end_date: '',
    notes: '',
  });
  const [saving, setSaving] = useState(false);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const selectedClient = clients.find(c => c.id === form.client);
  const pkgRecord = packages?.find(p => p.name === selectedClient?.package);
  const pkgBlocks = pkgRecord?.blocks || [];
  const noPackage = selectedClient && !selectedClient.package;

  const getDurationForType = (type) => {
    const pkgMatch = pkgBlocks.find(b => b.block_type === type);
    return pkgMatch ? pkgMatch.duration_minutes : (DEFAULT_DURATION[type] || 60);
  };

  const handleClientChange = (clientId) => {
    const newClient = clients.find(c => c.id === clientId);
    const newPkgRecord = packages?.find(p => p.name === newClient?.package);
    const newPkgBlocks = newPkgRecord?.blocks || [];
    const pkgMatch = newPkgBlocks.find(b => b.block_type === form.block_type);
    const newDuration = pkgMatch ? pkgMatch.duration_minutes : (DEFAULT_DURATION[form.block_type] || 60);
    setForm(f => ({ ...f, client: clientId, duration_minutes: newDuration, start_time: '09:00' }));
  };

  const handleTypeChange = (type) => {
    const duration = getDurationForType(type);
    setForm(f => ({ ...f, block_type: type, duration_minutes: duration, start_time: '09:00', employee: '' }));
  };

  const requiredRole = ROLE_FOR_BLOCK[form.block_type];
  const eligibleEmployees = employees.filter(e => e.role === requiredRole);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);

    const blockData = {
      client: form.client,
      block_type: form.block_type,
      employee: form.employee || '',
      is_unassigned: !form.employee,
      date: form.date,
      start_time: form.start_time,
      duration_minutes: parseInt(form.duration_minutes) || 60,
      repeat_frequency: form.repeat_frequency,
      repeat_end_date: form.repeat_end_date || '',
      notes: form.notes,
    };

    // Generate recurrence group
    const recGroupId = `manual-${form.client}-${Date.now()}`;

    // Calculate all instances
    const instances = [];
    const start = new Date(form.date + 'T00:00:00');
    const end = form.repeat_end_date ? new Date(form.repeat_end_date + 'T00:00:00') : new Date(start.getTime() + 90 * 24 * 60 * 60 * 1000); // 90 days default

    const intervalDays = form.repeat_frequency === 'Weekly' ? 7 : form.repeat_frequency === 'Fortnightly' ? 14 : form.repeat_frequency === 'Monthly' ? 30 : null;

    let cursor = new Date(start);
    while (cursor <= end) {
      instances.push({ ...blockData, date: dateToStr(cursor), recurrence_group_id: recGroupId });
      if (!intervalDays) break;
      cursor.setDate(cursor.getDate() + intervalDays);
    }

    await Promise.all(instances.map(b => base44.entities.CalendarBlock.create(b)));
    onSave();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-card rounded-t-2xl sm:rounded-2xl border border-border shadow-2xl w-full sm:max-w-md max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between px-5 py-4 border-b border-border sticky top-0 bg-card z-10">
          <h2 className="font-dm font-bold text-foreground">Create Calendar Block</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X size={18} /></button>
        </div>

        <form onSubmit={handleSubmit} className="px-5 py-5 space-y-4">
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Client *</label>
            <select required value={form.client} onChange={e => handleClientChange(e.target.value)} className="input-base">
              <option value="">Select client...</option>
              {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
            {noPackage && (
              <p className="text-xs text-amber-600 mt-1.5 font-medium">⚠️ This client has no package assigned — please update their profile first.</p>
            )}
          </div>

          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Block Type *</label>
            <select value={form.block_type} onChange={e => handleTypeChange(e.target.value)} className="input-base">
              {BLOCK_TYPES.map(t => <option key={t}>{t}</option>)}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">
              Assigned Employee <span className="opacity-60">({requiredRole})</span>
            </label>
            <select value={form.employee} onChange={e => set('employee', e.target.value)} className="input-base">
              <option value="">Unassigned</option>
              {eligibleEmployees.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Date *</label>
              <input type="date" required value={form.date} onChange={e => set('date', e.target.value)} className="input-base" />
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Start Time</label>
              <input type="time" value={form.start_time} onChange={e => set('start_time', e.target.value)} className="input-base" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Duration (minutes)</label>
            <input type="number" value={form.duration_minutes} onChange={e => set('duration_minutes', e.target.value)} className="input-base" min="5" />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Repeat</label>
              <select value={form.repeat_frequency} onChange={e => set('repeat_frequency', e.target.value)} className="input-base">
                {REPEAT_OPTIONS.map(r => <option key={r}>{r}</option>)}
              </select>
            </div>
            {form.repeat_frequency !== 'None' && (
              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-1.5">Repeat Until</label>
                <input type="date" value={form.repeat_end_date} onChange={e => set('repeat_end_date', e.target.value)} className="input-base" />
              </div>
            )}
          </div>

          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Notes</label>
            <textarea value={form.notes} onChange={e => set('notes', e.target.value)}
              className="input-base resize-none h-20" placeholder="Optional notes..." />
          </div>

          <div className="flex gap-3 pt-1">
            <button type="button" onClick={onClose}
              className="flex-1 px-4 py-2.5 border border-border rounded-lg text-sm font-medium text-foreground hover:bg-secondary transition-colors">
              Cancel
            </button>
            <button type="submit" disabled={saving}
              className="flex-1 px-4 py-2.5 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accent/90 transition-colors disabled:opacity-50">
              {saving ? 'Creating...' : 'Create Block'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}