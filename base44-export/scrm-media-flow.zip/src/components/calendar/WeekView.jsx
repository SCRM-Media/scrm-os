import BlockCard from './BlockCard';

const HOURS = Array.from({ length: 13 }, (_, i) => i + 7); // 7am to 7pm
const DAY_LABELS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

function getWeekDays(baseDate) {
  const dow = baseDate.getDay();
  const daysToMon = dow === 0 ? 6 : dow - 1;
  const mon = new Date(baseDate);
  mon.setDate(baseDate.getDate() - daysToMon);
  mon.setHours(0, 0, 0, 0);
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(mon);
    d.setDate(mon.getDate() + i);
    return d;
  });
}

function toKey(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export default function WeekView({ weekBase, blocks, clientsMap, employeesMap, onBlockClick }) {
  const days = getWeekDays(weekBase);
  const today = toKey(new Date());

  const itemsByDate = {};
  blocks.forEach(b => {
    if (!itemsByDate[b.date]) itemsByDate[b.date] = {};
    const hour = b.start_time ? parseInt(b.start_time.split(':')[0]) : 9;
    if (!itemsByDate[b.date][hour]) itemsByDate[b.date][hour] = [];
    itemsByDate[b.date][hour].push(b);
  });

  return (
    <div className="overflow-x-auto">
      <div className="min-w-[700px]">
        {/* Day headers */}
        <div className="grid grid-cols-8 border-b border-border">
          <div className="py-2 text-xs text-muted-foreground text-center" />
          {days.map((d, i) => (
            <div key={i} className={`py-2 text-center border-l border-border/50 ${toKey(d) === today ? 'bg-accent/10' : ''}`}>
              <div className="text-xs text-muted-foreground">{DAY_LABELS[i]}</div>
              <div className={`text-sm font-semibold mt-0.5 w-7 h-7 flex items-center justify-center rounded-full mx-auto
                ${toKey(d) === today ? 'bg-accent text-white' : 'text-foreground'}`}>
                {d.getDate()}
              </div>
            </div>
          ))}
        </div>

        {/* Time rows */}
        {HOURS.map(hour => (
          <div key={hour} className="grid grid-cols-8 border-b border-border/30 min-h-[56px]">
            <div className="text-xs text-muted-foreground text-right pr-3 pt-1 shrink-0 w-full">
              {hour === 12 ? '12pm' : hour > 12 ? `${hour - 12}pm` : `${hour}am`}
            </div>
            {days.map((d, i) => {
              const key = toKey(d);
              const cellBlocks = (itemsByDate[key] || {})[hour] || [];
              return (
                <div key={i} className={`border-l border-border/50 p-1 space-y-0.5 ${toKey(d) === today ? 'bg-accent/5' : ''}`}>
                  {cellBlocks.map(b => (
                    <BlockCard key={b.id} block={b} clientsMap={clientsMap} employeesMap={employeesMap} onClick={onBlockClick} />
                  ))}
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}