import { BLOCK_COLORS, formatDuration } from '@/lib/calendarBlocks';

export default function BlockCard({ block, clientsMap, employeesMap, onClick, compact = false }) {
  const colors = BLOCK_COLORS[block.block_type] || { bg: 'bg-gray-100', text: 'text-gray-800', border: 'border-gray-300' };
  const clientName = clientsMap[block.client]?.name || 'Unknown Client';
  const employeeName = block.employee ? (employeesMap[block.employee]?.name || 'Unknown') : null;

  if (compact) {
    return (
      <button
        onClick={() => onClick(block)}
        className={`w-full text-left text-xs px-1.5 py-0.5 rounded truncate font-medium leading-tight ${colors.bg} ${colors.text} hover:opacity-80 transition-opacity`}
      >
        {clientName}
      </button>
    );
  }

  return (
    <button
      onClick={() => onClick(block)}
      className={`w-full text-left p-2 rounded-lg border ${colors.bg} ${colors.border} ${colors.text} hover:opacity-90 transition-opacity shadow-sm`}
    >
      <div className="font-semibold text-xs truncate">{clientName}</div>
      <div className="text-xs opacity-80 truncate">{block.block_type}</div>
      <div className="flex items-center justify-between mt-1">
        <span className="text-xs opacity-70">{formatDuration(block.duration_minutes)}</span>
        {block.is_unassigned ? (
          <span className="text-xs bg-orange-200 text-orange-800 px-1.5 py-0.5 rounded font-medium">Unassigned</span>
        ) : (
          <span className="text-xs opacity-70 truncate max-w-[80px]">{employeeName}</span>
        )}
      </div>
    </button>
  );
}