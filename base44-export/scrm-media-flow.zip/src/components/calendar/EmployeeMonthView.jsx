import { ChevronLeft, ChevronRight } from 'lucide-react';
import { BLOCK_COLORS } from '@/lib/calendarBlocks';

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

function getDaysInMonth(date) {
  return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
}

function getFirstDayOfMonth(date) {
  return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
}

function dateToStr(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

export default function EmployeeMonthView({ month, blocks, clientsMap, employeesMap, onSelectBlock, onPrevMonth, onNextMonth }) {
  const daysInMonth = getDaysInMonth(month);
  const firstDay = getFirstDayOfMonth(month);
  const days = [];

  // Add empty cells for days before month starts
  for (let i = 0; i < firstDay; i++) {
    days.push(null);
  }

  // Add days of month
  for (let i = 1; i <= daysInMonth; i++) {
    days.push(i);
  }

  const blocksByDate = {};
  blocks.forEach(b => {
    if (!blocksByDate[b.date]) blocksByDate[b.date] = [];
    blocksByDate[b.date].push(b);
  });

  const monthStr = month.toLocaleDateString('en-AU', { month: 'long', year: 'numeric' });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-dm font-bold text-foreground">{monthStr}</h2>
        <div className="flex items-center gap-1 bg-card border border-border rounded-lg px-1 py-1">
          <button onClick={onPrevMonth} className="p-1.5 rounded hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors">
            <ChevronLeft size={16} />
          </button>
          <button onClick={onNextMonth} className="p-1.5 rounded hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors">
            <ChevronRight size={16} />
          </button>
        </div>
      </div>

      <div className="bg-card border border-border rounded-xl overflow-hidden shadow-sm">
        <div className="grid grid-cols-7 border-b border-border">
          {DAYS.map(day => (
            <div key={day} className="py-2 px-1 text-center border-r border-border/50 last:border-r-0 text-xs font-medium text-muted-foreground">
              {day}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7 min-h-[500px]">
          {days.map((day, i) => {
            if (day === null) {
              return <div key={`empty-${i}`} className="bg-secondary/20 border-r border-b border-border/50 last:border-r-0" />;
            }

            const dateStr = dateToStr(new Date(month.getFullYear(), month.getMonth(), day));
            const dayBlocks = blocksByDate[dateStr] || [];

            return (
              <div key={day} className="min-h-[70px] border-r border-b border-border/50 last:border-r-0 p-1.5 space-y-1">
                <div className="text-xs font-medium text-foreground">{day}</div>
                {dayBlocks.slice(0, 2).map((b) => {
                  const colors = BLOCK_COLORS[b.block_type] || { bg: 'bg-gray-100', text: 'text-gray-800' };
                  const client = clientsMap[b.client];
                  return (
                    <button
                      key={b.id}
                      onClick={() => onSelectBlock(b)}
                      className={`w-full text-left text-xs rounded px-1 py-0.5 truncate ${colors.bg} ${colors.text} hover:opacity-80 transition-opacity`}
                    >
                      {client?.name}
                    </button>
                  );
                })}
                {dayBlocks.length > 2 && (
                  <div className="text-xs text-muted-foreground px-1">+{dayBlocks.length - 2} more</div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}