import { useState, useRef, useEffect } from 'react';
import { ChevronDown, Check } from 'lucide-react';

/**
 * A checklist-style multi-select dropdown.
 * Props:
 *   options: [{ value, label }]
 *   selected: Set of selected values (empty = "all")
 *   onChange: (newSet) => void
 *   allLabel: string — label shown when nothing selected (e.g. "All Clients")
 */
export default function MultiSelectDropdown({ options, selected, onChange, allLabel }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const toggle = (value) => {
    const next = new Set(selected);
    if (next.has(value)) next.delete(value);
    else next.add(value);
    onChange(next);
  };

  const selectAll = () => onChange(new Set());

  const selectedCount = selected.size;
  const label = selectedCount === 0
    ? allLabel
    : selectedCount === 1
      ? options.find(o => selected.has(o.value))?.label ?? allLabel
      : `${selectedCount} selected`;

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen(o => !o)}
        className="flex items-center gap-2 px-3 py-2 text-sm border border-border rounded-lg bg-card hover:bg-secondary transition-colors focus:outline-none whitespace-nowrap"
      >
        <span className={selectedCount > 0 ? 'text-foreground font-medium' : 'text-muted-foreground'}>{label}</span>
        <ChevronDown size={14} className={`text-muted-foreground transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      {open && (
        <div className="absolute z-50 mt-1 min-w-[180px] max-h-72 overflow-y-auto bg-card border border-border rounded-xl shadow-lg py-1">
          {/* All option */}
          <button
            onClick={selectAll}
            className="w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-secondary transition-colors"
          >
            <div className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 ${selectedCount === 0 ? 'bg-accent border-accent' : 'border-border'}`}>
              {selectedCount === 0 && <Check size={11} className="text-white" />}
            </div>
            <span className={selectedCount === 0 ? 'font-medium text-foreground' : 'text-muted-foreground'}>{allLabel}</span>
          </button>

          <div className="border-t border-border/50 my-1" />

          {options.map(opt => {
            const checked = selected.has(opt.value);
            return (
              <button
                key={opt.value}
                onClick={() => toggle(opt.value)}
                className="w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-secondary transition-colors"
              >
                <div className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 ${checked ? 'bg-accent border-accent' : 'border-border'}`}>
                  {checked && <Check size={11} className="text-white" />}
                </div>
                <span className={`truncate ${checked ? 'font-medium text-foreground' : 'text-muted-foreground'}`}>{opt.label}</span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}