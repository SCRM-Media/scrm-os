import { useState, useEffect } from 'react';
import { X, Star, Trash2, Ban, ClipboardList } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { ROLE_FOR_BLOCK } from '@/lib/calendarBlocks';
import { dateToStr, addDays } from '@/lib/cycleEngine';
import LogSessionModal from '@/components/calendar/LogSessionModal.jsx';

export default function BlockRuleDetailPanel({ instance, clients, employees, rules, exceptions, clientsMap, employeesMap, onClose, onRefresh }) {
  const [showLogSession, setShowLogSession] = useState(false);
  const [form, setForm] = useState({
    employee: instance.employee || '',
    date: instance.date,
    start_time: instance.start_time,
    duration_minutes: instance.duration_minutes || 60,
    notes: '',
  });
  const [saving, setSaving] = useState(false);
  const [savingPermanent, setSavingPermanent] = useState(false);

  const rule = rules.find(r => r.id === instance.ruleId);
  const client = clientsMap[instance.client];
  const requiredRole = ROLE_FOR_BLOCK[instance.block_type];
  // Primary role first, then others
  const primaryEmployees = requiredRole ? employees.filter(e => e.role === requiredRole) : employees;
  const otherEmployees = requiredRole ? employees.filter(e => e.role !== requiredRole) : [];

  // Load existing exception note if any
  useEffect(() => {
    const ex = exceptions.find(e => e.block_rule === instance.ruleId && e.original_date === instance.originalDate);
    if (ex?.note) setForm(f => ({ ...f, notes: ex.note }));
  }, []);

  const permanentEmployee = rule?.employee ? employeesMap[rule.employee] : null;

  const handleSaveInstance = async () => {
    setSaving(true);
    const ex = exceptions.find(e => e.block_rule === instance.ruleId && e.original_date === instance.originalDate);
    const exData = {
      client: instance.client,
      block_type: instance.block_type,
      block_rule: instance.ruleId,
      original_date: instance.originalDate,
      new_date: form.date !== instance.originalDate ? form.date : null,
      new_start_time: form.start_time,
      new_employee: form.employee !== rule?.employee ? form.employee : null,
      is_cancelled: false,
      note: form.notes,
    };
    if (ex) {
      await base44.entities.BlockException.update(ex.id, exData);
    } else {
      await base44.entities.BlockException.create(exData);
    }
    setSaving(false);
    onRefresh();
  };

  const handleSavePermanent = async () => {
    setSavingPermanent(true);
    // Update the BlockRule's employee and duration
    if (rule) {
      await base44.entities.BlockRule.update(rule.id, {
        employee: form.employee || null,
        duration_minutes: form.duration_minutes,
        start_time: form.start_time,
      });
    }
    // Upsert ClientBlockAssignment for historical tracking
    if (form.employee) {
      const existing = await base44.entities.ClientBlockAssignment.filter({ client: instance.client, block_type: instance.block_type });
      if (existing.length > 0) {
        await base44.entities.ClientBlockAssignment.update(existing[0].id, { employee: form.employee });
      } else {
        await base44.entities.ClientBlockAssignment.create({ client: instance.client, block_type: instance.block_type, employee: form.employee });
      }
    }
    setSavingPermanent(false);
    onRefresh();
  };

  const handleRemovePermanent = async () => {
    if (!confirm('Remove permanent assignment? Future instances will become unassigned.')) return;
    if (rule) await base44.entities.BlockRule.update(rule.id, { employee: null });
    const existing = await base44.entities.ClientBlockAssignment.filter({ client: instance.client, block_type: instance.block_type });
    await Promise.all(existing.map(e => base44.entities.ClientBlockAssignment.delete(e.id)));
    onRefresh();
  };

  const handleCancelInstance = async () => {
    if (!confirm('Cancel just this one occurrence? It will be hidden from the calendar.')) return;
    const ex = exceptions.find(e => e.block_rule === instance.ruleId && e.original_date === instance.originalDate);
    if (ex) {
      await base44.entities.BlockException.update(ex.id, { is_cancelled: true });
    } else {
      await base44.entities.BlockException.create({
        client: instance.client,
        block_type: instance.block_type,
        block_rule: instance.ruleId,
        original_date: instance.originalDate,
        is_cancelled: true,
      });
    }
    onRefresh();
  };

  const handleDeleteAllFuture = async () => {
    if (!confirm('Delete all future instances of this block rule? This sets an end date on the rule from yesterday.')) return;
    const yesterday = dateToStr(addDays(new Date(), -1));
    if (rule) await base44.entities.BlockRule.update(rule.id, { rule_end_date: yesterday });
    onRefresh();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
      <div className="bg-card rounded-2xl border border-border shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border sticky top-0 bg-card z-10">
          <div>
            <h2 className="font-dm font-bold text-foreground">{instance.block_type}</h2>
            <p className="text-xs text-muted-foreground mt-0.5">{client?.name} · {instance.date}</p>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X size={18} /></button>
        </div>

        <div className="px-6 py-5 space-y-4">
          {/* Permanent assignment badge */}
          {permanentEmployee && (
            <div className="flex items-center justify-between bg-accent/5 border border-accent/20 rounded-lg px-3 py-2">
              <div className="flex items-center gap-2">
                <Star size={13} className="text-accent" />
                <span className="text-xs font-medium text-foreground">Permanent: {permanentEmployee.name}</span>
              </div>
              <button onClick={handleRemovePermanent} className="text-xs text-muted-foreground hover:text-destructive transition-colors">Remove</button>
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">
              Employee {requiredRole && <span className="opacity-60">({requiredRole})</span>}
            </label>
            <select value={form.employee} onChange={e => setForm(f => ({ ...f, employee: e.target.value }))} className="input-base">
              <option value="">Unassigned</option>
              {primaryEmployees.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
              {otherEmployees.length > 0 && (
                <optgroup label="Other employees">
                  {otherEmployees.map(e => <option key={e.id} value={e.id}>{e.name} ({e.role})</option>)}
                </optgroup>
              )}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Date</label>
              <input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))} className="input-base" />
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Start Time</label>
              <input type="time" value={form.start_time} onChange={e => setForm(f => ({ ...f, start_time: e.target.value }))} className="input-base" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Duration (minutes)</label>
            <input type="number" min="15" step="15" value={form.duration_minutes}
              onChange={e => setForm(f => ({ ...f, duration_minutes: Number(e.target.value) }))}
              className="input-base w-32" />
          </div>

          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Notes</label>
            <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
              className="input-base resize-none h-16" placeholder="Optional notes..." />
          </div>

          {/* Rule info */}
          {rule && (
            <div className="text-xs text-muted-foreground bg-secondary/40 rounded-lg px-3 py-2">
              Rule: {rule.repeat_frequency} · {rule.day_of_week} · {rule.start_time}
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-2 pt-1">
            <button onClick={handleSaveInstance} disabled={saving}
              className="flex-1 flex items-center justify-center gap-2 px-3 py-2.5 border border-border rounded-lg text-sm font-medium hover:bg-secondary transition-colors disabled:opacity-50">
              {saving ? 'Saving...' : 'Save this instance'}
            </button>
            <button onClick={handleSavePermanent} disabled={savingPermanent}
              className="flex-1 flex items-center justify-center gap-2 px-3 py-2.5 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accent/90 transition-colors disabled:opacity-50">
              <Star size={13} /> {savingPermanent ? 'Saving...' : 'Save permanently'}
            </button>
          </div>

          <div className="flex gap-2 border-t border-border pt-3">
            <button onClick={handleCancelInstance}
              className="flex-1 flex items-center justify-center gap-2 px-3 py-2 border border-border rounded-lg text-xs text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
              <Ban size={13} /> Cancel this instance
            </button>
            <button onClick={handleDeleteAllFuture}
              className="flex-1 flex items-center justify-center gap-2 px-3 py-2 border border-destructive/30 rounded-lg text-xs text-destructive hover:bg-destructive/5 transition-colors">
              <Trash2 size={13} /> Delete all future
            </button>
          </div>

          {(instance.block_type === 'CarBee Filming Block' || instance.block_type === 'Inventory Photography Block') && client && (
            <button onClick={() => setShowLogSession(true)}
              className={`w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                instance.block_type === 'CarBee Filming Block'
                  ? 'border border-yellow-300 bg-yellow-50 text-yellow-800 hover:bg-yellow-100'
                  : 'border border-teal-300 bg-teal-50 text-teal-800 hover:bg-teal-100'
              }`}>
              <ClipboardList size={14} /> Log {instance.block_type === 'CarBee Filming Block' ? 'CarBee' : 'Inventory'} Session
            </button>
          )}
        </div>
      </div>

      {showLogSession && client && (
        <LogSessionModal
          client={client}
          defaultDate={instance.date}
          defaultSessionType={instance.block_type === 'Inventory Photography Block' ? 'Inventory Photography' : 'CarBee'}
          employees={employees}
          onClose={() => setShowLogSession(false)}
          onSaved={() => { setShowLogSession(false); onRefresh(); }}
        />
      )}
    </div>
  );
}