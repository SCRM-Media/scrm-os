import { AlertCircle } from 'lucide-react';
import { dateToStr, getCurrentCycleStart, addDays } from '@/lib/cycleEngine';
import CycleCalendarGrid from '@/components/calendar/CycleCalendarGrid';

const STATE_COLORS = {
  VIC: 'bg-blue-100 text-blue-700',
  NSW: 'bg-purple-100 text-purple-700',
  QLD: 'bg-orange-100 text-orange-700',
  WA: 'bg-teal-100 text-teal-700',
  SA: 'bg-pink-100 text-pink-700',
  TAS: 'bg-indigo-100 text-indigo-700',
  NT: 'bg-amber-100 text-amber-700',
  ACT: 'bg-green-100 text-green-700',
};

export default function CycleStartDatesView({ clients }) {
  const today = dateToStr(new Date());

  const withCycle = clients
    .filter(c => (c.status === 'Active' || c.status === 'Onboarding') && c.cycle_start_date)
    .map(c => {
      const cycleStart = getCurrentCycleStart(c.cycle_start_date);
      const cycleStartStr = dateToStr(cycleStart);
      const nextCycleStart = dateToStr(addDays(cycleStart, 28));
      const daysIntoCycle = Math.floor((new Date(today) - new Date(cycleStartStr)) / (1000 * 60 * 60 * 24));
      const daysUntilNext = Math.floor((new Date(nextCycleStart) - new Date(today)) / (1000 * 60 * 60 * 24));
      return { ...c, cycleStartStr, nextCycleStart, daysIntoCycle, daysUntilNext };
    })
    .sort((a, b) => a.cycleStartStr.localeCompare(b.cycleStartStr));

  const noCycle = clients.filter(c =>
    (c.status === 'Active' || c.status === 'Onboarding') && !c.cycle_start_date
  );

  return (
    <div className="space-y-6">
      {/* Summary strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <StatCard label="Total Active" value={withCycle.length} />
        <StatCard label="Missing Cycle Date" value={noCycle.length} warn={noCycle.length > 0} />
        <StatCard label="Cycle Renewing ≤7 days" value={withCycle.filter(c => c.daysUntilNext <= 7).length} />
        <StatCard label="New This Cycle" value={withCycle.filter(c => c.daysIntoCycle <= 7).length} />
      </div>

      {/* Missing cycle dates warning */}
      {noCycle.length > 0 && (
        <div className="flex items-start gap-2 bg-amber-50 border border-amber-200 rounded-xl px-4 py-3">
          <AlertCircle size={15} className="text-amber-600 shrink-0 mt-0.5" />
          <div className="text-sm text-amber-800">
            <span className="font-semibold">{noCycle.length} client{noCycle.length > 1 ? 's' : ''} missing cycle start date: </span>
            {noCycle.map(c => c.name).join(', ')}
          </div>
        </div>
      )}

      {/* 4-Week Cycle Calendar */}
      <CycleCalendarGrid clients={clients} />

      {/* Client cycle table */}
      <div className="bg-card border border-border rounded-xl overflow-hidden shadow-sm">
        <div className="px-4 py-3 border-b border-border bg-secondary/30">
          <h3 className="text-sm font-semibold text-foreground">Client Cycle Start Dates</h3>
          <p className="text-xs text-muted-foreground mt-0.5">All active & onboarding clients — 28-day cycle</p>
        </div>

        <div className="divide-y divide-border">
          {withCycle.map(c => {
            const stateColor = STATE_COLORS[c.state] || 'bg-gray-100 text-gray-600';
            const isRenewingSoon = c.daysUntilNext <= 7;
            const progress = Math.min(100, Math.max(0, (c.daysIntoCycle / 28) * 100));

            return (
              <div key={c.id} className="px-4 py-3 flex flex-col sm:flex-row sm:items-center gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-medium text-sm text-foreground">{c.name}</span>
                    {c.state && (
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${stateColor}`}>{c.state}</span>
                    )}
                    {c.package && (
                      <span className="text-xs px-2 py-0.5 rounded-full bg-secondary text-muted-foreground border border-border">{c.package}</span>
                    )}
                    {isRenewingSoon && (
                      <span className="text-xs px-2 py-0.5 rounded-full bg-orange-100 text-orange-700 font-medium">Renews in {c.daysUntilNext}d</span>
                    )}
                  </div>
                  {/* Cycle progress bar */}
                  <div className="mt-2 flex items-center gap-2">
                    <div className="flex-1 h-1.5 bg-border rounded-full overflow-hidden">
                      <div className="h-full bg-accent rounded-full transition-all" style={{ width: `${progress}%` }} />
                    </div>
                    <span className="text-xs text-muted-foreground whitespace-nowrap">Day {c.daysIntoCycle + 1}/28</span>
                  </div>
                </div>

                <div className="flex items-center gap-6 shrink-0 text-xs">
                  <div>
                    <div className="text-muted-foreground mb-0.5">Cycle Start</div>
                    <div className="font-semibold text-foreground">{c.cycle_start_date}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground mb-0.5">Current Cycle</div>
                    <div className="font-semibold text-foreground">{c.cycleStartStr}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground mb-0.5">Next Cycle</div>
                    <div className={`font-semibold ${isRenewingSoon ? 'text-orange-600' : 'text-foreground'}`}>{c.nextCycleStart}</div>
                  </div>
                </div>
              </div>
            );
          })}

          {withCycle.length === 0 && (
            <div className="px-4 py-8 text-center text-sm text-muted-foreground">
              No active clients with cycle start dates set.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value, warn }) {
  return (
    <div className={`rounded-xl border px-4 py-3 ${warn && value > 0 ? 'bg-amber-50 border-amber-200' : 'bg-card border-border'}`}>
      <div className={`text-2xl font-bold font-dm ${warn && value > 0 ? 'text-amber-700' : 'text-foreground'}`}>{value}</div>
      <div className="text-xs text-muted-foreground mt-0.5">{label}</div>
    </div>
  );
}