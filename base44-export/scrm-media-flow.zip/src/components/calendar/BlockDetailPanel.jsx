import { useState, useEffect } from 'react';
import { X, Save, Trash2, Star } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { ROLE_FOR_BLOCK } from '@/lib/calendarBlocks';

export default function BlockDetailPanel({ block, clientsMap, employeesMap, onClose, onSave, onDelete }) {
  const [form, setForm] = useState({ ...block });
  const [employees, setEmployees] = useState([]);
  const [saving, setSaving] = useState(false);
  const [savingPermanent, setSavingPermanent] = useState(false);

  useEffect(() => {
    base44.entities.Employee.list().then(setEmployees);
  }, []);

  const requiredRole = ROLE_FOR_BLOCK[block.block_type];
  const eligibleEmployees = employees.filter(e => !requiredRole || e.role === requiredRole);
  const client = clientsMap[block.client];

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    await onSave({ ...form, is_unassigned: !form.employee });
    setSaving(false);
  };

  const handleSavePermanent = async () => {
    setSavingPermanent(true);
    // Save for this block
    await onSave({ ...form, is_unassigned: !form.employee });
    // Also upsert a ClientBlockAssignment
    if (form.employee) {
      const existing = await base44.entities.ClientBlockAssignment.filter({
        client: block.client,
        block_type: block.block_type,
      });
      if (existing.length > 0) {
        await base44.entities.ClientBlockAssignment.update(existing[0].id, { employee: form.employee });
      } else {
        await base44.entities.ClientBlockAssignment.create({
          client: block.client,
          block_type: block.block_type,
          employee: form.employee,
        });
      }
    }
    setSavingPermanent(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
      <div className="bg-card rounded-2xl border border-border shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <div>
            <h2 className="font-dm font-bold text-foreground">{block.block_type}</h2>
            <p className="text-xs text-muted-foreground mt-0.5">{client?.name} · {block.date}</p>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X size={18} /></button>
        </div>

        <form onSubmit={handleSave} className="px-6 py-5 space-y-4">
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">
              Assign Employee {requiredRole && <span className="opacity-60">({requiredRole})</span>}
            </label>
            <select
              value={form.employee || ''}
              onChange={e => setForm(f => ({ ...f, employee: e.target.value }))}
              className="input-base"
            >
              <option value="">Unassigned</option>
              {eligibleEmployees.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Date</label>
              <input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
                className="input-base" />
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Start Time</label>
              <input type="time" value={form.start_time || '09:00'} onChange={e => setForm(f => ({ ...f, start_time: e.target.value }))}
                className="input-base" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Duration (minutes)</label>
            <input type="number" value={form.duration_minutes || 60} onChange={e => setForm(f => ({ ...f, duration_minutes: parseInt(e.target.value) || 60 }))}
              className="input-base" min="5" />
          </div>

          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Notes</label>
            <textarea value={form.notes || ''} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
              className="input-base resize-none h-20" placeholder="Optional notes..." />
          </div>

          <div className="flex gap-2 pt-1">
            <button type="button" onClick={() => onDelete(block.id)}
              className="p-2.5 border border-border rounded-lg text-muted-foreground hover:text-destructive hover:border-destructive/40 transition-colors">
              <Trash2 size={15} />
            </button>
            <button type="submit" disabled={saving}
              className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 border border-border rounded-lg text-sm font-medium text-foreground hover:bg-secondary transition-colors disabled:opacity-50">
              <Save size={14} /> {saving ? 'Saving...' : 'Save'}
            </button>
            <button type="button" disabled={savingPermanent || !form.employee} onClick={handleSavePermanent}
              className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accent/90 disabled:opacity-50 transition-colors">
              <Star size={14} /> {savingPermanent ? 'Saving...' : 'Save Permanently'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}