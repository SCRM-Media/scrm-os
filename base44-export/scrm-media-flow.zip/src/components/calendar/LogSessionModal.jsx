import { useState } from 'react';
import { X } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function LogSessionModal({ client, defaultDate, defaultSessionType, employees, onClose, onSaved }) {
  const [form, setForm] = useState({
    session_date: defaultDate || new Date().toISOString().split('T')[0],
    session_type: defaultSessionType || 'CarBee',
    filmer_employee: '',
    cars_filmed: '',
    stock_numbers: '',
    google_sheet_updated: false,
    upload_destination_link: '',
    session_notes: '',
  });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    const session = await base44.entities.InventorySession.create({
      client: client.id,
      session_date: form.session_date,
      session_type: form.session_type,
      filmer_employee: form.filmer_employee || null,
      cars_filmed: Number(form.cars_filmed) || 0,
      stock_numbers: form.stock_numbers || '',
      google_sheet_updated: form.google_sheet_updated,
      upload_destination_link: form.upload_destination_link || '',
      session_notes: form.session_notes || '',
      edit_task_created: false,
    });

    // Auto-create edit task for Style 2 video sessions
    if (form.session_type === 'Inventory Video Style 2' && Number(form.cars_filmed) > 0) {
      const videoCount = Number(form.cars_filmed);
      const dueDate = new Date(form.session_date);
      dueDate.setDate(dueDate.getDate() + 1);
      await base44.entities.InventoryEditTask.create({
        client: client.id,
        inventory_session: session.id,
        session_date: form.session_date,
        video_count: videoCount,
        estimated_minutes: videoCount * 20,
        status: 'Not Started',
        due_date: dueDate.toISOString().split('T')[0],
      });
      await base44.entities.InventorySession.update(session.id, { edit_task_created: true });
    }

    setSaving(false);
    onSaved();
  };

  const SESSION_TYPES = ['CarBee', 'Inventory Photography', 'Inventory Video Style 1', 'Inventory Video Style 2'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
      <div className="bg-card border border-border rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border sticky top-0 bg-card z-10">
          <h2 className="font-dm font-bold text-foreground">Log Session — {client.name}</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X size={18} /></button>
        </div>

        <div className="px-6 py-5 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Date</label>
              <input type="date" value={form.session_date}
                onChange={e => setForm(f => ({ ...f, session_date: e.target.value }))}
                className="input-base" />
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Session Type</label>
              <select value={form.session_type}
                onChange={e => setForm(f => ({ ...f, session_type: e.target.value }))}
                className="input-base">
                {SESSION_TYPES.map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Filmer</label>
              <select value={form.filmer_employee}
                onChange={e => setForm(f => ({ ...f, filmer_employee: e.target.value }))}
                className="input-base">
                <option value="">— None —</option>
                {employees.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Cars Filmed</label>
              <input type="number" value={form.cars_filmed}
                onChange={e => setForm(f => ({ ...f, cars_filmed: e.target.value }))}
                className="input-base" placeholder="0" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Stock / Rego Numbers</label>
            <input type="text" value={form.stock_numbers}
              onChange={e => setForm(f => ({ ...f, stock_numbers: e.target.value }))}
              className="input-base" placeholder="Comma separated..." />
          </div>

          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Upload Destination Link</label>
            <input type="url" value={form.upload_destination_link}
              onChange={e => setForm(f => ({ ...f, upload_destination_link: e.target.value }))}
              className="input-base" placeholder="https://..." />
          </div>

          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Notes</label>
            <textarea value={form.session_notes}
              onChange={e => setForm(f => ({ ...f, session_notes: e.target.value }))}
              className="input-base resize-none h-16" placeholder="Any session notes..." />
          </div>

          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" checked={form.google_sheet_updated}
              onChange={e => setForm(f => ({ ...f, google_sheet_updated: e.target.checked }))}
              className="w-4 h-4 rounded" />
            <span className="text-sm text-foreground">Google Sheet updated</span>
          </label>

          {form.session_type === 'Inventory Video Style 2' && Number(form.cars_filmed) > 0 && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg px-4 py-3 text-xs text-yellow-800">
              An edit task will be auto-created for <strong>{form.cars_filmed} videos</strong> (~{Number(form.cars_filmed) * 20}min), due tomorrow.
            </div>
          )}

          <div className="flex gap-3 pt-1">
            <button onClick={onClose} className="flex-1 px-4 py-2.5 border border-border rounded-lg text-sm font-medium text-muted-foreground hover:bg-secondary transition-colors">
              Cancel
            </button>
            <button onClick={handleSave} disabled={saving}
              className="flex-1 px-4 py-2.5 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accent/90 transition-colors disabled:opacity-50">
              {saving ? 'Saving...' : 'Log Session'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}