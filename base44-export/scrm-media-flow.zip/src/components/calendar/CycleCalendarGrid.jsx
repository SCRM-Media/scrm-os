import { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { dateToStr, getCurrentCycleStart, addDays } from '@/lib/cycleEngine';

const DAY_LABELS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

const STATE_COLORS = {
  VIC: 'bg-blue-100 text-blue-700 border-blue-200',
  NSW: 'bg-purple-100 text-purple-700 border-purple-200',
  QLD: 'bg-orange-100 text-orange-700 border-orange-200',
  WA: 'bg-teal-100 text-teal-700 border-teal-200',
  SA: 'bg-pink-100 text-pink-700 border-pink-200',
  TAS: 'bg-indigo-100 text-indigo-700 border-indigo-200',
  NT: 'bg-amber-100 text-amber-700 border-amber-200',
  ACT: 'bg-green-100 text-green-700 border-green-200',
};

function getMondayOfWeek(date) {
  const d = new Date(date);
  const dow = d.getDay();
  const daysToMon = dow === 0 ? 6 : dow - 1;
  d.setDate(d.getDate() - daysToMon);
  d.setHours(0, 0, 0, 0);
  return d;
}

function get4WeekGrid(baseMonday) {
  return Array.from({ length: 4 }, (_, week) =>
    Array.from({ length: 7 }, (_, day) => {
      const d = new Date(baseMonday);
      d.setDate(baseMonday.getDate() + week * 7 + day);
      return d;
    })
  );
}

export default function CycleCalendarGrid({ clients }) {
  const [baseMonday, setBaseMonday] = useState(() => getMondayOfWeek(new Date()));
  const today = dateToStr(new Date());

  const weeks = get4WeekGrid(baseMonday);
  const startDate = dateToStr(weeks[0][0]);
  const endDate = dateToStr(weeks[3][6]);

  const navLabel = `${weeks[0][0].toLocaleDateString('en-AU', { day: 'numeric', month: 'short' })} – ${weeks[3][6].toLocaleDateString('en-AU', { day: 'numeric', month: 'short', year: 'numeric' })}`;

  const prev = () => { const d = new Date(baseMonday); d.setDate(d.getDate() - 28); setBaseMonday(d); };
  const next = () => { const d = new Date(baseMonday); d.setDate(d.getDate() + 28); setBaseMonday(d); };
  const goToday = () => setBaseMonday(getMondayOfWeek(new Date()));

  // Build a map: dateStr -> list of clients whose cycle starts on that date (current cycle)
  const cycleStartsByDate = {};
  clients
    .filter(c => (c.status === 'Active' || c.status === 'Onboarding') && c.cycle_start_date)
    .forEach(c => {
      // Find all cycle starts within the visible range
      let cycleStart = getCurrentCycleStart(c.cycle_start_date);
      // Walk back until before startDate
      while (dateToStr(cycleStart) > startDate) {
        cycleStart = addDays(cycleStart, -28);
      }
      // Walk forward and collect any that fall in range
      while (true) {
        const str = dateToStr(cycleStart);
        if (str > endDate) break;
        if (str >= startDate) {
          if (!cycleStartsByDate[str]) cycleStartsByDate[str] = [];
          cycleStartsByDate[str].push(c);
        }
        cycleStart = addDays(cycleStart, 28);
      }
    });

  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden shadow-sm">
      {/* Header */}
      <div className="px-4 py-3 border-b border-border flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h3 className="text-sm font-semibold text-foreground">4-Week Cycle Calendar</h3>
          <p className="text-xs text-muted-foreground mt-0.5">Dots show when each client's 28-day cycle begins</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={prev} className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground transition-colors"><ChevronLeft size={16} /></button>
          <span className="text-sm font-medium text-foreground min-w-48 text-center">{navLabel}</span>
          <button onClick={next} className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground transition-colors"><ChevronRight size={16} /></button>
          <button onClick={goToday} className="text-xs px-2.5 py-1.5 border border-border rounded-lg text-muted-foreground hover:bg-secondary transition-colors">Today</button>
        </div>
      </div>

      {/* Day headers */}
      <div className="grid grid-cols-7 border-b border-border bg-secondary/20">
        {DAY_LABELS.map(d => (
          <div key={d} className="text-center text-xs font-medium text-muted-foreground py-2">{d}</div>
        ))}
      </div>

      {/* Weeks */}
      {weeks.map((week, wi) => (
        <div key={wi} className="grid grid-cols-7 border-b border-border/50 last:border-b-0">
          {week.map((date, di) => {
            const key = dateToStr(date);
            const isToday = key === today;
            const cycleClients = cycleStartsByDate[key] || [];
            const isMonday = di === 0;

            return (
              <div
                key={di}
                className={`min-h-[80px] p-1.5 border-r border-border/30 last:border-r-0
                  ${isToday ? 'bg-accent/5' : ''}
                  ${cycleClients.length > 0 ? 'bg-green-50/50' : ''}`}
              >
                {/* Date number */}
                <div className={`text-xs font-medium w-6 h-6 flex items-center justify-center rounded-full mb-1
                  ${isToday ? 'bg-accent text-white' : 'text-muted-foreground'}`}>
                  {date.getDate()}
                </div>

                {/* Cycle start chips */}
                <div className="space-y-0.5">
                  {cycleClients.map(c => {
                    const colors = STATE_COLORS[c.state] || 'bg-gray-100 text-gray-700 border-gray-200';
                    return (
                      <div key={c.id} className={`rounded px-1.5 py-0.5 text-xs font-medium border truncate leading-tight ${colors}`}
                        title={`${c.name} — cycle starts`}>
                        {c.name}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}