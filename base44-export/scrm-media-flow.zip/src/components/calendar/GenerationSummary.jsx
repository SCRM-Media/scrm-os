import { useState } from 'react';
import { CheckCircle, AlertTriangle, ChevronDown, ChevronUp } from 'lucide-react';

export default function GenerationSummary({ results, onClose }) {
  const [expanded, setExpanded] = useState(null);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-card rounded-2xl border border-border shadow-2xl w-full max-w-2xl max-h-[85vh] flex flex-col">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <h2 className="font-dm font-bold text-foreground">Generation Summary</h2>
          <button onClick={onClose} className="text-sm text-muted-foreground hover:text-foreground px-3 py-1.5 border border-border rounded-lg">Close</button>
        </div>

        <div className="overflow-y-auto flex-1 p-6 space-y-3">
          {results.map((r, i) => {
            const isOk = r.status === 'ok';
            const isErr = r.status === 'error';
            const isMismatch = r.status === 'mismatch';
            const isExpanded = expanded === i;

            return (
              <div key={i} className={`rounded-xl border overflow-hidden ${isMismatch || isErr ? 'border-red-300 bg-red-50' : 'border-border bg-card'}`}>
                <div
                  className="flex items-center justify-between px-4 py-3 cursor-pointer hover:bg-secondary/30"
                  onClick={() => setExpanded(isExpanded ? null : i)}
                >
                  <div className="flex items-center gap-3">
                    {isOk ? <CheckCircle size={16} className="text-green-600 shrink-0" /> : <AlertTriangle size={16} className="text-red-600 shrink-0" />}
                    <div>
                      <div className="font-medium text-sm text-foreground">{r.clientName}</div>
                      <div className="text-xs text-muted-foreground">
                        {r.packageName} · cycle from {r.cycleStart} · {r.blocksCreated} blocks created
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {isMismatch && (
                      <span className="text-xs font-medium text-red-700 bg-red-100 px-2 py-0.5 rounded-full">Count mismatch</span>
                    )}
                    {isErr && (
                      <span className="text-xs font-medium text-red-700 bg-red-100 px-2 py-0.5 rounded-full">Error</span>
                    )}
                    {isExpanded ? <ChevronUp size={14} className="text-muted-foreground" /> : <ChevronDown size={14} className="text-muted-foreground" />}
                  </div>
                </div>

                {isExpanded && (
                  <div className="border-t border-border px-4 pb-4 pt-3">
                    {isErr && <p className="text-xs text-red-700 mb-2">{r.error}</p>}
                    {r.breakdown && (
                      <table className="w-full text-xs">
                        <thead>
                          <tr className="text-muted-foreground border-b border-border">
                            <th className="text-left py-1 font-medium">Block Type</th>
                            <th className="text-right py-1 font-medium">Expected</th>
                            <th className="text-right py-1 font-medium">Created</th>
                            <th className="text-right py-1 font-medium">Status</th>
                          </tr>
                        </thead>
                        <tbody>
                          {Object.entries(r.breakdown).map(([bt, counts]) => {
                            const ok = counts.created === counts.expected;
                            return (
                              <tr key={bt} className={`border-b border-border/50 ${!ok ? 'bg-red-50' : ''}`}>
                                <td className="py-1.5 text-foreground">{bt}</td>
                                <td className="py-1.5 text-right text-muted-foreground">{counts.expected}</td>
                                <td className="py-1.5 text-right font-medium text-foreground">{counts.created}</td>
                                <td className="py-1.5 text-right">
                                  {ok
                                    ? <span className="text-green-600">✓</span>
                                    : <span className="text-red-600 font-bold">✗</span>
                                  }
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}