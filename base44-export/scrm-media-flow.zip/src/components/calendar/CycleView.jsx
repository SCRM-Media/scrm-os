import { useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { addDays, dateToStr, parseDate } from '@/lib/cycleEngine';

const DAY_LABELS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

function getCycleStartsInWindow(clients, windowStart, windowEnd) {
  // Returns array of { date, client } for all cycle starts within the window
  const results = [];
  clients.forEach(client => {
    if (!client.cycle_start_date) return;
    const anchor = parseDate(client.cycle_start_date);
    // Find first cycle in/before windowStart
    const diffMs = parseDate(windowStart) - anchor;
    const daysElapsed = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    let cycleNum = Math.max(0, Math.floor(daysElapsed / 28));

    // Walk backward one in case we're mid-cycle
    if (cycleNum > 0) cycleNum--;

    while (true) {
      const cs = dateToStr(addDays(anchor, cycleNum * 28));
      if (cs > windowEnd) break;
      if (cs >= windowStart) {
        results.push({ date: cs, client });
      }
      cycleNum++;
    }
  });
  return results;
}

function getWindowDates(baseMonday) {
  // 4 weeks = 28 days from base Monday
  return Array.from({ length: 28 }, (_, i) => addDays(baseMonday, i));
}

function getThisMonday(base) {
  const d = new Date(base);
  const dow = d.getDay();
  const daysToMon = dow === 0 ? 6 : dow - 1;
  d.setDate(d.getDate() - daysToMon);
  d.setHours(0, 0, 0, 0);
  return d;
}

// Pick a distinct, readable color per client (cycles through palette)
const PALETTE = [
  'bg-blue-100 text-blue-800 border-blue-200',
  'bg-purple-100 text-purple-800 border-purple-200',
  'bg-green-100 text-green-800 border-green-200',
  'bg-orange-100 text-orange-800 border-orange-200',
  'bg-pink-100 text-pink-800 border-pink-200',
  'bg-teal-100 text-teal-800 border-teal-200',
  'bg-indigo-100 text-indigo-800 border-indigo-200',
  'bg-amber-100 text-amber-800 border-amber-200',
  'bg-red-100 text-red-800 border-red-200',
  'bg-cyan-100 text-cyan-800 border-cyan-200',
];

export default function CycleView({ clients }) {
  const [baseMonday, setBaseMonday] = useState(() => getThisMonday(new Date()));

  const windowDates = useMemo(() => getWindowDates(baseMonday), [baseMonday]);
  const windowStart = dateToStr(windowDates[0]);
  const windowEnd = dateToStr(windowDates[27]);
  const todayStr = dateToStr(new Date());

  // Assign a stable color per client id
  const clientColorMap = useMemo(() => {
    const map = {};
    const sorted = [...clients].sort((a, b) => a.id.localeCompare(b.id));
    sorted.forEach((c, i) => { map[c.id] = PALETTE[i % PALETTE.length]; });
    return map;
  }, [clients]);

  const cycleStarts = useMemo(() =>
    getCycleStartsInWindow(clients, windowStart, windowEnd),
    [clients, windowStart, windowEnd]
  );

  // Group by date
  const byDate = useMemo(() => {
    const map = {};
    cycleStarts.forEach(({ date, client }) => {
      if (!map[date]) map[date] = [];
      map[date].push(client);
    });
    return map;
  }, [cycleStarts]);

  // 4 rows of 7 days
  const weeks = [0, 1, 2, 3].map(w => windowDates.slice(w * 7, w * 7 + 7));

  const labelStart = windowDates[0].toLocaleDateString('en-AU', { day: 'numeric', month: 'short' });
  const labelEnd = windowDates[27].toLocaleDateString('en-AU', { day: 'numeric', month: 'short', year: 'numeric' });

  return (
    <div className="space-y-4">
      {/* Nav */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="flex items-center gap-1 bg-card border border-border rounded-lg px-1 py-1">
          <button onClick={() => setBaseMonday(d => addDays(d, -28))} className="p-1.5 rounded hover:bg-secondary text-muted-foreground transition-colors">
            <ChevronLeft size={16} />
          </button>
          <span className="text-sm font-medium text-foreground px-2 whitespace-nowrap">
            {labelStart} – {labelEnd}
          </span>
          <button onClick={() => setBaseMonday(d => addDays(d, 28))} className="p-1.5 rounded hover:bg-secondary text-muted-foreground transition-colors">
            <ChevronRight size={16} />
          </button>
        </div>
        <button
          onClick={() => setBaseMonday(getThisMonday(new Date()))}
          className="px-3 py-2 text-sm border border-border rounded-lg bg-card hover:bg-secondary transition-colors text-muted-foreground"
        >
          Today
        </button>
        <span className="text-xs text-muted-foreground">
          {cycleStarts.length} cycle start{cycleStarts.length !== 1 ? 's' : ''} in this 4-week window
        </span>
      </div>

      {/* Grid */}
      <div className="bg-card border border-border rounded-xl overflow-hidden shadow-sm">
        {/* Day headers */}
        <div className="grid grid-cols-7 border-b border-border">
          {DAY_LABELS.map(d => (
            <div key={d} className="py-2 text-center text-xs font-medium text-muted-foreground border-r border-border/50 last:border-r-0">
              {d}
            </div>
          ))}
        </div>

        {/* 4 weeks */}
        {weeks.map((week, wi) => (
          <div key={wi} className="grid grid-cols-7 border-b border-border/50 last:border-b-0">
            {week.map((date, di) => {
              const ds = dateToStr(date);
              const isToday = ds === todayStr;
              const dayClients = byDate[ds] || [];
              return (
                <div
                  key={ds}
                  className={`min-h-[90px] p-1.5 border-r border-border/50 last:border-r-0 ${isToday ? 'bg-accent/5' : ''}`}
                >
                  <div className={`text-xs font-semibold w-6 h-6 flex items-center justify-center rounded-full mb-1 ${isToday ? 'bg-accent text-white' : 'text-foreground'}`}>
                    {date.getDate()}
                  </div>
                  <div className="space-y-1">
                    {dayClients.map(client => (
                      <div
                        key={client.id}
                        className={`text-[10px] font-medium px-1.5 py-1 rounded border truncate leading-tight ${clientColorMap[client.id]}`}
                        title={`${client.name} — Cycle Start`}
                      >
                        🔄 {client.name}
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        ))}
      </div>

      {/* Legend */}
      <div className="flex flex-wrap gap-2">
        {clients.filter(c => c.cycle_start_date).sort((a, b) => a.name.localeCompare(b.name)).map(client => (
          <div key={client.id} className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-xs font-medium ${clientColorMap[client.id]}`}>
            <span>{client.name}</span>
            <span className="opacity-60">· {client.cycle_start_date}</span>
          </div>
        ))}
        {clients.filter(c => !c.cycle_start_date).length > 0 && (
          <div className="text-xs text-muted-foreground self-center">
            {clients.filter(c => !c.cycle_start_date).length} client{clients.filter(c => !c.cycle_start_date).length !== 1 ? 's' : ''} with no cycle date set
          </div>
        )}
      </div>
    </div>
  );
}