import { useState, useMemo } from 'react';
import { packageColors } from '@/components/ui/StatusBadge';
import StatusBadge from '@/components/ui/StatusBadge';
import PageHeader from '@/components/ui/PageHeader';
import { ArrowUpDown } from 'lucide-react';

const CITIES = ['All Cities', 'Melbourne', 'Sydney', 'Brisbane', 'Perth', 'Newcastle'];
const healthDot = { Green: 'bg-green-500', Amber: 'bg-amber-400', Red: 'bg-red-500' };

export default function ClientSelector({ clients, onSelect }) {
  const [city, setCity] = useState('All Cities');
  const [sortAZ, setSortAZ] = useState(true);

  const active = clients.filter(c => ['Active', 'Onboarding'].includes(c.status) && c.package);

  const filtered = useMemo(() => {
    let list = city === 'All Cities'
      ? active
      : active.filter(c => {
          const loc = (c.location || c.address || c.state || '').toLowerCase();
          return loc.includes(city.toLowerCase());
        });
    list = [...list].sort((a, b) => {
      const cmp = a.name.localeCompare(b.name);
      return sortAZ ? cmp : -cmp;
    });
    return list;
  }, [active, city, sortAZ]);

  return (
    <div className="p-4 lg:p-8 max-w-5xl mx-auto">
      <PageHeader title="Social Calendar" subtitle="Select a client to manage their content" />

      {/* Filters row */}
      <div className="flex items-center gap-3 mb-5 flex-wrap">
        <select
          value={city}
          onChange={e => setCity(e.target.value)}
          className="text-sm border border-border rounded-lg px-3 py-2 bg-card text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
        >
          {CITIES.map(c => <option key={c}>{c}</option>)}
        </select>
        <button
          onClick={() => setSortAZ(v => !v)}
          className="flex items-center gap-1.5 text-sm border border-border rounded-lg px-3 py-2 bg-card text-foreground hover:bg-secondary transition-colors"
        >
          <ArrowUpDown size={14} />
          {sortAZ ? 'A → Z' : 'Z → A'}
        </button>
        {city !== 'All Cities' && (
          <span className="text-xs text-muted-foreground">{filtered.length} client{filtered.length !== 1 ? 's' : ''}</span>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(client => (
          <button
            key={client.id}
            onClick={() => onSelect(client)}
            className="text-left bg-card rounded-xl border border-border p-5 shadow-sm hover:shadow-md hover:border-accent/40 active:scale-[0.98] transition-all group"
          >
            <div className="flex items-start justify-between mb-3">
              <span className="font-dm font-bold text-foreground text-lg leading-tight">{client.name}</span>
              <div className={`w-3 h-3 rounded-full shrink-0 mt-1 ${healthDot[client.account_health] || 'bg-green-500'}`} title={`Health: ${client.account_health}`} />
            </div>
            <div className="flex flex-wrap gap-1.5 mb-3">
              <StatusBadge label={client.package || 'Minimum'} colorMap={packageColors} />
            </div>
            <div className="text-xs text-muted-foreground space-y-0.5">
              {client.filming_cadence && <div>📹 {client.filming_cadence} filming</div>}
              {client.location && <div>📍 {client.location}</div>}
            </div>
          </button>
        ))}
        {filtered.length === 0 && (
          <div className="col-span-3 py-16 text-center text-muted-foreground text-sm">
            {city !== 'All Cities' ? `No clients in ${city}.` : 'No active clients found.'}
          </div>
        )}
      </div>
    </div>
  );
}