import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Calendar, Edit2, Plus } from 'lucide-react';

const statusPill = {
  'Scheduled': 'bg-blue-100 text-blue-700',
  'Completed': 'bg-green-100 text-green-700',
  'Cancelled': 'bg-gray-100 text-gray-600',
};

function formatMeetingDate(dateStr) {
  if (!dateStr) return null;
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('en-AU', { weekday: 'long', day: 'numeric', month: 'long' });
}

function monthLabel(monthStr) {
  const [y, m] = monthStr.split('-');
  return new Date(parseInt(y), parseInt(m) - 1).toLocaleDateString('en-AU', { month: 'long', year: 'numeric' });
}

export default function PlanningMeetingSection({ meeting, client, currentMonth, onUpdate }) {
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState(
    meeting
      ? { meeting_date: meeting.meeting_date || '', status: meeting.status, notes: meeting.notes || '' }
      : { meeting_date: '', status: 'Scheduled', notes: '' }
  );
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSave = async () => {
    if (meeting) {
      await base44.entities.PlanningMeeting.update(meeting.id, form);
    } else {
      await base44.entities.PlanningMeeting.create({ client: client.id, month: currentMonth, ...form });
    }
    setEditing(false);
    onUpdate();
  };

  return (
    <section>
      <div className="flex items-center gap-2 mb-3">
        <Calendar size={16} className="text-accent" />
        <h2 className="font-dm font-semibold text-foreground">Monthly Planning Meeting</h2>
        <span className="text-xs text-muted-foreground">— {monthLabel(currentMonth)}</span>
      </div>

      {!meeting && !editing ? (
        <div className="border-2 border-dashed border-border rounded-xl p-6 text-center">
          <p className="text-sm text-muted-foreground mb-3">No planning meeting set for {monthLabel(currentMonth)}</p>
          <button onClick={() => setEditing(true)}
            className="inline-flex items-center gap-2 bg-accent text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-accent/90 transition-colors">
            <Plus size={14} /> Schedule Meeting
          </button>
        </div>
      ) : editing ? (
        <div className="bg-card rounded-xl border border-border p-5 space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1">Meeting Date</label>
              <input type="date" value={form.meeting_date} onChange={e => set('meeting_date', e.target.value)} className="input-base" />
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1">Status</label>
              <select value={form.status} onChange={e => set('status', e.target.value)} className="input-base">
                {['Scheduled', 'Completed', 'Cancelled'].map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1">Meeting Notes / Brief</label>
            <textarea value={form.notes} onChange={e => set('notes', e.target.value)}
              className="input-base resize-none h-32" placeholder="Content agreed for this month, key themes, vehicles to feature, special events..." />
          </div>
          <div className="flex gap-2">
            <button onClick={handleSave} className="px-4 py-2 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accent/90 transition-colors">Save</button>
            <button onClick={() => setEditing(false)} className="px-4 py-2 border border-border rounded-lg text-sm text-muted-foreground hover:bg-secondary transition-colors">Cancel</button>
          </div>
        </div>
      ) : (
        <div className="bg-card rounded-xl border border-border p-5">
          <div className="flex items-start justify-between gap-3 mb-3">
            <div className="flex items-center gap-3 flex-wrap">
              {meeting.meeting_date && (
                <span className="text-sm font-medium text-foreground">{formatMeetingDate(meeting.meeting_date)}</span>
              )}
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusPill[meeting.status] || statusPill.Scheduled}`}>
                {meeting.status}
              </span>
            </div>
            <button onClick={() => { setForm({ meeting_date: meeting.meeting_date || '', status: meeting.status, notes: meeting.notes || '' }); setEditing(true); }}
              className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors shrink-0">
              <Edit2 size={14} />
            </button>
          </div>
          {meeting.notes
            ? <p className="text-sm text-foreground leading-relaxed whitespace-pre-line">{meeting.notes}</p>
            : <p className="text-sm text-muted-foreground italic">No notes recorded yet. Click edit to add the brief.</p>
          }
        </div>
      )}
    </section>
  );
}