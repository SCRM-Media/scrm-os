import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, ExternalLink, List, LayoutGrid, RefreshCw } from 'lucide-react';
import ContentItemDetailModal from '@/components/social/ContentItemDetailModal';
import QuickAddModal from '@/components/social/QuickAddModal';
import ContentCountBadges from '@/components/social/ContentCountBadges';
import { STATUSES, CAPTION_STATUSES, STATUS_COLORS, STATUS_HEADER, PACKAGE_TARGETS, getTypeBadgeClass, getFormat, isOverdue } from '@/lib/contentTypes';

const BOARD_STATUSES = ['Planned', 'Shoot Booked', 'Filmed', 'Editing', 'QC', 'Ready for Scheduling'];

function fmt(d) {
  if (!d) return '';
  return new Date(d + 'T00:00:00').toLocaleDateString('en-AU', { day: 'numeric', month: 'short' });
}

function MonthlyProgress({ items, clientPackage }) {
  const now = new Date();
  const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  const target = PACKAGE_TARGETS[clientPackage] || 12;
  const count = items.filter(i => i.scheduled_date && i.scheduled_date.startsWith(currentMonth)).length;
  const pct = Math.min((count / target) * 100, 100);

  // Warn if below target and < 2 weeks left in month
  const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
  const daysLeft = Math.ceil((lastDay - now) / (1000 * 60 * 60 * 24));
  const isWarning = count < target && daysLeft <= 14;
  const isDone = count >= target;

  return (
    <div className="mb-4 bg-card border border-border rounded-xl px-4 py-3">
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-medium text-foreground">{count} of {target} items this month</span>
        <span className={`text-xs font-semibold ${isDone ? 'text-green-600' : isWarning ? 'text-amber-600' : 'text-muted-foreground'}`}>
          {isDone ? '✓ Target met' : isWarning ? `${daysLeft}d left` : `${target - count} to go`}
        </span>
      </div>
      <div className="h-2 rounded-full bg-secondary overflow-hidden">
        <div
          className={`h-full rounded-full transition-all duration-500 ${isDone ? 'bg-green-500' : isWarning ? 'bg-amber-500' : 'bg-accent'}`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

export default function ContentTrackerBoard({ items, client, currentMonth, onUpdate }) {
  const [viewMode, setViewMode] = useState('board');
  const [selectedItem, setSelectedItem] = useState(null);
  const [quickAddStatus, setQuickAddStatus] = useState(null);
  const [expandedCaptionId, setExpandedCaptionId] = useState(null);
  const [captionDraft, setCaptionDraft] = useState('');

  const handleStatusChange = async (item, status) => {
    await base44.entities.ContentItem.update(item.id, { status });
    onUpdate();
  };

  const handleSaveCaption = async (item) => {
    await base44.entities.ContentItem.update(item.id, { caption: captionDraft });
    setExpandedCaptionId(null);
    onUpdate();
  };

  const sorted = [...items].sort((a, b) => {
    if (!a.scheduled_date) return 1;
    if (!b.scheduled_date) return -1;
    return a.scheduled_date.localeCompare(b.scheduled_date);
  });

  return (
    <section className="pb-8">
      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <span className="text-lg">📋</span>
          <h2 className="font-dm font-semibold text-foreground">Content Tracker</h2>
          <span className="text-xs text-muted-foreground">({items.length} items)</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex rounded-lg border border-border overflow-hidden text-xs">
            <button onClick={() => setViewMode('board')} className={`px-3 py-1.5 flex items-center gap-1 font-medium transition-colors ${viewMode === 'board' ? 'bg-primary text-primary-foreground' : 'bg-card text-muted-foreground hover:bg-secondary'}`}>
              <LayoutGrid size={12} /> Board
            </button>
            <button onClick={() => setViewMode('list')} className={`px-3 py-1.5 flex items-center gap-1 font-medium transition-colors ${viewMode === 'list' ? 'bg-primary text-primary-foreground' : 'bg-card text-muted-foreground hover:bg-secondary'}`}>
              <List size={12} /> List
            </button>
          </div>
          <button onClick={() => setQuickAddStatus('Planned')}
            className="flex items-center gap-1.5 bg-accent text-white px-3 py-1.5 rounded-lg text-sm font-medium hover:bg-accent/90 transition-colors">
            <Plus size={14} /> Add Content
          </button>
        </div>
      </div>

      <ContentCountBadges items={items} client={client} currentMonth={currentMonth || `${new Date().getFullYear()}-${String(new Date().getMonth()+1).padStart(2,'0')}`} />
      <MonthlyProgress items={items} clientPackage={client.package} />

      {viewMode === 'board' ? (
        <div className="overflow-x-auto -mx-4 px-4 lg:mx-0 lg:px-0">
          <div className="flex gap-4 min-w-max pb-2">
            {BOARD_STATUSES.map(status => {
              const colItems = items.filter(i => i.status === status);
              return (
                <div key={status} className={`w-64 shrink-0 rounded-xl border p-3 ${STATUS_COLORS[status] || 'bg-secondary/30 border-border'}`}>
                  <div className="flex items-center justify-between mb-3">
                    <span className={`font-dm font-semibold text-sm ${STATUS_HEADER[status]}`}>{status}</span>
                    <div className="flex items-center gap-1">
                      <span className="text-xs text-muted-foreground">{colItems.length}</span>
                      <button onClick={() => setQuickAddStatus(status)}
                        className="w-5 h-5 rounded flex items-center justify-center bg-white/60 border border-border text-muted-foreground hover:text-accent hover:border-accent transition-colors">
                        <Plus size={11} />
                      </button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    {colItems.length === 0 && (
                      <div className="text-xs text-muted-foreground/60 text-center py-4">Empty</div>
                    )}
                    {colItems.map(item => {
                      const overdue = isOverdue(item);
                      return (
                        <button key={item.id} onClick={() => setSelectedItem(item)}
                          className={`w-full text-left bg-white rounded-lg border p-3 shadow-sm hover:shadow-md transition-all ${overdue ? 'border-red-300' : 'border-border/70'}`}>
                          <div className="flex items-center gap-1.5 mb-1.5 flex-wrap">
                            <span className={`text-xs px-1.5 py-0.5 rounded font-medium ${getTypeBadgeClass(item.content_type)}`}>{getFormat(item.content_type)}</span>
                            {item.is_recurring_instance && <RefreshCw size={10} className="text-purple-500" />}
                            {overdue && <span className="text-xs bg-red-100 text-red-700 px-1.5 py-0.5 rounded font-medium">Overdue</span>}
                          </div>
                          <div className="text-xs text-muted-foreground mb-0.5">{item.content_type}</div>
                          <div className="text-sm font-medium text-foreground leading-tight mb-1">{item.title}</div>
                          {item.scheduled_date && <div className="text-xs text-muted-foreground">{fmt(item.scheduled_date)}</div>}
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
          {sorted.length === 0 && <div className="py-12 text-center text-sm text-muted-foreground">No content items yet.</div>}
          {sorted.map(item => {
            const overdue = isOverdue(item);
            return (
              <div key={item.id} className={`border-b border-border last:border-0 ${overdue ? 'bg-red-50/30' : ''}`}>
                <div className="px-4 py-3 flex items-center gap-3 hover:bg-secondary/20 transition-colors cursor-pointer" onClick={() => setSelectedItem(item)}>
                  <span className={`text-xs px-1.5 py-0.5 rounded font-medium shrink-0 ${getTypeBadgeClass(item.content_type)}`}>{getFormat(item.content_type)}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="font-medium text-sm text-foreground truncate">{item.title}</span>
                      {item.is_recurring_instance && <RefreshCw size={10} className="text-purple-500 shrink-0" />}
                      {overdue && <span className="text-xs bg-red-100 text-red-700 px-1 py-0.5 rounded shrink-0">Overdue</span>}
                    </div>
                    <span className="text-xs text-muted-foreground">{item.content_type}{item.scheduled_date ? ` · ${fmt(item.scheduled_date)}` : ''}</span>
                  </div>
                  <select
                    value={item.status}
                    onChange={e => { e.stopPropagation(); handleStatusChange(item, e.target.value); }}
                    onClick={e => e.stopPropagation()}
                    className="text-xs border border-border rounded-lg px-2 py-1.5 bg-card focus:outline-none focus:ring-1 focus:ring-ring shrink-0"
                  >
                    {STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                  {item.drive_folder_link && (
                    <a href={item.drive_folder_link} target="_blank" rel="noreferrer" className="text-accent shrink-0" onClick={e => e.stopPropagation()}>
                      <ExternalLink size={14} />
                    </a>
                  )}
                </div>
                {CAPTION_STATUSES.includes(item.status) && (
                  <div className="px-4 pb-3">
                    {expandedCaptionId === item.id ? (
                      <div className="space-y-1.5">
                        <textarea value={captionDraft} onChange={e => setCaptionDraft(e.target.value)}
                          className="input-base text-xs resize-none h-20" placeholder="Caption..." autoFocus />
                        <div className="flex gap-2">
                          <button onClick={() => handleSaveCaption(item)} className="text-xs px-3 py-1 bg-accent text-white rounded-lg hover:bg-accent/90">Save</button>
                          <button onClick={() => setExpandedCaptionId(null)} className="text-xs px-3 py-1 border border-border rounded-lg text-muted-foreground">Cancel</button>
                        </div>
                      </div>
                    ) : (
                      <div onClick={() => { setExpandedCaptionId(item.id); setCaptionDraft(item.caption || ''); }}
                        className="text-xs text-muted-foreground bg-secondary/40 rounded-lg px-3 py-2 cursor-pointer hover:bg-secondary transition-colors">
                        {item.caption ? <span className="text-foreground">{item.caption}</span> : <span className="italic">+ Add caption</span>}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {selectedItem && (
        <ContentItemDetailModal
          item={selectedItem}
          client={client}
          onClose={() => setSelectedItem(null)}
          onUpdate={() => { setSelectedItem(null); onUpdate(); }}
        />
      )}

      {quickAddStatus && (
        <QuickAddModal
          client={client}
          defaultStatus={quickAddStatus}
          onSave={async (data) => { await base44.entities.ContentItem.create(data); setQuickAddStatus(null); onUpdate(); }}
          onClose={() => setQuickAddStatus(null)}
        />
      )}
    </section>
  );
}