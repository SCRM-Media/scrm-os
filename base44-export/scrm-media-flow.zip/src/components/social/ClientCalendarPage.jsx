import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { ArrowLeft } from 'lucide-react';
import StatusBadge, { packageColors } from '@/components/ui/StatusBadge';
import PlanningMeetingSection from '@/components/social/PlanningMeetingSection';
import PreviousMeetingsArchive from '@/components/social/PreviousMeetingsArchive';
import MonthlySuggestionsPrompt from '@/components/social/MonthlySuggestionsPrompt';
import ShootChecklist from '@/components/social/ShootChecklist';
import ContentCalendarGrid from '@/components/social/ContentCalendarGrid';
import ContentTrackerBoard from '@/components/social/ContentTrackerBoard';
import ClientAboutTabs from '@/components/social/ClientAboutTabs';

export default function ClientCalendarPage({ client: initialClient, onBack }) {
  const [client, setClient] = useState(initialClient);
  const [items, setItems] = useState([]);
  const [meetings, setMeetings] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    Promise.all([
      base44.entities.ContentItem.filter({ client: client.id }),
      base44.entities.PlanningMeeting.filter({ client: client.id }),
    ]).then(([ci, m]) => {
      setItems(ci);
      setMeetings(m);
      setLoading(false);
    });
  };

  const reloadClient = async () => {
    const updated = await base44.entities.Client.filter({ id: client.id });
    if (updated && updated.length > 0) setClient(updated[0]);
  };

  useEffect(() => { load(); }, [client.id]);

  const now = new Date();
  const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  const currentMeeting = meetings.find(m => m.month === currentMonth) || null;

  // Next Monday → Sunday
  const getNextWeek = () => {
    const today = new Date();
    const dow = today.getDay();
    const daysToNextMonday = dow === 0 ? 1 : 8 - dow;
    const monday = new Date(today);
    monday.setDate(today.getDate() + daysToNextMonday);
    monday.setHours(0, 0, 0, 0);
    const sunday = new Date(monday);
    sunday.setDate(monday.getDate() + 6);
    sunday.setHours(23, 59, 59, 999);
    return { start: monday, end: sunday };
  };

  const { start: weekStart, end: weekEnd } = getNextWeek();

  const shootItems = items.filter(item => {
    if (!['Planned', 'Shoot Booked'].includes(item.status)) return false;
    if (!item.scheduled_date) return false;
    const d = new Date(item.scheduled_date + 'T00:00:00');
    return d >= weekStart && d <= weekEnd;
  });

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="w-7 h-7 border-2 border-border border-t-accent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto">
      {/* Sticky header */}
      <div className="sticky top-0 z-30 bg-background/95 backdrop-blur border-b border-border px-4 lg:px-8 py-3 flex items-center gap-3">
        <button onClick={onBack} className="p-2 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft size={18} />
        </button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-dm font-bold text-foreground text-lg truncate">{client.name}</span>
            <StatusBadge label={client.package || 'Minimum'} colorMap={packageColors} />
            {client.filming_cadence && <span className="text-xs text-muted-foreground">{client.filming_cadence}</span>}
          </div>
        </div>
      </div>

      <div className="px-4 lg:px-8 py-6 space-y-8">
        {/* Feature 5 — About / Filming Guide / Editing Guide tabs */}
        <ClientAboutTabs client={client} onClientUpdate={reloadClient} />

        {/* Feature 3 — Monthly suggestions */}
        <MonthlySuggestionsPrompt
          client={client}
          items={items}
          currentMonth={currentMonth}
          onUpdate={load}
        />

        {/* Planning Meeting + Feature 6 Previous Meetings */}
        <section>
          <PlanningMeetingSection
            meeting={currentMeeting}
            client={client}
            currentMonth={currentMonth}
            onUpdate={load}
          />
          <PreviousMeetingsArchive meetings={meetings} currentMonth={currentMonth} />
        </section>

        <ShootChecklist
          items={shootItems}
          client={client}
          weekStart={weekStart}
          weekEnd={weekEnd}
          onUpdate={load}
        />

        <ContentCalendarGrid
          items={items}
          client={client}
          onUpdate={load}
        />

        <ContentTrackerBoard
          items={items}
          client={client}
          currentMonth={currentMonth}
          onUpdate={load}
        />
      </div>
    </div>
  );
}