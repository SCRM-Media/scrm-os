import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { X, ExternalLink, Trash2, RefreshCw } from 'lucide-react';
import { FORMAT_GROUPS, STATUSES, CAPTION_STATUSES, isOverdue, getTypeBadgeClass, getFormat, REPEAT_OPTIONS, computeNextDate } from '@/lib/contentTypes';

const AD_LEAD_TYPES = ['Lead Form', 'Landing Page'];

export default function ContentItemDetailModal({ item, client, onClose, onUpdate }) {
  const [form, setForm] = useState({
    title: item.title || '',
    content_type: item.content_type || 'Car of the Week',
    format: item.format || getFormat(item.content_type),
    status: item.status || 'Planned',
    scheduled_date: item.scheduled_date || '',
    drive_folder_link: item.drive_folder_link || '',
    caption: item.caption || '',
    brief: item.brief || '',
    editing_notes: item.editing_notes || '',
    platform_override: item.platform_override || '',
    video_example_url: item.video_example_url || '',
    video_example_title: item.video_example_title || '',
    video_example_notes: item.video_example_notes || '',
    repeat_enabled: item.repeat_enabled || false,
    repeat_frequency: item.repeat_frequency || '1w',
    comments: item.comments || [],
    // Ad fields
    hook_1: item.hook_1 || '',
    hook_2: item.hook_2 || '',
    hook_3: item.hook_3 || '',
    ad_script: item.ad_script || '',
    ad_audience: item.ad_audience || '',
    ad_budget: item.ad_budget || '',
    ad_start_date: item.ad_start_date || '',
    ad_end_date: item.ad_end_date || '',
    lead_type: item.lead_type || '',
    form_questions: item.form_questions || '',
  });
  const [qcSendBackReason, setQcSendBackReason] = useState('');
  const [showSendBack, setShowSendBack] = useState(false);
  const [newComment, setNewComment] = useState('');
  const [savingComment, setSavingComment] = useState(false);
  const [rfsChecked, setRfsChecked] = useState(false);
  const [videoExample, setVideoExample] = useState(null);

  // Load matching ContentTypeExample on mount / content_type change
  useEffect(() => {
    base44.entities.ContentTypeExample.filter({ content_type: form.content_type }).then(res => {
      if (res && res.length > 0) {
        const ex = res[0];
        setVideoExample(ex);
        // Pre-populate if not already set
        if (!form.video_example_url && ex.video_url) {
          save({ video_example_url: ex.video_url, video_example_title: ex.title, video_example_notes: ex.notes || '' });
        }
      } else {
        setVideoExample(null);
      }
    });
  }, [form.content_type]);

  const save = async (patch) => {
    const updated = { ...form, ...patch };
    setForm(updated);
    await base44.entities.ContentItem.update(item.id, patch);
  };

  const set = (k, v) => save({ [k]: v });

  const handleStatusChange = async (status) => {
    await save({ status });
    onUpdate();
  };

  const handleQcPass = () => set('status', 'Ready for Scheduling');

  const handleQcSendBack = async () => {
    if (!qcSendBackReason.trim()) return;
    const comment = { author: 'QC', text: `Sent back from QC: ${qcSendBackReason}`, timestamp: new Date().toISOString() };
    const updatedComments = [...form.comments, comment];
    await base44.entities.ContentItem.update(item.id, { status: 'Editing', comments: updatedComments });
    setForm(f => ({ ...f, status: 'Editing', comments: updatedComments }));
    setShowSendBack(false);
    setQcSendBackReason('');
    onUpdate();
  };

  const handleAddComment = async () => {
    if (!newComment.trim()) return;
    setSavingComment(true);
    const comment = { author: 'Team', text: newComment.trim(), timestamp: new Date().toISOString() };
    const updatedComments = [...form.comments, comment];
    await base44.entities.ContentItem.update(item.id, { comments: updatedComments });
    setForm(f => ({ ...f, comments: updatedComments }));
    setNewComment('');
    setSavingComment(false);
  };

  const createNextInstance = async (frequency) => {
    const freq = frequency || form.repeat_frequency;
    if (!freq || !form.scheduled_date) return;
    const startDate = new Date(form.scheduled_date + 'T00:00:00');
    const endOfMonth = new Date(startDate.getFullYear(), startDate.getMonth() + 1, 0);
    const datesToCreate = [];
    let cursor = computeNextDate(form.scheduled_date, freq);
    while (cursor) {
      const d = new Date(cursor + 'T00:00:00');
      if (d > endOfMonth) break;
      datesToCreate.push(cursor);
      cursor = computeNextDate(cursor, freq);
    }
    if (datesToCreate.length === 0) return;
    const existing = await base44.entities.ContentItem.filter({ client: item.client, title: form.title });
    const existingDates = new Set((existing || []).map(e => e.scheduled_date));
    const toCreate = datesToCreate.filter(d => !existingDates.has(d));
    if (toCreate.length === 0) return;
    await Promise.all(toCreate.map(date => base44.entities.ContentItem.create({
      title: form.title, client: item.client,
      planning_meeting: item.planning_meeting || '',
      content_type: form.content_type, format: form.format,
      template_tag: item.template_tag || '', brief: form.brief,
      repeat_enabled: true, repeat_frequency: freq,
      is_recurring_instance: true, status: 'Planned', scheduled_date: date,
    })));
    onUpdate();
  };

  const handleDelete = async () => {
    if (!confirm('Delete this content item?')) return;
    await base44.entities.ContentItem.delete(item.id);
    onUpdate();
  };

  const handleReelSuggestionAddBoth = async () => {
    await Promise.all([
      base44.entities.ContentItem.create({ title: `${form.title} — Support Post`, client: item.client, content_type: 'Reel Support Post', format: 'Post', scheduled_date: form.scheduled_date, planning_meeting: item.planning_meeting || '', status: 'Planned' }),
      base44.entities.ContentItem.create({ title: `${form.title} — Support Story`, client: item.client, content_type: 'Reel Support Story', format: 'Story', scheduled_date: form.scheduled_date, planning_meeting: item.planning_meeting || '', status: 'Planned' }),
    ]);
    setRfsChecked(true);
    onUpdate();
  };

  const overdue = isOverdue({ ...item, ...form });
  const showCaption = CAPTION_STATUSES.includes(form.status);
  const isReel = FORMAT_GROUPS.Reel.includes(form.content_type) && form.content_type !== 'Ad';
  const isQC = form.status === 'QC';
  const showAdBrief = form.content_type === 'Ad';

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-card rounded-t-2xl sm:rounded-2xl border border-border shadow-2xl w-full sm:max-w-lg max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-border sticky top-0 bg-card z-10">
          <div className="flex items-center gap-2 flex-wrap min-w-0">
            <span className={`text-xs px-2 py-0.5 rounded font-medium shrink-0 ${getTypeBadgeClass(form.content_type)}`}>{getFormat(form.content_type)}</span>
            <span className="font-dm font-bold text-foreground truncate">{form.title}</span>
            {form.is_recurring_instance && (
              <span className="text-xs bg-purple-100 text-purple-700 px-1.5 py-0.5 rounded flex items-center gap-1 shrink-0"><RefreshCw size={10} /> Recurring</span>
            )}
          </div>
          <div className="flex items-center gap-1 shrink-0">
            <button onClick={handleDelete} className="p-1.5 rounded-lg hover:bg-red-50 text-muted-foreground hover:text-red-600 transition-colors"><Trash2 size={15} /></button>
            <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"><X size={18} /></button>
          </div>
        </div>

        <div className="px-5 py-5 space-y-4">
          {/* Overdue flag */}
          {overdue && (
            <div className="bg-red-50 border border-red-200 rounded-lg px-3 py-2 text-xs text-red-700 font-medium flex items-center gap-2">
              ⚠️ Overdue — scheduled date has passed
            </div>
          )}

          {item.template_tag && (
            <div className="text-xs text-muted-foreground">Template: <span className="font-medium text-foreground">{item.template_tag}</span></div>
          )}

          {form.repeat_enabled && (
            <div className="flex items-center gap-2 text-xs bg-purple-50 border border-purple-200 rounded-lg px-3 py-2 text-purple-700">
              <RefreshCw size={12} /> Repeats {REPEAT_OPTIONS.find(r => r.value === form.repeat_frequency)?.label || form.repeat_frequency}
            </div>
          )}

          {/* Reel companion suggestion */}
          {isReel && !rfsChecked && (
            <div className="bg-amber-50 border border-amber-200 rounded-lg px-3 py-2.5">
              <p className="text-xs text-amber-800 font-medium mb-2">Add matching Post and Story?</p>
              <div className="flex gap-2">
                <button onClick={handleReelSuggestionAddBoth} className="text-xs px-3 py-1.5 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors font-medium">Add Both</button>
                <button onClick={() => setRfsChecked(true)} className="text-xs px-3 py-1.5 border border-amber-300 text-amber-700 rounded-lg hover:bg-amber-100 transition-colors">Dismiss</button>
              </div>
            </div>
          )}

          <Field label="Title">
            <input value={form.title} onChange={e => save({ title: e.target.value })} className="input-base" />
          </Field>

          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Content Type</label>
            <select value={form.content_type} onChange={e => save({ content_type: e.target.value, format: getFormat(e.target.value) })} className="input-base">
              <optgroup label="Reels">
                {FORMAT_GROUPS.Reel.map(t => <option key={t}>{t}</option>)}
              </optgroup>
              <optgroup label="Posts">
                {FORMAT_GROUPS.Post.map(t => <option key={t}>{t}</option>)}
              </optgroup>
              <optgroup label="Stories">
                {FORMAT_GROUPS.Story.map(t => <option key={t}>{t}</option>)}
              </optgroup>
              <optgroup label="Ads">
                {FORMAT_GROUPS.Ad.map(t => <option key={t}>{t}</option>)}
              </optgroup>
            </select>
          </div>

          <Field label="Status">
            <select value={form.status} onChange={e => handleStatusChange(e.target.value)} className="input-base">
              {STATUSES.map(s => <option key={s}>{s}</option>)}
            </select>
          </Field>

          <Field label="Scheduled Date">
            <input type="date" value={form.scheduled_date} onChange={e => save({ scheduled_date: e.target.value })} className="input-base" />
          </Field>

          {/* Repeat toggle */}
          <div className="flex items-center justify-between py-1">
            <div>
              <div className="text-xs font-medium text-foreground">Repeat</div>
              <div className="text-xs text-muted-foreground">Fills all instances until end of this month</div>
            </div>
            <button type="button"
              onClick={async () => {
                const enabling = !form.repeat_enabled;
                await save({ repeat_enabled: enabling });
                if (enabling && form.repeat_frequency && form.scheduled_date) await createNextInstance();
              }}
              className={`relative w-10 h-6 rounded-full transition-colors ${form.repeat_enabled ? 'bg-accent' : 'bg-border'}`}
            >
              <span className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-transform ${form.repeat_enabled ? 'translate-x-5' : 'translate-x-1'}`} />
            </button>
          </div>
          {form.repeat_enabled && (
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Repeat Frequency</label>
              <div className="grid grid-cols-2 gap-2">
                {REPEAT_OPTIONS.map(opt => (
                  <button key={opt.value} type="button" onClick={async () => {
                    await save({ repeat_frequency: opt.value });
                    if (opt.value !== form.repeat_frequency && form.scheduled_date) await createNextInstance(opt.value);
                  }}
                    className={`py-2 rounded-lg text-sm font-medium border transition-colors ${form.repeat_frequency === opt.value ? 'bg-accent text-white border-accent' : 'bg-secondary border-border text-foreground hover:border-accent/40'}`}>
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          <Field label="Drive Folder Link">
            <div className="flex gap-2">
              <input value={form.drive_folder_link} onChange={e => save({ drive_folder_link: e.target.value })}
                className="input-base flex-1" placeholder="https://drive.google.com/..." />
              {form.drive_folder_link && (
                <a href={form.drive_folder_link} target="_blank" rel="noreferrer"
                  className="px-3 flex items-center rounded-lg border border-border text-accent hover:bg-secondary transition-colors">
                  <ExternalLink size={15} />
                </a>
              )}
            </div>
          </Field>

          {/* Video Example (replaces Platform Override) */}
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-0.5">Video Example</label>
            {videoExample ? (
              <div className="mb-2 bg-secondary/30 rounded-lg px-3 py-2">
                <div className="text-xs font-medium text-foreground">{videoExample.title}</div>
                {videoExample.notes && <div className="text-xs text-muted-foreground mt-0.5">{videoExample.notes}</div>}
              </div>
            ) : (
              <div className="mb-2 text-xs text-muted-foreground italic">No example saved for this content type yet — add one in Settings.</div>
            )}
            <div className="flex gap-2">
              <input value={form.video_example_url} onChange={e => save({ video_example_url: e.target.value })}
                className="input-base flex-1 text-xs" placeholder="Paste or override video URL..." />
              {form.video_example_url && (
                <a href={form.video_example_url} target="_blank" rel="noreferrer"
                  className="px-3 flex items-center rounded-lg border border-border text-accent hover:bg-secondary transition-colors shrink-0">
                  <ExternalLink size={15} />
                </a>
              )}
            </div>
          </div>

          {/* Shoot Brief */}
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-0.5">Shoot Brief</label>
            <p className="text-xs text-muted-foreground mb-1.5">What to film, hooks, shot structure — read this on-site before filming</p>
            <textarea value={form.brief} onChange={e => save({ brief: e.target.value })}
              className="input-base resize-none h-28" placeholder="Describe what to film, angles, hook ideas, vehicles to feature..." />
          </div>

          {/* Editing Notes (Feature 8) */}
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-0.5">For the Editor</label>
            <p className="text-xs text-muted-foreground mb-1.5">Filming context, song suggestions, split video notes, anything the editor needs to know</p>
            <textarea value={form.editing_notes} onChange={e => save({ editing_notes: e.target.value })}
              className="input-base resize-none h-24" placeholder="Editor notes..." />
          </div>

          {showCaption && (
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-0.5">Caption</label>
              <p className="text-xs text-muted-foreground mb-1.5">Write the post caption here once editing is complete.</p>
              <textarea value={form.caption} onChange={e => save({ caption: e.target.value })}
                className="input-base resize-none h-28" placeholder="Post caption..." />
            </div>
          )}

          {/* Ad Brief section (Feature 11) */}
          {showAdBrief && (
            <div className="border border-border rounded-xl p-4 space-y-3">
              <div className="text-xs font-semibold text-foreground uppercase tracking-wide">Ad Brief</div>
              <Field label="Hook 1"><input value={form.hook_1} onChange={e => save({ hook_1: e.target.value })} className="input-base" placeholder="Opening hook option 1..." /></Field>
              <Field label="Hook 2"><input value={form.hook_2} onChange={e => save({ hook_2: e.target.value })} className="input-base" placeholder="Opening hook option 2..." /></Field>
              <Field label="Hook 3"><input value={form.hook_3} onChange={e => save({ hook_3: e.target.value })} className="input-base" placeholder="Opening hook option 3..." /></Field>
              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-1.5">Script</label>
                <textarea value={form.ad_script} onChange={e => save({ ad_script: e.target.value })} className="input-base resize-none h-32" placeholder="Full ad script..." />
              </div>
              <Field label="Target Audience"><input value={form.ad_audience} onChange={e => save({ ad_audience: e.target.value })} className="input-base" placeholder="Describe the target audience..." /></Field>
              <Field label="Budget (AUD)"><input type="number" value={form.ad_budget} onChange={e => save({ ad_budget: e.target.value })} className="input-base" placeholder="0" /></Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Start Date"><input type="date" value={form.ad_start_date} onChange={e => save({ ad_start_date: e.target.value })} className="input-base" /></Field>
                <Field label="End Date"><input type="date" value={form.ad_end_date} onChange={e => save({ ad_end_date: e.target.value })} className="input-base" /></Field>
              </div>
              <Field label="Lead Type">
                <select value={form.lead_type} onChange={e => save({ lead_type: e.target.value })} className="input-base">
                  <option value="">Select...</option>
                  {AD_LEAD_TYPES.map(t => <option key={t}>{t}</option>)}
                </select>
              </Field>
              {form.lead_type === 'Lead Form' && (
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1.5">Form Questions</label>
                  <textarea value={form.form_questions} onChange={e => save({ form_questions: e.target.value })} className="input-base resize-none h-24" placeholder="List the questions on the lead form..." />
                </div>
              )}
            </div>
          )}

          {/* QC Actions */}
          {isQC && (
            <div className="border border-amber-200 bg-amber-50 rounded-xl p-4">
              <div className="text-xs font-semibold text-amber-800 mb-3">QC Review</div>
              {showSendBack ? (
                <div className="space-y-2">
                  <textarea value={qcSendBackReason} onChange={e => setQcSendBackReason(e.target.value)}
                    className="input-base resize-none h-20 text-sm" placeholder="Reason for sending back (required)..." autoFocus />
                  <div className="flex gap-2">
                    <button onClick={handleQcSendBack} disabled={!qcSendBackReason.trim()}
                      className="flex-1 py-2 bg-red-600 text-white rounded-lg text-sm font-medium hover:bg-red-700 disabled:opacity-40 transition-colors">
                      Confirm Send Back
                    </button>
                    <button onClick={() => setShowSendBack(false)}
                      className="px-4 py-2 border border-border rounded-lg text-sm text-muted-foreground hover:bg-secondary transition-colors">
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex gap-2">
                  <button onClick={handleQcPass} className="flex-1 py-2.5 bg-green-600 text-white rounded-lg text-sm font-semibold hover:bg-green-700 transition-colors">✓ Pass — Ready for Scheduling</button>
                  <button onClick={() => setShowSendBack(true)} className="flex-1 py-2.5 bg-red-600 text-white rounded-lg text-sm font-semibold hover:bg-red-700 transition-colors">✗ Send Back</button>
                </div>
              )}
            </div>
          )}

          {/* Internal Comments */}
          <div className="border-t border-border pt-4">
            <div className="text-xs font-semibold text-muted-foreground mb-3 uppercase tracking-wide">Internal Comments</div>
            <div className="space-y-3 mb-3 max-h-40 overflow-y-auto">
              {form.comments.length === 0 && (
                <p className="text-xs text-muted-foreground italic">No comments yet.</p>
              )}
              {form.comments.map((c, i) => (
                <div key={i} className="bg-secondary/40 rounded-lg px-3 py-2">
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className="text-xs font-medium text-foreground">{c.author}</span>
                    <span className="text-xs text-muted-foreground">{new Date(c.timestamp).toLocaleDateString('en-AU', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                  <p className="text-xs text-foreground">{c.text}</p>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <input value={newComment} onChange={e => setNewComment(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleAddComment(); }}}
                className="input-base flex-1 text-xs" placeholder="Add a comment..." />
              <button onClick={handleAddComment} disabled={!newComment.trim() || savingComment}
                className="px-3 py-2 bg-primary text-primary-foreground rounded-lg text-xs font-medium hover:bg-primary/90 disabled:opacity-40 transition-colors">
                Post
              </button>
            </div>
          </div>

          <div className="text-xs text-muted-foreground pt-1">Changes save automatically.</div>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label className="block text-xs font-medium text-muted-foreground mb-1.5">{label}</label>
      {children}
    </div>
  );
}