import { useState, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { ChevronLeft, ChevronRight, Plus, GripHorizontal } from 'lucide-react';
import ContentItemDetailModal from '@/components/social/ContentItemDetailModal';
import QuickAddModal from '@/components/social/QuickAddModal';
import { getFormat, getTypeBadgeClass } from '@/lib/contentTypes';
import { buildHolidayMap } from '@/lib/australianHolidays';

const DAY_LABELS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

const DRAG_TYPES = [
  { label: 'Reel',  format: 'Reel',  color: 'bg-orange-100 text-orange-700 border-orange-200', content_type: 'Car of the Week' },
  { label: 'Post',  format: 'Post',  color: 'bg-blue-100 text-blue-700 border-blue-200',       content_type: 'Reel Support Post' },
  { label: 'Story', format: 'Story', color: 'bg-pink-100 text-pink-700 border-pink-200',        content_type: 'Reel Support Story' },
  { label: 'Ad',    format: 'Ad',    color: 'bg-red-100 text-red-700 border-red-200',           content_type: 'Ad' },
];

function getMonthGrid(year, month) {
  const firstDay = new Date(year, month, 1);
  let startDow = firstDay.getDay();
  if (startDow === 0) startDow = 7;
  const offset = startDow - 1;
  const cells = [];
  for (let i = 0; i < 42; i++) {
    const d = new Date(year, month, 1 - offset + i);
    cells.push(d);
  }
  return cells;
}

function getWeekDays(baseDate) {
  const dow = baseDate.getDay();
  const daysToMon = dow === 0 ? -6 : 1 - dow;
  const mon = new Date(baseDate);
  mon.setDate(baseDate.getDate() + daysToMon);
  mon.setHours(0, 0, 0, 0);
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(mon);
    d.setDate(mon.getDate() + i);
    return d;
  });
}

function toKey(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function getCycleDates(cycleStartDateStr) {
  if (!cycleStartDateStr) return new Set();
  const [y, m, d] = cycleStartDateStr.split('-').map(Number);
  const anchor = new Date(y, m - 1, d);
  anchor.setHours(0, 0, 0, 0);
  const dates = new Set();
  for (let offset = -365; offset <= 365; offset += 28) {
    const cycleDate = new Date(anchor);
    cycleDate.setDate(anchor.getDate() + offset);
    dates.add(toKey(cycleDate));
  }
  return dates;
}

// ─── Day Cell ─────────────────────────────────────────────────────────────────

function DayCell({ date, dayItems, isToday, inMonth, isCycleStart, holidayName, onItemClick, onAddClick, onDrop, onItemDrop, compact, isMobile }) {
  const [dragOver, setDragOver] = useState(false);
  const [expanded, setExpanded] = useState(false);

  const VISIBLE = compact ? 2 : 99;
  const overflow = Math.max(0, dayItems.length - VISIBLE);

  const handleDragOver = (e) => { e.preventDefault(); setDragOver(true); };
  const handleDragLeave = () => setDragOver(false);
  const handleDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    const dragType = e.dataTransfer.getData('dragType');
    const itemId = e.dataTransfer.getData('itemId');
    if (itemId) {
      onItemDrop(date, itemId);
    } else if (dragType) {
      onDrop(date, dragType);
    }
  };

  if (isMobile) {
    return (
      <div
        className={`min-h-[48px] p-1 relative border-r border-b border-border/50 flex flex-col items-center justify-center ${!inMonth ? 'bg-secondary/20' : ''} ${holidayName ? 'bg-gray-100' : ''} ${isCycleStart ? 'bg-red-50/40' : ''}`}
        onDragOver={handleDragOver} onDragLeave={handleDragLeave} onDrop={handleDrop}
      >
        <div className={`text-xs font-medium w-5 h-5 flex items-center justify-center rounded-full ${isToday ? 'bg-accent text-white' : inMonth ? 'text-foreground' : 'text-muted-foreground/40'}`}>
          {date.getDate()}
        </div>
        {dayItems.length > 0 && (
          <button onClick={() => setExpanded(true)} className="mt-0.5 text-xs font-bold text-accent">
            {dayItems.length}
          </button>
        )}
        {/* Mobile popover */}
        {expanded && (
          <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/40" onClick={() => setExpanded(false)}>
            <div className="bg-card rounded-t-2xl w-full max-w-md p-4 max-h-[60vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
              <div className="text-sm font-semibold text-foreground mb-3">
                {date.toLocaleDateString('en-AU', { weekday: 'long', day: 'numeric', month: 'long' })}
              </div>
              <div className="space-y-2">
                {dayItems.map(item => (
                  <button key={item.id} onClick={() => { setExpanded(false); onItemClick(item); }}
                    className={`w-full text-left text-xs px-2 py-1.5 rounded-lg font-medium ${getTypeBadgeClass(item.content_type)}`}>
                    {item.title}
                  </button>
                ))}
              </div>
              <button onClick={() => setExpanded(false)} className="mt-3 w-full text-xs text-muted-foreground py-1.5">Close</button>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div
      className={`min-h-[120px] p-1 relative group border-r border-b border-border/50 transition-colors
        ${!inMonth ? 'bg-secondary/20' : ''}
        ${holidayName ? 'bg-gray-50' : ''}
        ${isCycleStart && !holidayName ? 'bg-red-50/40' : ''}
        ${dragOver ? 'bg-accent/10 ring-2 ring-inset ring-accent/30' : ''}`}
      onDragOver={handleDragOver} onDragLeave={handleDragLeave} onDrop={handleDrop}
    >
      <div className="flex items-start justify-between mb-0.5">
        <div>
          <div className={`text-xs font-medium w-6 h-6 flex items-center justify-center rounded-full transition-colors ${isToday ? 'bg-accent text-white' : inMonth ? 'text-foreground' : 'text-muted-foreground/40'}`}>
            {date.getDate()}
          </div>
          {holidayName && <div className="text-[9px] text-gray-500 leading-tight mt-0.5 max-w-[80px] truncate">{holidayName}</div>}
          {isCycleStart && !holidayName && <div className="w-2 h-2 rounded-full bg-red-400 mt-0.5" title="Cycle start" />}
        </div>
        <button
          onClick={() => onAddClick(toKey(date))}
          className="opacity-0 group-hover:opacity-100 w-5 h-5 rounded flex items-center justify-center bg-accent text-white hover:bg-accent/80 transition-all"
        >
          <Plus size={11} />
        </button>
      </div>

      {/* Pills — max 2 visible + overflow badge */}
      <div className="space-y-0.5">
        {dayItems.slice(0, VISIBLE).map(item => (
          <div
            key={item.id}
            draggable
            onDragStart={e => { e.stopPropagation(); e.dataTransfer.setData('itemId', item.id); e.dataTransfer.setData('dragType', ''); }}
            onClick={() => onItemClick(item)}
            className={`w-full text-left text-[10px] px-1.5 py-0.5 rounded truncate font-medium leading-tight cursor-grab active:cursor-grabbing select-none ${getTypeBadgeClass(item.content_type)} hover:opacity-80 transition-opacity`}>
            {item.title}
          </div>
        ))}
        {overflow > 0 && (
          <button onClick={() => setExpanded(true)} className="text-[10px] text-muted-foreground pl-1 hover:text-foreground">
            +{overflow} more
          </button>
        )}
      </div>

      {/* Expanded overflow popover */}
      {expanded && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30" onClick={() => setExpanded(false)}>
          <div className="bg-card border border-border rounded-xl shadow-xl p-3 min-w-48 max-w-xs" onClick={e => e.stopPropagation()}>
            <div className="text-xs font-semibold text-foreground mb-2">
              {date.toLocaleDateString('en-AU', { day: 'numeric', month: 'short' })}
            </div>
            {dayItems.map(item => (
              <button key={item.id} onClick={() => { setExpanded(false); onItemClick(item); }}
                className={`w-full text-left text-xs px-2 py-1 rounded mb-1 font-medium ${getTypeBadgeClass(item.content_type)} hover:opacity-80`}>
                {item.title}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Main Component ────────────────────────────────────────────────────────────

export default function ContentCalendarGrid({ items, client, onUpdate }) {
  const today = new Date();
  const [viewMode, setViewMode] = useState('month');
  const [year, setYear] = useState(today.getFullYear());
  const [month, setMonth] = useState(today.getMonth());
  const [weekBase, setWeekBase] = useState(today);
  const [selectedItem, setSelectedItem] = useState(null);
  const [addForDate, setAddForDate] = useState(null);
  const [holidayConfirm, setHolidayConfirm] = useState(null); // { date, dragType, holidayName }
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const dragTypeRef = useRef(null);

  const cycleDates = getCycleDates(client?.cycle_start_date);
  const holidayMap = buildHolidayMap(client?.state || client?.location);

  const itemsByDate = {};
  items.forEach(item => {
    if (item.scheduled_date) {
      if (!itemsByDate[item.scheduled_date]) itemsByDate[item.scheduled_date] = [];
      itemsByDate[item.scheduled_date].push(item);
    }
  });

  const prevMonth = () => { if (month === 0) { setYear(y => y - 1); setMonth(11); } else setMonth(m => m - 1); };
  const nextMonth = () => { if (month === 11) { setYear(y => y + 1); setMonth(0); } else setMonth(m => m + 1); };
  const prevWeek = () => { const d = new Date(weekBase); d.setDate(d.getDate() - 7); setWeekBase(d); };
  const nextWeek = () => { const d = new Date(weekBase); d.setDate(d.getDate() + 7); setWeekBase(d); };

  const navPrev = viewMode === 'month' ? prevMonth : prevWeek;
  const navNext = viewMode === 'month' ? nextMonth : nextWeek;
  const monthName = new Date(year, month).toLocaleDateString('en-AU', { month: 'long', year: 'numeric' });
  const navLabel = viewMode === 'month' ? monthName : (() => {
    const w = getWeekDays(weekBase);
    return `${w[0].toLocaleDateString('en-AU', { day: 'numeric', month: 'short' })} – ${w[6].toLocaleDateString('en-AU', { day: 'numeric', month: 'short' })}`;
  })();

  const cells = viewMode === 'month' ? getMonthGrid(year, month) : null;
  const weekDays = viewMode === 'week' ? getWeekDays(weekBase) : null;

  const doCreateBlankItem = async (dateStr, dragType) => {
    const dt = DRAG_TYPES.find(t => t.label === dragType);
    if (!dt) return;
    const newItem = await base44.entities.ContentItem.create({
      client: client.id,
      title: `Blank ${dt.label}`,
      content_type: dt.content_type,
      format: dt.format,
      status: 'Planned',
      scheduled_date: dateStr,
    });
    onUpdate();
    // Open the detail modal right away
    setSelectedItem(newItem);
  };

  const handleDrop = (date, dragType) => {
    if (!dragType) return;
    const dateStr = toKey(date);
    const holidayName = holidayMap[dateStr];
    if (holidayName) {
      setHolidayConfirm({ dateStr, dragType, holidayName });
    } else {
      doCreateBlankItem(dateStr, dragType);
    }
  };

  const handleItemDrop = async (date, itemId) => {
    const dateStr = toKey(date);
    const item = items.find(i => i.id === itemId);
    if (!item || item.scheduled_date === dateStr) return;
    await base44.entities.ContentItem.update(itemId, { scheduled_date: dateStr });
    onUpdate();
  };

  const renderCells = (dateCells, compact, showOutOfMonth) => dateCells.map((date, i) => {
    const key = toKey(date);
    const inMonth = showOutOfMonth ? true : date.getMonth() === month;
    return (
      <DayCell
        key={i}
        date={date}
        dayItems={itemsByDate[key] || []}
        isToday={key === toKey(today)}
        inMonth={inMonth}
        isCycleStart={cycleDates.has(key)}
        holidayName={holidayMap[key] || null}
        onItemClick={setSelectedItem}
        onAddClick={setAddForDate}
        onDrop={handleDrop}
        onItemDrop={handleItemDrop}
        compact={compact}
        isMobile={isMobile}
      />
    );
  });

  return (
    <section>
      <div className="flex items-center justify-between gap-3 mb-3 flex-wrap">
        <div className="flex items-center gap-2">
          <span className="text-lg">📅</span>
          <h2 className="font-dm font-semibold text-foreground">Content Calendar</h2>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex rounded-lg border border-border overflow-hidden text-xs">
            <button onClick={() => setViewMode('month')} className={`px-3 py-1.5 font-medium transition-colors ${viewMode === 'month' ? 'bg-primary text-primary-foreground' : 'bg-card text-muted-foreground hover:bg-secondary'}`}>Month</button>
            <button onClick={() => setViewMode('week')} className={`px-3 py-1.5 font-medium transition-colors ${viewMode === 'week' ? 'bg-primary text-primary-foreground' : 'bg-card text-muted-foreground hover:bg-secondary'}`}>Week</button>
          </div>
          <div className="flex items-center gap-1">
            <button onClick={navPrev} className="p-1.5 rounded-lg hover:bg-secondary transition-colors text-muted-foreground"><ChevronLeft size={16} /></button>
            <span className="text-sm font-medium text-foreground min-w-40 text-center">{navLabel}</span>
            <button onClick={navNext} className="p-1.5 rounded-lg hover:bg-secondary transition-colors text-muted-foreground"><ChevronRight size={16} /></button>
          </div>
          <button onClick={() => { setYear(today.getFullYear()); setMonth(today.getMonth()); setWeekBase(new Date()); }}
            className="text-xs px-2.5 py-1.5 border border-border rounded-lg text-muted-foreground hover:bg-secondary transition-colors">Today</button>
        </div>
      </div>

      {/* Drag-drop planning toolbar */}
      <div className="flex items-center gap-3 mb-3 p-3 bg-secondary/30 rounded-xl border border-border">
        <span className="text-xs text-muted-foreground font-medium hidden sm:block">Drag to add:</span>
        {DRAG_TYPES.map(dt => (
          <div
            key={dt.label}
            draggable
            onDragStart={e => { e.dataTransfer.setData('dragType', dt.label); dragTypeRef.current = dt.label; }}
            onDragEnd={() => { dragTypeRef.current = null; }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-xs font-semibold cursor-grab active:cursor-grabbing select-none ${dt.color} hover:opacity-80 transition-opacity`}
          >
            <GripHorizontal size={12} />
            {dt.label}
          </div>
        ))}
        <span className="text-[10px] text-muted-foreground hidden sm:block">Drop onto a day cell</span>
      </div>

      <div className="bg-card rounded-xl border border-border overflow-hidden shadow-sm">
        <div className="grid grid-cols-7 border-b border-border">
          {DAY_LABELS.map(d => (
            <div key={d} className="text-center text-xs font-medium text-muted-foreground py-2">{d}</div>
          ))}
        </div>

        <div className="grid grid-cols-7">
          {viewMode === 'month'
            ? renderCells(cells, true, false)
            : renderCells(weekDays, false, true)
          }
        </div>
      </div>

      {/* Holiday confirmation modal */}
      {holidayConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-card rounded-2xl border border-border shadow-2xl w-full max-w-sm p-6">
            <div className="text-sm font-semibold text-foreground mb-2">⚠️ Public Holiday</div>
            <p className="text-sm text-foreground mb-4">
              This date is a public holiday in the client's state (<strong>{holidayConfirm.holidayName}</strong>). Are you sure you want to schedule content on this day?
            </p>
            <div className="flex gap-2">
              <button onClick={() => { doCreateBlankItem(holidayConfirm.dateStr, holidayConfirm.dragType); setHolidayConfirm(null); }}
                className="flex-1 py-2 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accent/90">Continue</button>
              <button onClick={() => setHolidayConfirm(null)}
                className="flex-1 py-2 border border-border rounded-lg text-sm text-muted-foreground hover:bg-secondary">Cancel</button>
            </div>
          </div>
        </div>
      )}

      {selectedItem && (
        <ContentItemDetailModal
          item={selectedItem}
          client={client}
          onClose={() => setSelectedItem(null)}
          onUpdate={() => { setSelectedItem(null); onUpdate(); }}
        />
      )}

      {addForDate && (
        <QuickAddModal
          client={client}
          defaultDate={addForDate}
          defaultStatus="Planned"
          onSave={async (data) => {
            await base44.entities.ContentItem.create(data);
            setAddForDate(null);
            onUpdate();
          }}
          onClose={() => setAddForDate(null)}
        />
      )}
    </section>
  );
}