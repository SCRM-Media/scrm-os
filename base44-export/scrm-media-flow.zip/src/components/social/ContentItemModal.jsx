import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { X } from 'lucide-react';

const STATUSES = ['Planned', 'Shoot Booked', 'Filmed', 'Editing', 'QC', 'Caption', 'Scheduled', 'Published'];

export default function ContentItemModal({ item, clients, onSave, onClose, lockedClient }) {
  const [meetings, setMeetings] = useState([]);
  const [form, setForm] = useState({
    title: item?.title || '',
    client: item?.client || '',
    planning_meeting: item?.planning_meeting || '',
    content_type: item?.content_type || 'Reel',
    status: item?.status || 'Planned',
    scheduled_date: item?.scheduled_date || '',
    drive_folder_link: item?.drive_folder_link || '',
    caption: item?.caption || '',
    platform_override: item?.platform_override || '',
  });

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  useEffect(() => {
    if (form.client) {
      base44.entities.PlanningMeeting.filter({ client: form.client }).then(setMeetings);
    } else {
      setMeetings([]);
    }
  }, [form.client]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(form);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
      <div className="bg-card rounded-2xl border border-border shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border sticky top-0 bg-card z-10">
          <h2 className="font-dm font-bold text-foreground">{item ? 'Edit Content Item' : 'Add Content Item'}</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X size={18} /></button>
        </div>

        <form onSubmit={handleSubmit} className="px-6 py-5 space-y-4">
          <Field label="Title *">
            <input required value={form.title} onChange={e => set('title', e.target.value)}
              className="input-base" placeholder="e.g. Summer Sale Reel" />
          </Field>

          <div className="grid grid-cols-2 gap-4">
            <Field label="Client *">
              {lockedClient ? (
                <div className="input-base bg-secondary/40 text-muted-foreground cursor-not-allowed">{lockedClient.name}</div>
              ) : (
                <select required value={form.client} onChange={e => set('client', e.target.value)} className="input-base">
                  <option value="">Select client...</option>
                  {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              )}
            </Field>
            <Field label="Content Type">
              <select value={form.content_type} onChange={e => set('content_type', e.target.value)} className="input-base">
                {['Reel', 'Post', 'Story'].map(t => <option key={t}>{t}</option>)}
              </select>
            </Field>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Field label="Status">
              <select value={form.status} onChange={e => set('status', e.target.value)} className="input-base">
                {STATUSES.map(s => <option key={s}>{s}</option>)}
              </select>
            </Field>
            <Field label="Scheduled Date">
              <input type="date" value={form.scheduled_date} onChange={e => set('scheduled_date', e.target.value)} className="input-base" />
            </Field>
          </div>

          {meetings.length > 0 && (
            <Field label="Planning Meeting">
              <select value={form.planning_meeting} onChange={e => set('planning_meeting', e.target.value)} className="input-base">
                <option value="">No meeting linked</option>
                {meetings.map(m => <option key={m.id} value={m.id}>{m.month} — {m.status}</option>)}
              </select>
            </Field>
          )}

          <Field label="Drive Folder Link">
            <input type="url" value={form.drive_folder_link} onChange={e => set('drive_folder_link', e.target.value)}
              className="input-base" placeholder="https://drive.google.com/..." />
          </Field>

          <Field label="Caption">
            <textarea value={form.caption} onChange={e => set('caption', e.target.value)}
              className="input-base resize-none h-24" placeholder="Post caption..." />
          </Field>

          <Field label="Platform Override">
            <input value={form.platform_override} onChange={e => set('platform_override', e.target.value)}
              className="input-base" placeholder="Leave blank for Instagram, TikTok & Facebook" />
            <p className="text-xs text-muted-foreground mt-1">Default: Instagram, TikTok, Facebook. Only fill if different.</p>
          </Field>

          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose}
              className="flex-1 px-4 py-2 rounded-lg border border-border text-sm font-medium text-foreground hover:bg-secondary transition-colors">
              Cancel
            </button>
            <button type="submit"
              className="flex-1 px-4 py-2 rounded-lg bg-accent text-white text-sm font-medium hover:bg-accent/90 transition-colors">
              {item ? 'Save Changes' : 'Add Item'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label className="block text-xs font-medium text-muted-foreground mb-1.5">{label}</label>
      {children}
    </div>
  );
}