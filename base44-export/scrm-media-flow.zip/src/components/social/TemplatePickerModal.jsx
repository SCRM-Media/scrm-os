import { useState } from 'react';
import { X } from 'lucide-react';
import { CONTENT_TEMPLATES, FORMAT_GROUPS, getTypeBadgeClass } from '@/lib/contentTypes';

const FORMAT_COLORS = {
  Reel:  'text-orange-600 bg-orange-50 border-orange-200',
  Post:  'text-blue-600 bg-blue-50 border-blue-200',
  Story: 'text-pink-600 bg-pink-50 border-pink-200',
  Ad:    'text-red-600 bg-red-50 border-red-200',
};

export default function TemplatePickerModal({ onSelect, onCustom, onClose }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-card rounded-t-2xl sm:rounded-2xl border border-border shadow-2xl w-full sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between px-5 py-4 border-b border-border sticky top-0 bg-card z-10">
          <h2 className="font-dm font-bold text-foreground">Add Content</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X size={18} /></button>
        </div>

        <div className="px-5 py-4">
          {/* Custom option */}
          <button onClick={onCustom}
            className="w-full mb-5 py-3 border-2 border-dashed border-border rounded-xl text-sm font-medium text-muted-foreground hover:border-accent hover:text-accent transition-colors">
            + Custom (blank form)
          </button>

          {Object.entries(FORMAT_GROUPS).map(([format, types]) => (
            <div key={format} className="mb-5">
              <div className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold border mb-3 ${FORMAT_COLORS[format]}`}>
                {format}s
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {types.map(type => {
                  const tpl = CONTENT_TEMPLATES.find(t => t.content_type === type);
                  return (
                    <button
                      key={type}
                      onClick={() => onSelect(tpl)}
                      className="text-left p-3 rounded-xl border border-border hover:border-accent hover:bg-secondary/40 transition-all group"
                    >
                      <div className={`text-xs px-1.5 py-0.5 rounded font-medium mb-2 inline-block ${getTypeBadgeClass(type)}`}>
                        {format}
                      </div>
                      <div className="text-sm font-medium text-foreground leading-tight">{type}</div>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}