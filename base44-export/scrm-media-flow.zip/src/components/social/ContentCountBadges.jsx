import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { FORMAT_GROUPS } from '@/lib/contentTypes';

function Badge({ label, x, y, daysLeft }) {
  const met = x >= y;
  const warn = !met && daysLeft <= 14;
  const color = met
    ? 'bg-green-100 text-green-700 border-green-200'
    : warn
    ? 'bg-amber-100 text-amber-700 border-amber-200'
    : 'bg-secondary text-muted-foreground border-border';
  return (
    <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium ${color}`}>
      <span>{label}</span>
      <span className="font-bold">{x}</span>
      {y > 0 && <span className="opacity-60">/ {y}</span>}
    </div>
  );
}

export default function ContentCountBadges({ items, client, currentMonth }) {
  const [pkg, setPkg] = useState(null);

  useEffect(() => {
    if (client.package) {
      base44.entities.Package.filter({ name: client.package }).then(res => {
        if (res && res.length > 0) setPkg(res[0]);
      });
    }
  }, [client.package]);

  const now = new Date();
  const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
  const daysLeft = Math.max(0, Math.ceil((lastDay - now) / (1000 * 60 * 60 * 24)));

  const monthItems = items.filter(i => i.scheduled_date && i.scheduled_date.startsWith(currentMonth));

  const reelCount = monthItems.filter(i => FORMAT_GROUPS.Reel.includes(i.content_type)).length;
  const postCount = monthItems.filter(i => FORMAT_GROUPS.Post.includes(i.content_type)).length;
  const storyCount = monthItems.filter(i => FORMAT_GROUPS.Story.includes(i.content_type)).length;
  // Ads: for simplicity, count items that are Reel type (ad content)
  const adCount = monthItems.filter(i => ['Car of the Week', 'Car Highlight'].includes(i.content_type)).length;

  // Derive Y from package
  const reelTarget = pkg?.monthly_video_count || 0;
  const postTarget = pkg?.posts_per_week ? pkg.posts_per_week * 4 : 0;
  const storyTarget = pkg?.posts_per_week ? pkg.posts_per_week * 4 : 0;
  const adTarget = ['Dominate', 'Partner'].includes(client.package) ? 2 : 0;

  return (
    <div className="flex flex-wrap gap-2 mb-4">
      <Badge label="Reels" x={reelCount} y={reelTarget} daysLeft={daysLeft} />
      <Badge label="Posts" x={postCount} y={postTarget} daysLeft={daysLeft} />
      <Badge label="Stories" x={storyCount} y={storyTarget} daysLeft={daysLeft} />
      <Badge label="Ads" x={adCount} y={adTarget} daysLeft={daysLeft} />
    </div>
  );
}