import { useState } from 'react';
import { X, RefreshCw } from 'lucide-react';
import { FORMAT_GROUPS, STATUSES, getFormat, REPEAT_OPTIONS } from '@/lib/contentTypes';
import TemplatePickerModal from '@/components/social/TemplatePickerModal';

export default function QuickAddModal({ client, defaultType, defaultStatus, defaultDate, onSave, onClose }) {
  const [step, setStep] = useState('pick'); // 'pick' | 'form'
  const [form, setForm] = useState({
    title: '',
    content_type: defaultType || 'Car of the Week',
    format: defaultType ? getFormat(defaultType) : 'Reel',
    status: defaultStatus || 'Planned',
    scheduled_date: defaultDate || '',
    platform_override: '',
    brief: '',
    repeat_enabled: false,
    repeat_frequency: '',
    client: client.id,
    template_tag: '',
  });
  const [saving, setSaving] = useState(false);
  const [testimonialsBlocked, setTestimonialsBlocked] = useState(false);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleTemplateSelect = (tpl) => {
    if (tpl.content_type === 'Testimonial Story') {
      const reviews = Number(client.monthly_google_reviews || 0);
      if (reviews < 5) { setTestimonialsBlocked(true); return; }
    }
    setForm(f => ({
      ...f,
      content_type: tpl.content_type,
      format: tpl.format,
      title: tpl.title,
      template_tag: tpl.content_type,
    }));
    setStep('form');
  };

  const handleCustom = () => {
    setForm(f => ({ ...f, template_tag: '', title: '' }));
    setStep('form');
  };

  const handleTypeChange = (content_type) => {
    if (content_type === 'Testimonial Story') {
      const reviews = Number(client.monthly_google_reviews || 0);
      if (reviews < 5) { setTestimonialsBlocked(true); set('content_type', content_type); set('format', getFormat(content_type)); return; }
    }
    setTestimonialsBlocked(false);
    set('content_type', content_type);
    set('format', getFormat(content_type));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    await onSave({ ...form });
    // If repeat enabled, create all instances until end of the month
    if (form.repeat_enabled && form.repeat_frequency && form.scheduled_date) {
      const { computeNextDate } = await import('@/lib/contentTypes');
      const { base44: b44 } = await import('@/api/base44Client');

      const startDate = new Date(form.scheduled_date + 'T00:00:00');
      const endOfMonth = new Date(startDate.getFullYear(), startDate.getMonth() + 1, 0);

      const datesToCreate = [];
      let cursor = computeNextDate(form.scheduled_date, form.repeat_frequency);
      while (cursor) {
        const d = new Date(cursor + 'T00:00:00');
        if (d > endOfMonth) break;
        datesToCreate.push(cursor);
        cursor = computeNextDate(cursor, form.repeat_frequency);
      }

      await Promise.all(datesToCreate.map(date =>
        b44.entities.ContentItem.create({
          title: form.title,
          client: client.id,
          content_type: form.content_type,
          format: form.format,
          template_tag: form.template_tag || '',
          brief: form.brief,
          repeat_enabled: true,
          repeat_frequency: form.repeat_frequency,
          is_recurring_instance: true,
          status: 'Planned',
          scheduled_date: date,
        })
      ));
    }
    setSaving(false);
  };

  if (step === 'pick') {
    return (
      <>
        {testimonialsBlocked ? (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/50 backdrop-blur-sm">
            <div className="bg-card rounded-t-2xl sm:rounded-2xl border border-border shadow-2xl w-full sm:max-w-md p-6">
              <div className="text-center">
                <div className="text-3xl mb-3">⭐</div>
                <h3 className="font-dm font-bold text-foreground mb-2">Not Enough Reviews</h3>
                <p className="text-sm text-muted-foreground mb-4">Testimonial Stories require a minimum of 5 x five-star Google reviews this month. Update the review count in the client profile first.</p>
                <div className="flex gap-2">
                  <button onClick={() => setTestimonialsBlocked(false)} className="flex-1 py-2 border border-border rounded-lg text-sm text-muted-foreground hover:bg-secondary">Go Back</button>
                  <button onClick={onClose} className="flex-1 py-2 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accent/90">Close</button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <TemplatePickerModal onSelect={handleTemplateSelect} onCustom={handleCustom} onClose={onClose} />
        )}
      </>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-card rounded-t-2xl sm:rounded-2xl border border-border shadow-2xl w-full sm:max-w-md max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between px-5 py-4 border-b border-border sticky top-0 bg-card z-10">
          <div>
            <h2 className="font-dm font-bold text-foreground text-sm">Add Content — {client.name}</h2>
            {form.template_tag && <p className="text-xs text-muted-foreground">Template: {form.template_tag}</p>}
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X size={18} /></button>
        </div>

        <form onSubmit={handleSubmit} className="px-5 py-4 space-y-4">
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Title *</label>
            <input required value={form.title} onChange={e => set('title', e.target.value)}
              className="input-base" placeholder="e.g. Patrol Car of the Week" autoFocus />
          </div>

          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Content Type</label>
            <select value={form.content_type} onChange={e => handleTypeChange(e.target.value)} className="input-base">
              <optgroup label="Reels">
                {FORMAT_GROUPS.Reel.map(t => <option key={t}>{t}</option>)}
              </optgroup>
              <optgroup label="Posts">
                {FORMAT_GROUPS.Post.map(t => <option key={t}>{t}</option>)}
              </optgroup>
              <optgroup label="Stories">
                {FORMAT_GROUPS.Story.map(t => <option key={t}>{t}</option>)}
              </optgroup>
              <optgroup label="Ads">
                {FORMAT_GROUPS.Ad.map(t => <option key={t}>{t}</option>)}
              </optgroup>
            </select>
            {testimonialsBlocked && (
              <p className="text-xs text-red-500 mt-1">Requires 5+ Google reviews this month. Update the client profile first.</p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Status</label>
              <select value={form.status} onChange={e => set('status', e.target.value)} className="input-base">
                {STATUSES.map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Scheduled Date</label>
              <input type="date" value={form.scheduled_date} onChange={e => set('scheduled_date', e.target.value)} className="input-base" />
            </div>
          </div>

          {/* Shoot Brief */}
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-0.5">Shoot Brief</label>
            <p className="text-xs text-muted-foreground mb-1.5">What to film, hooks, shot structure</p>
            <textarea value={form.brief} onChange={e => set('brief', e.target.value)}
              className="input-base resize-none h-20" placeholder="Describe what to film, angles, hooks, vehicles to feature..." />
          </div>

          {/* Repeat */}
          <div className="border border-border rounded-xl p-3 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <RefreshCw size={14} className="text-muted-foreground" />
                <span className="text-xs font-medium text-foreground">Repeat</span>
              </div>
              <button
                type="button"
                onClick={() => set('repeat_enabled', !form.repeat_enabled)}
                className={`relative w-10 h-6 rounded-full transition-colors ${form.repeat_enabled ? 'bg-accent' : 'bg-border'}`}
              >
                <span className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-transform ${form.repeat_enabled ? 'translate-x-5' : 'translate-x-1'}`} />
              </button>
            </div>
            {form.repeat_enabled && (
              <div className="grid grid-cols-2 gap-2">
                {REPEAT_OPTIONS.map(opt => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => set('repeat_frequency', opt.value)}
                    className={`py-2 rounded-lg text-xs font-medium border transition-colors ${form.repeat_frequency === opt.value ? 'bg-accent text-white border-accent' : 'bg-secondary border-border text-foreground hover:border-accent/40'}`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1.5">Platform Override <span className="font-normal opacity-60">(optional)</span></label>
            <input value={form.platform_override} onChange={e => set('platform_override', e.target.value)}
              className="input-base" placeholder="Leave blank for default: Instagram, TikTok, Facebook" />
          </div>

          <div className="flex gap-3 pt-1">
            <button type="button" onClick={() => setStep('pick')}
              className="flex-1 px-4 py-2.5 border border-border rounded-lg text-sm font-medium text-foreground hover:bg-secondary transition-colors">Back</button>
            <button type="submit" disabled={saving || testimonialsBlocked}
              className="flex-1 px-4 py-2.5 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accent/90 transition-colors disabled:opacity-50">
              {saving ? 'Adding...' : 'Add Item'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}