import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Camera, Plus, Video, RefreshCw } from 'lucide-react';
import QuickAddModal from '@/components/social/QuickAddModal';
import { getFormat, getTypeBadgeClass } from '@/lib/contentTypes';

const COL_STYLES = {
  Post:  { bg: 'bg-blue-50',   border: 'border-blue-200',   dot: 'bg-blue-500'   },
  Reel:  { bg: 'bg-orange-50', border: 'border-orange-200', dot: 'bg-orange-500' },
  Story: { bg: 'bg-pink-50',   border: 'border-pink-200',   dot: 'bg-pink-500'   },
};

const STATUS_PILL = {
  'Planned':     'bg-gray-100 text-gray-600',
  'Shoot Booked':'bg-sky-100 text-sky-700',
};

function fmt(d) {
  if (!d) return '';
  return new Date(d + 'T00:00:00').toLocaleDateString('en-AU', { weekday: 'short', day: 'numeric', month: 'short' });
}

export default function ShootChecklist({ items, client, weekStart, weekEnd, onUpdate }) {
  const [filmingId, setFilmingId] = useState(null);
  const [driveLink, setDriveLink] = useState('');
  const [saving, setSaving] = useState(false);
  const [quickAdd, setQuickAdd] = useState(null);

  const weekLabel = `${weekStart.toLocaleDateString('en-AU', { day: 'numeric', month: 'short' })} – ${weekEnd.toLocaleDateString('en-AU', { day: 'numeric', month: 'short' })}`;

  const handleMarkFilmed = async () => {
    if (!driveLink.trim()) return;
    setSaving(true);
    await base44.entities.ContentItem.update(filmingId, { status: 'Filmed', drive_folder_link: driveLink });
    setFilmingId(null);
    setDriveLink('');
    setSaving(false);
    onUpdate();
  };

  return (
    <section>
      <div className="flex items-center gap-2 mb-3">
        <Camera size={16} className="text-accent" />
        <h2 className="font-dm font-semibold text-foreground">Weekly Content Shoot Checklist</h2>
        <span className="text-xs text-muted-foreground">— Next week: {weekLabel}</span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {['Post', 'Reel', 'Story'].map(formatGroup => {
          const col = COL_STYLES[formatGroup];
          const colItems = items.filter(i => getFormat(i.content_type) === formatGroup);
          return (
            <div key={formatGroup} className={`rounded-xl border ${col.border} ${col.bg} p-4`}>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className={`w-2.5 h-2.5 rounded-full ${col.dot}`} />
                  <span className="font-dm font-semibold text-sm text-foreground">{formatGroup}s</span>
                  <span className="text-xs text-muted-foreground">({colItems.length})</span>
                </div>
                <button onClick={() => setQuickAdd(formatGroup)}
                  className="w-6 h-6 rounded-md bg-white/70 border border-border flex items-center justify-center text-muted-foreground hover:text-accent hover:border-accent transition-colors">
                  <Plus size={13} />
                </button>
              </div>

              {colItems.length === 0 ? (
                <p className="text-xs text-muted-foreground text-center py-4 opacity-60">Nothing to film this week</p>
              ) : (
                <div className="space-y-2">
                  {colItems.map(item => (
                    <div key={item.id} className="bg-white rounded-lg border border-border/60 p-3 shadow-sm">
                      <div className="flex items-center gap-1.5 mb-1">
                        <span className={`text-xs px-1 py-0.5 rounded font-medium ${getTypeBadgeClass(item.content_type)}`}>{item.content_type}</span>
                        {item.is_recurring_instance && <RefreshCw size={9} className="text-purple-500" />}
                      </div>
                      <div className="font-medium text-sm text-foreground mb-1 leading-tight">{item.title}</div>
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <span className="text-xs text-muted-foreground">{fmt(item.scheduled_date)}</span>
                        <span className={`text-xs px-1.5 py-0.5 rounded font-medium ${STATUS_PILL[item.status] || 'bg-gray-100 text-gray-600'}`}>{item.status}</span>
                      </div>
                      {item.brief && (
                        <p className="text-xs text-muted-foreground bg-secondary/40 rounded p-2 mb-2 leading-relaxed">{item.brief}</p>
                      )}
                      {filmingId === item.id ? (
                        <div className="space-y-2 mt-2 pt-2 border-t border-border/50">
                          <input value={driveLink} onChange={e => setDriveLink(e.target.value)}
                            className="input-base text-xs" placeholder="Drive folder link (required)..." autoFocus />
                          <div className="flex gap-2">
                            <button onClick={handleMarkFilmed} disabled={!driveLink.trim() || saving}
                              className="flex-1 py-1.5 bg-accent text-white rounded-lg text-xs font-medium hover:bg-accent/90 disabled:opacity-40 transition-colors">
                              {saving ? '...' : '✓ Filmed'}
                            </button>
                            <button onClick={() => { setFilmingId(null); setDriveLink(''); }}
                              className="px-3 py-1.5 border border-border rounded-lg text-xs text-muted-foreground hover:bg-secondary transition-colors">
                              Cancel
                            </button>
                          </div>
                        </div>
                      ) : (
                        <button onClick={() => { setFilmingId(item.id); setDriveLink(item.drive_folder_link || ''); }}
                          className="w-full flex items-center justify-center gap-1.5 py-1.5 bg-accent/10 text-accent rounded-lg text-xs font-medium hover:bg-accent/20 transition-colors">
                          <Video size={11} /> Mark as Filmed
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {quickAdd && (
        <QuickAddModal
          client={client}
          defaultType={quickAdd === 'Reel' ? 'Car of the Week' : quickAdd === 'Post' ? 'Reel Support Post' : 'Reel Support Story'}
          defaultStatus="Planned"
          onSave={async (data) => { await base44.entities.ContentItem.create(data); setQuickAdd(null); onUpdate(); }}
          onClose={() => setQuickAdd(null)}
        />
      )}
    </section>
  );
}