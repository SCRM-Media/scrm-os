import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import CarBeeTab from '@/components/clients/CarBeeTab.jsx';
import InventoryPhotographyTab from '@/components/clients/InventoryPhotographyTab.jsx';

const BASE_TABS = ['About', 'Filming Guide', 'Editing Guide'];

export default function ClientAboutTabs({ client, onClientUpdate }) {
  const [tab, setTab] = useState('About');
  const [filmingGuide, setFilmingGuide] = useState(client.filming_guide || '');
  const [editingGuide, setEditingGuide] = useState(client.editing_guide || '');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [employees, setEmployees] = useState([]);

  useEffect(() => {
    base44.entities.Employee.list().then(setEmployees);
  }, []);

  // Update local state when client prop changes (after onClientUpdate)
  useEffect(() => {
    setFilmingGuide(client.filming_guide || '');
    setEditingGuide(client.editing_guide || '');
  }, [client.id, client.filming_guide, client.editing_guide]);

  const showCarBee = !!client.carbee_enabled;
  const showInventory = !!client.inventory_enabled;

  const tabs = [
    ...BASE_TABS,
    ...(showCarBee ? ['CarBee'] : []),
    ...(showInventory ? ['Inventory Photography'] : []),
  ];

  // Reset to About if current tab was removed
  useEffect(() => {
    if (!tabs.includes(tab)) setTab('About');
  }, [showCarBee, showInventory]);

  const autoSave = async (field, value) => {
    setSaving(true);
    await base44.entities.Client.update(client.id, { [field]: value });
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
    onClientUpdate && onClientUpdate();
  };

  const progress = client.onboarding_progress || {};
  const contact = progress.contact || {};

  return (
    <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
      {/* Tab row */}
      <div className="flex border-b border-border overflow-x-auto">
        {tabs.map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-4 py-3 text-sm font-medium transition-colors border-b-2 -mb-px whitespace-nowrap shrink-0 ${tab === t ? 'border-accent text-accent' : 'border-transparent text-muted-foreground hover:text-foreground'}`}>
            {t}
          </button>
        ))}
        {(saving || saved) && (
          <div className="ml-auto px-4 flex items-center text-xs text-muted-foreground shrink-0">
            {saving ? 'Saving...' : '✓ Saved'}
          </div>
        )}
      </div>

      <div className="p-5">
        {tab === 'About' && (
          <div className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-x-8 gap-y-2">
              <Detail label="Dealership" value={client.name} />
              <Detail label="Package" value={client.package} />
              <Detail label="Location" value={client.location || client.address} />
              <Detail label="State" value={client.state} />
              <Detail label="Filming Cadence" value={client.filming_cadence} />
              <Detail label="Monthly Google Reviews" value={client.monthly_google_reviews != null ? String(client.monthly_google_reviews) : null} />
              <Detail label="Primary Contact" value={contact.full_name} />
              <Detail label="Contact Phone" value={contact.phone} />
              {showCarBee && <Detail label="CarBee Model" value={client.carbee_model} />}
              {showInventory && <Detail label="Inventory Photography" value="Active" />}
            </div>

            {client.content_notes && (
              <div>
                <div className="text-xs font-medium text-muted-foreground mb-1.5">Content Notes</div>
                <p className="text-sm text-foreground leading-relaxed whitespace-pre-line bg-secondary/30 rounded-lg px-4 py-3">{client.content_notes}</p>
              </div>
            )}

            {client.brand_pack && (
              <div>
                <div className="text-xs font-medium text-muted-foreground mb-1.5">Brand Pack</div>
                <p className="text-sm text-foreground leading-relaxed whitespace-pre-line bg-secondary/30 rounded-lg px-4 py-3">{client.brand_pack}</p>
              </div>
            )}

            {!client.content_notes && !client.brand_pack && !contact.full_name && (
              <p className="text-sm text-muted-foreground italic">No additional details on file.</p>
            )}
          </div>
        )}

        {tab === 'Filming Guide' && (
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1">Filming instructions for content creators</label>
            <p className="text-xs text-muted-foreground mb-3">Shot preferences, parking, dealership layout, key contacts on-site, what to avoid.</p>
            <textarea
              value={filmingGuide}
              onChange={e => setFilmingGuide(e.target.value)}
              onBlur={e => autoSave('filming_guide', e.target.value)}
              className="input-base resize-none h-64 font-inter text-sm leading-relaxed"
              placeholder="Write filming instructions here..."
            />
            <div className="mt-2 flex justify-end">
              <button onClick={() => autoSave('filming_guide', filmingGuide)}
                className="text-xs px-3 py-1.5 bg-accent text-white rounded-lg hover:bg-accent/90 transition-colors">Save</button>
            </div>
          </div>
        )}

        {tab === 'Editing Guide' && (
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1">Editing instructions for editors</label>
            <p className="text-xs text-muted-foreground mb-3">Style preferences, music direction, pacing, graphics, what the client likes and dislikes.</p>
            <textarea
              value={editingGuide}
              onChange={e => setEditingGuide(e.target.value)}
              onBlur={e => autoSave('editing_guide', e.target.value)}
              className="input-base resize-none h-64 font-inter text-sm leading-relaxed"
              placeholder="Write editing instructions here..."
            />
            <div className="mt-2 flex justify-end">
              <button onClick={() => autoSave('editing_guide', editingGuide)}
                className="text-xs px-3 py-1.5 bg-accent text-white rounded-lg hover:bg-accent/90 transition-colors">Save</button>
            </div>
          </div>
        )}

        {tab === 'CarBee' && showCarBee && (
          <CarBeeTab client={client} employees={employees} onClientUpdate={onClientUpdate} />
        )}

        {tab === 'Inventory Photography' && showInventory && (
          <InventoryPhotographyTab client={client} employees={employees} onClientUpdate={onClientUpdate} />
        )}
      </div>
    </div>
  );
}

function Detail({ label, value }) {
  if (!value) return null;
  return (
    <div className="py-1.5 border-b border-border/40 last:border-0">
      <span className="text-xs text-muted-foreground block">{label}</span>
      <span className="text-sm font-medium text-foreground">{value}</span>
    </div>
  );
}