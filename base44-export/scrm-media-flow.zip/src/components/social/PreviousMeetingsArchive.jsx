import { useState } from 'react';
import { ChevronDown, ChevronRight, X } from 'lucide-react';

const statusPill = {
  'Scheduled': 'bg-blue-100 text-blue-700',
  'Completed': 'bg-green-100 text-green-700',
  'Cancelled': 'bg-gray-100 text-gray-600',
};

function fmt(dateStr) {
  if (!dateStr) return '';
  return new Date(dateStr + 'T00:00:00').toLocaleDateString('en-AU', { weekday: 'short', day: 'numeric', month: 'long', year: 'numeric' });
}

function monthLabel(monthStr) {
  if (!monthStr) return '';
  const [y, m] = monthStr.split('-');
  return new Date(parseInt(y), parseInt(m) - 1).toLocaleDateString('en-AU', { month: 'long', year: 'numeric' });
}

function MeetingDetailModal({ meeting, onClose }) {
  const fields = [
    { label: 'Month', value: monthLabel(meeting.month) },
    { label: 'Meeting Date', value: meeting.meeting_date ? fmt(meeting.meeting_date) : null },
    { label: 'Status', value: meeting.status },
    { label: 'Offers to Push', value: meeting.offers_to_push },
    { label: 'Priority Stock', value: meeting.priority_stock },
    { label: 'Upcoming Events', value: meeting.upcoming_events },
    { label: 'Content Priorities', value: meeting.content_priorities },
    { label: 'Sensitivities', value: meeting.sensitivities },
    { label: 'General Notes', value: meeting.notes || meeting.general_notes },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-card rounded-2xl border border-border shadow-2xl w-full max-w-lg max-h-[80vh] overflow-y-auto">
        <div className="flex items-center justify-between px-5 py-4 border-b border-border sticky top-0 bg-card">
          <div>
            <h3 className="font-dm font-bold text-foreground">{monthLabel(meeting.month)}</h3>
            <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium mt-1 ${statusPill[meeting.status] || statusPill.Scheduled}`}>
              {meeting.status}
            </span>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground">
            <X size={18} />
          </button>
        </div>
        <div className="px-5 py-5 space-y-4">
          {fields.map(({ label, value }) => value ? (
            <div key={label}>
              <div className="text-xs font-medium text-muted-foreground mb-1">{label}</div>
              <p className="text-sm text-foreground whitespace-pre-line leading-relaxed">{value}</p>
            </div>
          ) : null)}
        </div>
      </div>
    </div>
  );
}

export default function PreviousMeetingsArchive({ meetings, currentMonth }) {
  const [open, setOpen] = useState(false);
  const [detailMeeting, setDetailMeeting] = useState(null);

  const previous = meetings
    .filter(m => m.month && m.month < currentMonth)
    .sort((a, b) => b.month.localeCompare(a.month));

  if (previous.length === 0) return null;

  return (
    <div className="mt-4">
      <button
        onClick={() => setOpen(o => !o)}
        className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors font-medium"
      >
        {open ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
        Previous Meetings ({previous.length})
      </button>

      {open && (
        <div className="mt-3 space-y-2">
          {previous.map(m => (
            <button
              key={m.id}
              onClick={() => setDetailMeeting(m)}
              className="w-full text-left bg-card border border-border rounded-xl px-4 py-3 hover:border-accent/40 hover:shadow-sm transition-all"
            >
              <div className="flex items-center justify-between gap-3 mb-1">
                <span className="text-sm font-medium text-foreground">{monthLabel(m.month)}</span>
                <span className={`text-xs px-2 py-0.5 rounded-full font-medium shrink-0 ${statusPill[m.status] || statusPill.Scheduled}`}>
                  {m.status}
                </span>
              </div>
              {m.meeting_date && (
                <div className="text-xs text-muted-foreground mb-1">{fmt(m.meeting_date)}</div>
              )}
              {(m.notes || m.general_notes) && (
                <p className="text-xs text-muted-foreground truncate">
                  {(m.notes || m.general_notes || '').slice(0, 100)}
                  {(m.notes || m.general_notes || '').length > 100 ? '…' : ''}
                </p>
              )}
            </button>
          ))}
        </div>
      )}

      {detailMeeting && (
        <MeetingDetailModal meeting={detailMeeting} onClose={() => setDetailMeeting(null)} />
      )}
    </div>
  );
}