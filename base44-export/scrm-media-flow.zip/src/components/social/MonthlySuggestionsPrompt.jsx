import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { X, AlertTriangle } from 'lucide-react';

function getDismissKey(clientId, currentMonth) {
  return `dismiss_monthly_${clientId}_${currentMonth}`;
}

export default function MonthlySuggestionsPrompt({ client, items, currentMonth, onUpdate }) {
  const [dismissed, setDismissed] = useState(() => {
    try { return !!sessionStorage.getItem(getDismissKey(client.id, currentMonth)); } catch { return false; }
  });
  const [adDismissed, setAdDismissed] = useState(() => {
    try { return !!sessionStorage.getItem(getDismissKey(client.id, currentMonth) + '_ad'); } catch { return false; }
  });
  const [creating, setCreating] = useState(false);
  const [reviewWarning, setReviewWarning] = useState(false);

  const monthItems = items.filter(i => i.scheduled_date && i.scheduled_date.startsWith(currentMonth));
  const hasTestimonial = monthItems.some(i => i.content_type === 'Testimonial Story');
  const hasDelivery = monthItems.some(i => i.content_type === 'Delivery Post');
  const hasAdContent = monthItems.filter(i => ['Car of the Week', 'Car Highlight'].includes(i.content_type)).length >= 2;

  // Ad suggestion for Dominate/Partner
  const isHighPackage = ['Dominate', 'Partner'].includes(client.package);
  const showAdPrompt = isHighPackage && !hasAdContent && !adDismissed;
  const showContentPrompt = (!hasTestimonial || !hasDelivery) && !dismissed;

  const handleDismiss = () => {
    try { sessionStorage.setItem(getDismissKey(client.id, currentMonth), '1'); } catch {}
    setDismissed(true);
  };

  const handleAdDismiss = () => {
    try { sessionStorage.setItem(getDismissKey(client.id, currentMonth) + '_ad', '1'); } catch {}
    setAdDismissed(true);
  };

  const handleAddBoth = async () => {
    setCreating(true);
    const lowReviews = (client.monthly_google_reviews || 0) < 5;

    if (lowReviews && !hasTestimonial) {
      setReviewWarning(true);
      // Only create Delivery Post
      if (!hasDelivery) {
        await base44.entities.ContentItem.create({
          client: client.id,
          title: 'Delivery Post',
          content_type: 'Delivery Post',
          format: 'Post',
          status: 'Planned',
        });
      }
    } else {
      const toCreate = [];
      if (!hasTestimonial) toCreate.push({ client: client.id, title: 'Testimonial Story', content_type: 'Testimonial Story', format: 'Story', status: 'Planned' });
      if (!hasDelivery) toCreate.push({ client: client.id, title: 'Delivery Post', content_type: 'Delivery Post', format: 'Post', status: 'Planned' });
      await Promise.all(toCreate.map(d => base44.entities.ContentItem.create(d)));
    }
    setCreating(false);
    handleDismiss();
    onUpdate();
  };

  const handleAddAdBoth = async () => {
    setCreating(true);
    await Promise.all([
      base44.entities.ContentItem.create({ client: client.id, title: 'Ad Video 1', content_type: 'Car of the Week', format: 'Reel', status: 'Planned' }),
      base44.entities.ContentItem.create({ client: client.id, title: 'Ad Video 2', content_type: 'Car Highlight', format: 'Reel', status: 'Planned' }),
    ]);
    setCreating(false);
    handleAdDismiss();
    onUpdate();
  };

  if (!showContentPrompt && !showAdPrompt) return null;

  return (
    <div className="space-y-3">
      {showContentPrompt && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl px-4 py-3">
          {reviewWarning && (
            <div className="flex items-start gap-2 mb-3 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
              <AlertTriangle size={14} className="text-red-600 shrink-0 mt-0.5" />
              <p className="text-xs text-red-700">
                <strong>Testimonial Story requires 5+ Google reviews this month.</strong> Update the review count in the client profile first. Only the Delivery Post was created.
              </p>
            </div>
          )}
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-amber-900 mb-1">
                This client typically needs a {!hasTestimonial && !hasDelivery ? 'Testimonial Story and Delivery Post' : !hasTestimonial ? 'Testimonial Story' : 'Delivery Post'} this month — add them?
              </p>
              <div className="flex gap-2 mt-2">
                <button onClick={handleAddBoth} disabled={creating}
                  className="text-xs px-3 py-1.5 bg-amber-600 text-white rounded-lg hover:bg-amber-700 disabled:opacity-50 transition-colors font-medium">
                  {creating ? 'Adding...' : 'Add Both'}
                </button>
                <button onClick={handleDismiss}
                  className="text-xs px-3 py-1.5 border border-amber-300 text-amber-700 rounded-lg hover:bg-amber-100 transition-colors">
                  Dismiss
                </button>
              </div>
            </div>
            <button onClick={handleDismiss} className="text-amber-400 hover:text-amber-700 shrink-0">
              <X size={16} />
            </button>
          </div>
        </div>
      )}

      {showAdPrompt && (
        <div className="bg-blue-50 border border-blue-200 rounded-xl px-4 py-3">
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-blue-900 mb-1">
                This client has 2 ad videos planned this month — add them?
              </p>
              <div className="flex gap-2 mt-2">
                <button onClick={handleAddAdBoth} disabled={creating}
                  className="text-xs px-3 py-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 transition-colors font-medium">
                  {creating ? 'Adding...' : 'Add Both'}
                </button>
                <button onClick={handleAdDismiss}
                  className="text-xs px-3 py-1.5 border border-blue-300 text-blue-700 rounded-lg hover:bg-blue-100 transition-colors">
                  Dismiss
                </button>
              </div>
            </div>
            <button onClick={handleAdDismiss} className="text-blue-400 hover:text-blue-700 shrink-0">
              <X size={16} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}