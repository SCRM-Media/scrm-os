import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import Layout from '@/components/Layout';
import Dashboard from '@/pages/Dashboard';
import SocialCalendar from '@/pages/SocialCalendar';
import Clients from '@/pages/Clients';
import Onboarding from '@/pages/Onboarding';
import Employees from '@/pages/Employees';
import EmployeeCalendar from '@/pages/EmployeeCalendar';
import Packages from '@/pages/Packages';
import VideoExamples from '@/pages/VideoExamples';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-2 border-border border-t-accent rounded-full animate-spin"></div>
          <span className="text-sm text-muted-foreground font-inter">Loading SCRM OS...</span>
        </div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/social-calendar" element={<SocialCalendar />} />
        <Route path="/clients" element={<Clients />} />
        <Route path="/onboarding" element={<Onboarding />} />
        <Route path="/employees" element={<Employees />} />
        <Route path="/employee-calendar" element={<EmployeeCalendar />} />
        <Route path="/packages" element={<Packages />} />
        <Route path="/video-examples" element={<VideoExamples />} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App